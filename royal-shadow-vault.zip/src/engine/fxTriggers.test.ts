import test from 'node:test';
import assert from 'node:assert/strict';
import { detectFxTrigger } from './fxTriggers';

test('detects emoji triggers cleanly', () => {
  assert.equal(detectFxTrigger('Miss you ❤️'), 'heart');
  assert.equal(detectFxTrigger('💋'), 'kiss');
  assert.equal(detectFxTrigger('Boo 👻'), 'ghost');
  assert.equal(detectFxTrigger('💀'), 'horror');
  assert.equal(detectFxTrigger('For you 🌹'), 'rose');
  assert.equal(detectFxTrigger('Look up 🌠'), 'stars');
  assert.equal(detectFxTrigger('So lit 🔥'), 'fire');
  assert.equal(detectFxTrigger('Night 🦋'), 'fireflies');
});

test('detects multilingual keyword triggers', () => {
  assert.equal(detectFxTrigger('sending a kiss now'), 'kiss');
  assert.equal(detectFxTrigger('ye bhoot dekho'), 'ghost');
  assert.equal(detectFxTrigger('bahut darawna scene hai'), 'horror');
  assert.equal(detectFxTrigger('dil se'), 'heart');
  assert.equal(detectFxTrigger('fresh rose'), 'rose');
  assert.equal(detectFxTrigger('aag laga di'), 'fire');
});

test('ignores neutral messages', () => {
  assert.equal(detectFxTrigger('Let us meet at 8pm'), null);
  assert.equal(detectFxTrigger(''), null);
});

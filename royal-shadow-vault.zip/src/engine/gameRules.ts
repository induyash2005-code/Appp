/* ============================================================================
 * PURE DETERMINISTIC RULES FOR TOP 3 CURATED P2P GAMES
 * 1. Stone Paper Scissor (Simultaneous secret lock + reveal)
 * 2. Tic-Tac-Toe (Strictly 1-touch per turn + SVG strike-through)
 * 3. Connect 4 (6x7 Drop Strategy + strictly 1-touch per turn)
 * ============================================================================ */

import type { RpsChoice } from '../types/vault';

/* ---------------- 1. STONE PAPER SCISSOR ---------------- */

export type RpsOutcome = 'win' | 'lose' | 'draw';

export function resolveRpsRound(
  myChoice: RpsChoice,
  peerChoice: RpsChoice
): RpsOutcome {
  if (myChoice === peerChoice) return 'draw';
  if (
    (myChoice === 'rock' && peerChoice === 'scissors') ||
    (myChoice === 'paper' && peerChoice === 'rock') ||
    (myChoice === 'scissors' && peerChoice === 'paper')
  ) {
    return 'win';
  }
  return 'lose';
}

/* ---------------- 2. TIC-TAC-TOE ---------------- */

export type TttCell = 'X' | 'O' | null;

export interface TttWinResult {
  winner: 'X' | 'O' | 'draw' | null;
  line: [number, number, number] | null;
}

const TTT_LINES: Array<[number, number, number]> = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6],
];

export function evaluateTicTacToe(board: TttCell[]): TttWinResult {
  for (const line of TTT_LINES) {
    const [a, b, c] = line;
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return { winner: board[a], line };
    }
  }
  if (board.every((cell) => cell !== null)) {
    return { winner: 'draw', line: null };
  }
  return { winner: null, line: null };
}

/**
 * Returns SVG line coordinates (in 0..300 viewBox) for the winning strike-through.
 */
export function getTttStrikeCoords(line: [number, number, number]): {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
} {
  const center = (idx: number) => {
    const col = idx % 3;
    const row = Math.floor(idx / 3);
    return { x: col * 100 + 50, y: row * 100 + 50 };
  };
  const start = center(line[0]);
  const end = center(line[2]);
  return { x1: start.x, y1: start.y, x2: end.x, y2: end.y };
}

export function canPlayTttMove(params: {
  board: TttCell[];
  index: number;
  mySymbol: 'X' | 'O';
  currentTurn: 'X' | 'O';
  lockedWaitingPeer: boolean;
}): boolean {
  const { board, index, mySymbol, currentTurn, lockedWaitingPeer } = params;
  if (lockedWaitingPeer) return false;
  if (currentTurn !== mySymbol) return false;
  if (index < 0 || index > 8) return false;
  if (board[index] !== null) return false;
  if (evaluateTicTacToe(board).winner !== null) return false;
  return true;
}

/* ---------------- 3. CONNECT 4 (6 ROWS x 7 COLS) ---------------- */

export const C4_ROWS = 6;
export const C4_COLS = 7;
export type C4Cell = 0 | 1 | 2; // 0 = empty, 1 = host (rose-red), 2 = guest (golden-amber)
export type C4Board = C4Cell[][];

export interface C4WinResult {
  winner: 1 | 2 | 'draw' | null;
  cells: Array<[number, number]>;
}

export function createConnect4Board(): C4Board {
  return Array.from({ length: C4_ROWS }, () =>
    Array.from({ length: C4_COLS }, () => 0 as C4Cell)
  );
}

/**
 * Finds the lowest available row in a column where a disc settles under gravity.
 * Returns -1 if the column is full or invalid.
 */
export function getConnect4DropRow(board: C4Board, col: number): number {
  if (col < 0 || col >= C4_COLS) return -1;
  for (let row = C4_ROWS - 1; row >= 0; row--) {
    if (board[row][col] === 0) {
      return row;
    }
  }
  return -1;
}

export function evaluateConnect4(board: C4Board): C4WinResult {
  const directions: Array<[number, number]> = [
    [0, 1],  // horizontal
    [1, 0],  // vertical
    [1, 1],  // diagonal down-right
    [1, -1], // diagonal down-left
  ];

  for (let r = 0; r < C4_ROWS; r++) {
    for (let c = 0; c < C4_COLS; c++) {
      const player = board[r][c];
      if (player === 0) continue;

      for (const [dr, dc] of directions) {
        const line: Array<[number, number]> = [[r, c]];
        for (let step = 1; step < 4; step++) {
          const nr = r + dr * step;
          const nc = c + dc * step;
          if (
            nr >= 0 &&
            nr < C4_ROWS &&
            nc >= 0 &&
            nc < C4_COLS &&
            board[nr][nc] === player
          ) {
            line.push([nr, nc]);
          } else {
            break;
          }
        }
        if (line.length === 4) {
          return { winner: player, cells: line };
        }
      }
    }
  }

  const isDraw = board[0].every((cell) => cell !== 0);
  if (isDraw) {
    return { winner: 'draw', cells: [] };
  }

  return { winner: null, cells: [] };
}

export function canPlayConnect4Move(params: {
  board: C4Board;
  col: number;
  myDisc: 1 | 2;
  currentTurn: 1 | 2;
  lockedWaitingPeer: boolean;
}): boolean {
  const { board, col, myDisc, currentTurn, lockedWaitingPeer } = params;
  if (lockedWaitingPeer) return false;
  if (currentTurn !== myDisc) return false;
  if (evaluateConnect4(board).winner !== null) return false;
  return getConnect4DropRow(board, col) !== -1;
}

/**
 * Deterministically assigns Host ('X' / disc 1) vs Guest ('O' / disc 2) between two 4-digit peer codes.
 * The lexicographically smaller code is Host, ensuring both devices agree without handshake race.
 */
export function resolvePeerRole(myCode: string, peerCode: string): 'host' | 'guest' {
  return myCode <= peerCode ? 'host' : 'guest';
}

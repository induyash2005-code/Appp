import test from 'node:test';
import assert from 'node:assert/strict';
import {
  evaluateMathExpression,
  isStealthPinMatch,
  normalizeExpression,
} from './mathParser';

test('normalizes visual symbols to canonical operators', () => {
  assert.equal(normalizeExpression('12 × 3 ÷ 2 − 1'), '12*3/2-1');
});

test('respects operator precedence and unary minus', () => {
  assert.equal(evaluateMathExpression('2+3×4').value, '14');
  assert.equal(evaluateMathExpression('10−3×2+8÷4').value, '6');
  assert.equal(evaluateMathExpression('-5×3').value, '-15');
  assert.equal(evaluateMathExpression('15%4').value, '3');
});

test('handles decimals cleanly without IEEE-754 noise', () => {
  assert.equal(evaluateMathExpression('0.1+0.2').value, '0.3');
  assert.equal(evaluateMathExpression('7×6').value, '42');
});

test('handles division by zero and malformed inputs gracefully', () => {
  assert.equal(evaluateMathExpression('10÷0').ok, false);
  assert.equal(evaluateMathExpression('10÷0').value, 'Error');
  assert.equal(evaluateMathExpression('5++2').ok, false);
});

test('stealth PIN matching works accurately', () => {
  assert.equal(isStealthPinMatch('1904', '1904'), true);
  assert.equal(isStealthPinMatch('1904+1', '1904'), false);
  assert.equal(isStealthPinMatch('4821', '4821'), true);
});

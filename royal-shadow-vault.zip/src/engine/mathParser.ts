/* ============================================================================
 * ZERO-DEPENDENCY SAFE ARITHMETIC MATH PARSER (NO eval / NO Function)
 * Supports +, −, ×, ÷, %, decimals, unary minus, and operator precedence.
 * ============================================================================ */

export interface MathResult {
  ok: boolean;
  value: string;
  error?: string;
}

interface Token {
  type: 'number' | 'op';
  value: string;
}

/**
 * Normalizes visual calculator symbols (×, ÷, −) to canonical ASCII operators.
 */
export function normalizeExpression(expr: string): string {
  return expr
    .replace(/×/g, '*')
    .replace(/÷/g, '/')
    .replace(/−/g, '-')
    .replace(/\s+/g, '');
}

/**
 * Tokenizes a normalized math expression into numbers and operators.
 */
export function tokenizeExpression(raw: string): Token[] | null {
  const expr = normalizeExpression(raw);
  if (!expr) return null;

  const tokens: Token[] = [];
  let i = 0;

  while (i < expr.length) {
    const ch = expr[i];

    // Check unary minus at start or immediately following an operator
    const isUnaryMinus =
      ch === '-' &&
      (tokens.length === 0 || tokens[tokens.length - 1].type === 'op');

    if ((ch >= '0' && ch <= '9') || ch === '.' || isUnaryMinus) {
      let numStr = '';
      if (isUnaryMinus) {
        numStr += '-';
        i++;
      }
      let dotCount = 0;
      let hasDigit = false;
      while (i < expr.length) {
        const c = expr[i];
        if (c >= '0' && c <= '9') {
          hasDigit = true;
          numStr += c;
          i++;
        } else if (c === '.') {
          dotCount++;
          if (dotCount > 1) return null;
          numStr += c;
          i++;
        } else {
          break;
        }
      }
      if (!hasDigit) return null;
      tokens.push({ type: 'number', value: numStr });
      continue;
    }

    if (ch === '+' || ch === '-' || ch === '*' || ch === '/' || ch === '%') {
      if (tokens.length === 0 || tokens[tokens.length - 1].type === 'op') {
        return null;
      }
      tokens.push({ type: 'op', value: ch });
      i++;
      continue;
    }

    return null;
  }

  if (tokens.length === 0 || tokens[tokens.length - 1].type === 'op') {
    return null;
  }

  return tokens;
}

/**
 * Formats floating-point output cleanly without IEEE-754 trailing noise.
 */
export function formatCalcNumber(num: number): string {
  if (!Number.isFinite(num)) {
    return 'Error';
  }
  if (Object.is(num, -0) || Math.abs(num) < 1e-12) {
    return '0';
  }
  const rounded = Number(num.toPrecision(12));
  if (Math.abs(rounded) >= 1e12 || (Math.abs(rounded) > 0 && Math.abs(rounded) < 1e-7)) {
    return rounded.toExponential(6).replace(/\.?0+e/, 'e');
  }
  return String(rounded);
}

/**
 * Evaluates an arithmetic expression safely using recursive precedence folding.
 * Returns MathResult without ever calling eval() or new Function().
 */
export function evaluateMathExpression(raw: string): MathResult {
  const cleaned = normalizeExpression(raw);
  if (!cleaned) {
    return { ok: true, value: '0' };
  }

  const tokens = tokenizeExpression(cleaned);
  if (!tokens) {
    return { ok: false, value: 'Error', error: 'Invalid expression' };
  }

  // Pass 1: evaluate *, /, % left-to-right
  const afterMulDiv: Array<number | string> = [];
  let idx = 0;

  while (idx < tokens.length) {
    const tok = tokens[idx];
    if (tok.type === 'number') {
      const parsed = Number(tok.value);
      if (!Number.isFinite(parsed)) {
        return { ok: false, value: 'Error', error: 'Invalid number' };
      }
      afterMulDiv.push(parsed);
      idx++;
    } else if (tok.value === '*' || tok.value === '/' || tok.value === '%') {
      const left = afterMulDiv.pop();
      const rightToken = tokens[idx + 1];
      if (typeof left !== 'number' || !rightToken || rightToken.type !== 'number') {
        return { ok: false, value: 'Error', error: 'Malformed term' };
      }
      const right = Number(rightToken.value);
      if (tok.value === '*') {
        afterMulDiv.push(left * right);
      } else if (tok.value === '/') {
        if (right === 0) {
          return { ok: false, value: 'Error', error: 'Division by zero' };
        }
        afterMulDiv.push(left / right);
      } else {
        if (right === 0) {
          return { ok: false, value: 'Error', error: 'Modulo by zero' };
        }
        afterMulDiv.push(left % right);
      }
      idx += 2;
    } else {
      afterMulDiv.push(tok.value);
      idx++;
    }
  }

  // Pass 2: evaluate + and - left-to-right
  let acc = afterMulDiv[0];
  if (typeof acc !== 'number') {
    return { ok: false, value: 'Error', error: 'Malformed expression' };
  }

  for (let j = 1; j < afterMulDiv.length; j += 2) {
    const op = afterMulDiv[j];
    const rhs = afterMulDiv[j + 1];
    if (typeof rhs !== 'number') {
      return { ok: false, value: 'Error', error: 'Malformed expression' };
    }
    if (op === '+') {
      acc += rhs;
    } else if (op === '-') {
      acc -= rhs;
    } else {
      return { ok: false, value: 'Error', error: 'Unknown operator' };
    }
  }

  const formatted = formatCalcNumber(acc);
  if (formatted === 'Error') {
    return { ok: false, value: 'Error', error: 'Overflow' };
  }
  return { ok: true, value: formatted };
}

/**
 * Checks whether the raw calculator input matches the Stealth PIN exactly.
 */
export function isStealthPinMatch(expression: string, pin: string): boolean {
  const normalizedExpr = normalizeExpression(expression).trim();
  const normalizedPin = pin.trim();
  return normalizedPin.length >= 3 && normalizedExpr === normalizedPin;
}

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  canPlayConnect4Move,
  canPlayTttMove,
  createConnect4Board,
  evaluateConnect4,
  evaluateTicTacToe,
  getConnect4DropRow,
  getTttStrikeCoords,
  resolvePeerRole,
  resolveRpsRound,
  type TttCell,
} from './gameRules';

test('resolveRpsRound resolves win, lose, and draw correctly', () => {
  assert.equal(resolveRpsRound('rock', 'scissors'), 'win');
  assert.equal(resolveRpsRound('paper', 'scissors'), 'lose');
  assert.equal(resolveRpsRound('paper', 'paper'), 'draw');
});

test('Tic-Tac-Toe enforces strict 1-touch turn locking and detects wins', () => {
  const board: TttCell[] = ['X', 'X', null, 'O', 'O', null, null, null, null];
  assert.equal(
    canPlayTttMove({
      board,
      index: 2,
      mySymbol: 'X',
      currentTurn: 'X',
      lockedWaitingPeer: false,
    }),
    true
  );
  // Locked waiting for peer -> cannot tap again
  assert.equal(
    canPlayTttMove({
      board,
      index: 2,
      mySymbol: 'X',
      currentTurn: 'X',
      lockedWaitingPeer: true,
    }),
    false
  );
  // Not my turn -> cannot tap
  assert.equal(
    canPlayTttMove({
      board,
      index: 2,
      mySymbol: 'O',
      currentTurn: 'X',
      lockedWaitingPeer: false,
    }),
    false
  );

  const wonBoard: TttCell[] = ['X', 'X', 'X', 'O', 'O', null, null, null, null];
  const res = evaluateTicTacToe(wonBoard);
  assert.equal(res.winner, 'X');
  assert.deepEqual(res.line, [0, 1, 2]);
  assert.deepEqual(getTttStrikeCoords(res.line!), {
    x1: 50,
    y1: 50,
    x2: 250,
    y2: 50,
  });
});

test('Connect 4 gravity drop, turn lock, and 4-in-a-row evaluation', () => {
  const board = createConnect4Board();
  assert.equal(getConnect4DropRow(board, 3), 5);
  board[5][3] = 1;
  assert.equal(getConnect4DropRow(board, 3), 4);

  assert.equal(
    canPlayConnect4Move({
      board,
      col: 3,
      myDisc: 2,
      currentTurn: 2,
      lockedWaitingPeer: true,
    }),
    false
  );

  // Diagonal 4-in-a-row win for player 2
  board[5][0] = 2;
  board[4][1] = 2;
  board[3][2] = 2;
  board[2][3] = 2;
  const win = evaluateConnect4(board);
  assert.equal(win.winner, 2);
  assert.equal(win.cells.length, 4);
});

test('resolvePeerRole agrees deterministically across devices', () => {
  assert.equal(resolvePeerRole('1204', '8912'), 'host');
  assert.equal(resolvePeerRole('8912', '1204'), 'guest');
});

/* ============================================================================
 * ZERO-SERVER P2P STATE MACHINE (PEERJS OVER WEBRTC + STUN)
 * - Auto-unique 4-digit code (1000-9999) with unavailable-id collision retry
 * - Persistent auto-reconnect for saved friends
 * - DataChannel packet delivery + MediaConnection voice/video/3-way calls
 * ============================================================================ */

import Peer, { type DataConnection, type MediaConnection } from 'peerjs';
import type { P2PPacket, PeerConnectionStatus } from '../types/vault';
import { generateFourDigitCode } from './storage';

const PEER_PREFIX = 'rsv7-';

export function toPeerId(fourDigitCode: string): string {
  return `${PEER_PREFIX}${fourDigitCode.trim()}`;
}

export function fromPeerId(peerId: string): string {
  return peerId.startsWith(PEER_PREFIX)
    ? peerId.slice(PEER_PREFIX.length)
    : peerId;
}

export interface P2PEventHandlers {
  onStatusChange: (status: PeerConnectionStatus) => void;
  onCodeAssigned: (newCode: string) => void;
  onOnlinePeersChange: (onlineCodes: Set<string>) => void;
  onPacket: (fromCode: string, packet: P2PPacket) => void;
  onIncomingMediaCall: (call: MediaConnection, fromCode: string) => void;
}

export class VaultP2PManager {
  private peer: Peer | null = null;
  private myCode = '';
  private myName = '';
  private myAvatar = '';
  private knownFriendCodes: string[] = [];
  private connections = new Map<string, DataConnection>();
  private onlineCodes = new Set<string>();
  private triedCollisionCodes = new Set<string>();
  private handlers: P2PEventHandlers;
  private reconnectTimer: number | null = null;
  private presenceTimer: number | null = null;
  private destroyed = false;

  constructor(handlers: P2PEventHandlers) {
    this.handlers = handlers;
  }

  public start(params: {
    code: string;
    displayName: string;
    avatarDataUrl: string;
    friendCodes: string[];
  }): void {
    this.destroyed = false;
    this.myCode = params.code;
    this.myName = params.displayName;
    this.myAvatar = params.avatarDataUrl;
    this.knownFriendCodes = params.friendCodes;
    this.connectPeer(params.code);
  }

  public updateProfile(displayName: string, avatarDataUrl: string): void {
    this.myName = displayName;
    this.myAvatar = avatarDataUrl;
  }

  public updateFriends(friendCodes: string[]): void {
    this.knownFriendCodes = friendCodes;
    for (const code of friendCodes) {
      if (!this.connections.has(code) && this.peer && !this.peer.destroyed) {
        this.connectToFriend(code);
      }
    }
  }

  public stop(): void {
    this.destroyed = true;
    if (this.reconnectTimer !== null) {
      window.clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.presenceTimer !== null) {
      window.clearInterval(this.presenceTimer);
      this.presenceTimer = null;
    }
    this.connections.forEach((conn) => {
      try {
        conn.close();
      } catch {
        // ignore
      }
    });
    this.connections.clear();
    this.onlineCodes.clear();
    this.handlers.onOnlinePeersChange(new Set());
    if (this.peer) {
      try {
        this.peer.destroy();
      } catch {
        // ignore
      }
      this.peer = null;
    }
    this.handlers.onStatusChange('offline');
  }

  private connectPeer(code: string): void {
    if (this.destroyed) return;
    if (this.peer) {
      try {
        this.peer.destroy();
      } catch {
        // ignore
      }
      this.peer = null;
    }

    this.myCode = code;
    this.handlers.onStatusChange('connecting');

    try {
      const peer = new Peer(toPeerId(code), {
        debug: 0,
        config: {
          iceServers: [
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' },
          ],
        },
      });
      this.peer = peer;

      peer.on('open', () => {
        if (this.destroyed) return;
        this.handlers.onStatusChange('ready');
        this.connectAllFriends();
        this.startPresenceHeartbeat();
      });

      peer.on('connection', (conn) => {
        this.attachDataConnection(conn);
      });

      peer.on('call', (mediaCall) => {
        const remoteCode = fromPeerId(mediaCall.peer);
        this.handlers.onIncomingMediaCall(mediaCall, remoteCode);
      });

      peer.on('disconnected', () => {
        if (this.destroyed) return;
        this.handlers.onStatusChange('connecting');
        this.scheduleReconnect();
      });

      peer.on('error', (err: unknown) => {
        if (this.destroyed) return;
        const errType =
          typeof err === 'object' && err !== null && 'type' in err
            ? String((err as { type?: string }).type)
            : '';

        // Auto-unique 4-digit collision recovery
        if (errType === 'unavailable-id') {
          this.triedCollisionCodes.add(this.myCode);
          const freshCode = generateFourDigitCode(this.triedCollisionCodes);
          this.handlers.onCodeAssigned(freshCode);
          this.connectPeer(freshCode);
          return;
        }

        if (errType === 'peer-unavailable') {
          // Friend is currently offline; keep socket ready without breaking own session
          return;
        }

        if (
          errType === 'network' ||
          errType === 'server-error' ||
          errType === 'socket-error' ||
          errType === 'socket-closed'
        ) {
          this.handlers.onStatusChange('error');
          this.scheduleReconnect();
        }
      });
    } catch {
      this.handlers.onStatusChange('error');
      this.scheduleReconnect();
    }
  }

  private scheduleReconnect(): void {
    if (this.destroyed || this.reconnectTimer !== null) return;
    this.reconnectTimer = window.setTimeout(() => {
      this.reconnectTimer = null;
      if (this.destroyed) return;
      if (this.peer && this.peer.disconnected && !this.peer.destroyed) {
        try {
          this.peer.reconnect();
        } catch {
          this.connectPeer(this.myCode);
        }
      } else if (!this.peer || this.peer.destroyed) {
        this.connectPeer(this.myCode);
      }
    }, 3500);
  }

  private startPresenceHeartbeat(): void {
    if (this.presenceTimer !== null) {
      window.clearInterval(this.presenceTimer);
    }
    this.presenceTimer = window.setInterval(() => {
      if (this.destroyed) return;
      this.connectAllFriends();
      this.connections.forEach((conn, remoteCode) => {
        if (conn.open) {
          this.sendToCode(remoteCode, {
            type: 'presence_ping',
            fromCode: this.myCode,
            sentAt: Date.now(),
          });
        }
      });
    }, 12000);
  }

  private connectAllFriends(): void {
    for (const code of this.knownFriendCodes) {
      const existing = this.connections.get(code);
      if (!existing || !existing.open) {
        this.connectToFriend(code);
      }
    }
  }

  public connectToFriend(targetCode: string): DataConnection | null {
    if (!this.peer || this.peer.destroyed || targetCode === this.myCode) {
      return null;
    }
    const existing = this.connections.get(targetCode);
    if (existing && existing.open) {
      return existing;
    }
    try {
      const conn = this.peer.connect(toPeerId(targetCode), { reliable: true });
      this.attachDataConnection(conn);
      return conn;
    } catch {
      return null;
    }
  }

  private attachDataConnection(conn: DataConnection): void {
    const remoteCode = fromPeerId(conn.peer);

    conn.on('open', () => {
      this.connections.set(remoteCode, conn);
      this.markPeerOnline(remoteCode, true);
      this.sendDirect(conn, {
        type: 'presence_hello',
        fromCode: this.myCode,
        displayName: this.myName,
        avatarDataUrl: this.myAvatar,
        sentAt: Date.now(),
      });
    });

    conn.on('data', (raw) => {
      if (!raw || typeof raw !== 'object') return;
      const packet = raw as P2PPacket;
      this.markPeerOnline(remoteCode, true);
      this.handlers.onPacket(remoteCode, packet);
    });

    conn.on('close', () => {
      if (this.connections.get(remoteCode) === conn) {
        this.connections.delete(remoteCode);
      }
      this.markPeerOnline(remoteCode, false);
    });

    conn.on('error', () => {
      if (this.connections.get(remoteCode) === conn) {
        this.connections.delete(remoteCode);
      }
      this.markPeerOnline(remoteCode, false);
    });
  }

  private markPeerOnline(code: string, isOnline: boolean): void {
    const next = new Set(this.onlineCodes);
    if (isOnline) {
      next.add(code);
    } else {
      next.delete(code);
    }
    this.onlineCodes = next;
    this.handlers.onOnlinePeersChange(next);
  }

  private sendDirect(conn: DataConnection, packet: P2PPacket): boolean {
    try {
      if (conn.open) {
        conn.send(packet);
        return true;
      }
    } catch {
      // ignore
    }
    return false;
  }

  public sendToCode(targetCode: string, packet: P2PPacket): boolean {
    const existing = this.connections.get(targetCode);
    if (existing && existing.open) {
      return this.sendDirect(existing, packet);
    }

    // Attempt transient connection and send once open
    const conn = this.connectToFriend(targetCode);
    if (!conn) return false;
    conn.once('open', () => {
      this.sendDirect(conn, packet);
    });
    return true;
  }

  public callPeer(targetCode: string, localStream: MediaStream): MediaConnection | null {
    if (!this.peer || this.peer.destroyed) return null;
    try {
      return this.peer.call(toPeerId(targetCode), localStream);
    } catch {
      return null;
    }
  }
}

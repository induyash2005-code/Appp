/* ============================================================================
 * FULLSCREEN CANVAS 2D PARTICLE & PHYSICS FX ENGINE
 * Renders 8 layered, high-FPS animations with dt clamping & clean pooling:
 * heart | kiss | ghost | horror | rose | stars | fire | fireflies
 * ============================================================================ */

import type { FxType } from '../types/vault';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  alpha: number;
  rotation: number;
  vRot: number;
  phase: number;
  life: number;
  maxLife: number;
  color: string;
  secondaryColor: string;
  flip: number;
  vFlip: number;
  delay: number;
  trail: Array<{ x: number; y: number }>;
}

interface Shockwave {
  radius: number;
  maxRadius: number;
  alpha: number;
  delay: number;
  color: string;
}

interface GhostEntity {
  x: number;
  y: number;
  baseY: number;
  vx: number;
  scale: number;
  alpha: number;
  phase: number;
  tint: string;
}

interface LightningBolt {
  segments: Array<{ x: number; y: number }>;
  alpha: number;
  triggerAt: number;
}

export class FullscreenFxRenderer {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private rafId: number | null = null;
  private lastTs = 0;
  private elapsed = 0;
  private duration = 3.6;
  private activeFx: FxType = 'heart';
  private onComplete?: () => void;

  private width = 0;
  private height = 0;
  private dpr = 1;

  private particles: Particle[] = [];
  private shockwaves: Shockwave[] = [];
  private ghosts: GhostEntity[] = [];
  private bolts: LightningBolt[] = [];

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const context = canvas.getContext('2d');
    if (!context) {
      throw new Error('Canvas 2D context unavailable');
    }
    this.ctx = context;
    this.resize();
  }

  public resize(): void {
    const rect = this.canvas.getBoundingClientRect();
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.width = Math.max(320, rect.width || window.innerWidth);
    this.height = Math.max(320, rect.height || window.innerHeight);
    this.canvas.width = Math.floor(this.width * this.dpr);
    this.canvas.height = Math.floor(this.height * this.dpr);
    this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
  }

  public start(fx: FxType, onComplete?: () => void): void {
    this.stop();
    this.resize();
    this.activeFx = fx;
    this.onComplete = onComplete;
    this.elapsed = 0;
    this.lastTs = performance.now();
    this.particles = [];
    this.shockwaves = [];
    this.ghosts = [];
    this.bolts = [];

    switch (fx) {
      case 'heart':
        this.duration = 3.5;
        this.initHeartScene();
        break;
      case 'kiss':
        this.duration = 3.4;
        this.initKissScene();
        break;
      case 'ghost':
        this.duration = 3.8;
        this.initGhostScene();
        break;
      case 'horror':
        this.duration = 3.2;
        this.initHorrorScene();
        break;
      case 'rose':
        this.duration = 4.0;
        this.initRoseScene();
        break;
      case 'stars':
        this.duration = 3.6;
        this.initStarsScene();
        break;
      case 'fire':
        this.duration = 3.6;
        this.initFireScene();
        break;
      case 'fireflies':
        this.duration = 4.0;
        this.initFirefliesScene();
        break;
    }

    const tick = (now: number) => {
      const rawDt = (now - this.lastTs) / 1000;
      this.lastTs = now;
      const dt = Math.min(Math.max(rawDt, 0.001), 0.05);
      this.elapsed += dt;

      this.renderFrame(dt);

      if (this.elapsed >= this.duration) {
        this.stop();
        this.onComplete?.();
        return;
      }
      this.rafId = window.requestAnimationFrame(tick);
    };

    this.rafId = window.requestAnimationFrame(tick);
  }

  public stop(): void {
    if (this.rafId !== null) {
      window.cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
    this.ctx.clearRect(0, 0, this.width, this.height);
  }

  /* ---------------- SCENE INITIALIZERS ---------------- */

  private initHeartScene(): void {
    const maxR = Math.hypot(this.width, this.height) * 0.45;
    this.shockwaves = [
      { radius: 24, maxRadius: maxR, alpha: 0.9, delay: 0.05, color: '#fbbf24' },
      { radius: 24, maxRadius: maxR * 0.88, alpha: 0.85, delay: 0.24, color: '#fb7185' },
      { radius: 24, maxRadius: maxR, alpha: 0.85, delay: 0.65, color: '#fbbf24' },
      { radius: 24, maxRadius: maxR * 0.88, alpha: 0.8, delay: 0.84, color: '#f43f5e' },
    ];

    for (let i = 0; i < 34; i++) {
      const golden = i % 3 === 0;
      this.particles.push({
        x: this.width * (0.12 + Math.random() * 0.76),
        y: this.height * (0.68 + Math.random() * 0.42),
        vx: (Math.random() - 0.5) * 32,
        vy: -(85 + Math.random() * 145),
        size: 10 + Math.random() * 18,
        alpha: 0.7 + Math.random() * 0.3,
        rotation: (Math.random() - 0.5) * 0.5,
        vRot: (Math.random() - 0.5) * 0.8,
        phase: Math.random() * Math.PI * 2,
        life: 0,
        maxLife: 2.8 + Math.random() * 0.8,
        color: golden ? '#fbbf24' : '#fb7185',
        secondaryColor: golden ? '#fef08a' : '#e11d48',
        flip: 1,
        vFlip: 0,
        delay: Math.random() * 0.6,
        trail: [],
      });
    }
  }

  private initKissScene(): void {
    // 14 ruby lipstick stamps + bursts of rose-gold stardust
    for (let i = 0; i < 14; i++) {
      const kx = this.width * (0.14 + Math.random() * 0.72);
      const ky = this.height * (0.14 + Math.random() * 0.72);
      const delay = i * 0.13;
      this.particles.push({
        x: kx,
        y: ky,
        vx: 0,
        vy: -6,
        size: 32 + Math.random() * 26,
        alpha: 0.92,
        rotation: (Math.random() - 0.5) * 0.8,
        vRot: 0,
        phase: 0,
        life: 0,
        maxLife: 2.3,
        color: i % 2 === 0 ? '#e11d48' : '#be123c',
        secondaryColor: '#fda4af',
        flip: 1,
        vFlip: 0,
        delay,
        trail: [],
      });

      // Shimmering rose-gold dust around each kiss
      for (let s = 0; s < 10; s++) {
        const angle = (Math.PI * 2 * s) / 10 + Math.random() * 0.4;
        const speed = 40 + Math.random() * 95;
        this.particles.push({
          x: kx,
          y: ky,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          size: 2 + Math.random() * 3.5,
          alpha: 1,
          rotation: 0,
          vRot: 0,
          phase: 1, // mark as dust spark
          life: 0,
          maxLife: 1.1 + Math.random() * 0.5,
          color: s % 2 === 0 ? '#fbbf24' : '#fda4af',
          secondaryColor: '#fff1f2',
          flip: 1,
          vFlip: 0,
          delay: delay + 0.05,
          trail: [],
        });
      }
    }
  }

  private initGhostScene(): void {
    for (let i = 0; i < 6; i++) {
      const fromLeft = i % 2 === 0;
      const baseY = this.height * (0.18 + (i / 6) * 0.58);
      this.ghosts.push({
        x: fromLeft ? -80 - i * 45 : this.width + 80 + i * 45,
        y: baseY,
        baseY,
        vx: (fromLeft ? 1 : -1) * (120 + Math.random() * 95),
        scale: 0.72 + Math.random() * 0.48,
        alpha: 0.72 + Math.random() * 0.2,
        phase: Math.random() * Math.PI * 2,
        tint: i % 2 === 0 ? 'rgba(165, 243, 252, 0.85)' : 'rgba(196, 181, 253, 0.85)',
      });
    }

    // Spectral wisps
    for (let i = 0; i < 42; i++) {
      this.particles.push({
        x: Math.random() * this.width,
        y: this.height * (0.45 + Math.random() * 0.55),
        vx: (Math.random() - 0.5) * 35,
        vy: -(25 + Math.random() * 55),
        size: 3 + Math.random() * 8,
        alpha: 0.55,
        rotation: 0,
        vRot: 0,
        phase: Math.random() * Math.PI * 2,
        life: 0,
        maxLife: 3.4,
        color: i % 2 === 0 ? '#67e8f9' : '#c4b5fd',
        secondaryColor: '#ffffff',
        flip: 1,
        vFlip: 0,
        delay: Math.random() * 0.4,
        trail: [],
      });
    }
  }

  private initHorrorScene(): void {
    const createBolt = (startX: number, triggerAt: number): LightningBolt => {
      const segments: Array<{ x: number; y: number }> = [{ x: startX, y: 0 }];
      let cx = startX;
      let cy = 0;
      const steps = 10;
      for (let i = 1; i <= steps; i++) {
        cx += (Math.random() - 0.5) * 110;
        cy = (this.height * 0.82 * i) / steps;
        segments.push({ x: cx, y: cy });
      }
      return { segments, alpha: 1, triggerAt };
    };

    this.bolts = [
      createBolt(this.width * 0.28, 0.04),
      createBolt(this.width * 0.72, 0.18),
      createBolt(this.width * 0.5, 0.85),
    ];

    for (let i = 0; i < 45; i++) {
      this.particles.push({
        x: Math.random() * this.width,
        y: Math.random() * this.height,
        vx: (Math.random() - 0.5) * 60,
        vy: (Math.random() - 0.5) * 40,
        size: 2 + Math.random() * 4,
        alpha: 0.7,
        rotation: 0,
        vRot: 0,
        phase: Math.random() * Math.PI * 2,
        life: 0,
        maxLife: 3.0,
        color: i % 3 === 0 ? '#ef4444' : '#7f1d1d',
        secondaryColor: '#000000',
        flip: 1,
        vFlip: 0,
        delay: 0,
        trail: [],
      });
    }
  }

  private initRoseScene(): void {
    for (let i = 0; i < 48; i++) {
      this.particles.push({
        x: Math.random() * (this.width + 80) - 40,
        y: -30 - Math.random() * (this.height * 0.65),
        vx: (Math.random() - 0.3) * 45,
        vy: 85 + Math.random() * 115,
        size: 11 + Math.random() * 13,
        alpha: 0.86 + Math.random() * 0.14,
        rotation: Math.random() * Math.PI * 2,
        vRot: (Math.random() - 0.5) * 2.8,
        phase: Math.random() * Math.PI * 2,
        life: 0,
        maxLife: 4.0,
        color: i % 4 === 0 ? '#fb7185' : i % 2 === 0 ? '#e11d48' : '#be123c',
        secondaryColor: '#881337',
        flip: Math.random() * Math.PI,
        vFlip: 2.2 + Math.random() * 2.4,
        delay: Math.random() * 0.8,
        trail: [],
      });
    }
  }

  private initStarsScene(): void {
    // 14 diagonal golden meteors + 40 twinkling background stardust particles
    for (let i = 0; i < 14; i++) {
      const startX = this.width * (0.25 + Math.random() * 0.9);
      const startY = -40 - Math.random() * 120;
      const speed = 520 + Math.random() * 340;
      const angle = Math.PI * 0.72 + (Math.random() - 0.5) * 0.12;
      this.particles.push({
        x: startX,
        y: startY,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: 3.5 + Math.random() * 3,
        alpha: 1,
        rotation: angle,
        vRot: 0,
        phase: 0, // meteor
        life: 0,
        maxLife: 1.5,
        color: '#fef08a',
        secondaryColor: '#fbbf24',
        flip: 1,
        vFlip: 0,
        delay: i * 0.18,
        trail: [],
      });
    }

    for (let i = 0; i < 42; i++) {
      this.particles.push({
        x: Math.random() * this.width,
        y: Math.random() * this.height,
        vx: 0,
        vy: 0,
        size: 1.5 + Math.random() * 2.8,
        alpha: 0.9,
        rotation: 0,
        vRot: 0,
        phase: 1 + Math.random() * 6, // static twinkle
        life: 0,
        maxLife: 3.6,
        color: '#fde68a',
        secondaryColor: '#ffffff',
        flip: 1,
        vFlip: 0,
        delay: Math.random() * 0.5,
        trail: [],
      });
    }
  }

  private initFireScene(): void {
    for (let i = 0; i < 85; i++) {
      this.particles.push({
        x: Math.random() * this.width,
        y: this.height + 10 + Math.random() * 140,
        vx: (Math.random() - 0.5) * 75,
        vy: -(160 + Math.random() * 260),
        size: 2.2 + Math.random() * 5.2,
        alpha: 0.95,
        rotation: 0,
        vRot: 0,
        phase: Math.random() * Math.PI * 2,
        life: 0,
        maxLife: 1.8 + Math.random() * 1.4,
        color: i % 3 === 0 ? '#fde047' : i % 2 === 0 ? '#fb923c' : '#ef4444',
        secondaryColor: '#fbbf24',
        flip: 1,
        vFlip: 0,
        delay: Math.random() * 1.1,
        trail: [],
      });
    }
  }

  private initFirefliesScene(): void {
    for (let i = 0; i < 36; i++) {
      this.particles.push({
        x: Math.random() * this.width,
        y: this.height * (0.15 + Math.random() * 0.75),
        vx: (Math.random() - 0.5) * 55,
        vy: (Math.random() - 0.5) * 45,
        size: 3 + Math.random() * 4.5,
        alpha: 0.95,
        rotation: 0,
        vRot: 0,
        phase: Math.random() * Math.PI * 2,
        life: 0,
        maxLife: 4.0,
        color: i % 3 === 0 ? '#bef264' : '#fde047',
        secondaryColor: '#fbbf24',
        flip: 1,
        vFlip: 0,
        delay: Math.random() * 0.25,
        trail: [],
      });
    }
  }

  /* ---------------- FRAME RENDERERS ---------------- */

  private renderFrame(dt: number): void {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.width, this.height);

    const fadeOut =
      this.elapsed > this.duration - 0.65
        ? Math.max(0, (this.duration - this.elapsed) / 0.65)
        : 1;

    ctx.save();
    ctx.globalAlpha = fadeOut;

    switch (this.activeFx) {
      case 'heart':
        this.renderHeart(dt);
        break;
      case 'kiss':
        this.renderKiss(dt);
        break;
      case 'ghost':
        this.renderGhost(dt);
        break;
      case 'horror':
        this.renderHorror(dt);
        break;
      case 'rose':
        this.renderRose(dt);
        break;
      case 'stars':
        this.renderStars(dt);
        break;
      case 'fire':
        this.renderFire(dt);
        break;
      case 'fireflies':
        this.renderFireflies(dt);
        break;
    }

    ctx.restore();
  }

  private drawHeartPath(x: number, y: number, size: number): void {
    const ctx = this.ctx;
    ctx.beginPath();
    const topCurveHeight = size * 0.3;
    ctx.moveTo(x, y + topCurveHeight);
    ctx.bezierCurveTo(x, y, x - size / 2, y, x - size / 2, y + topCurveHeight);
    ctx.bezierCurveTo(
      x - size / 2,
      y + (size + topCurveHeight) / 2,
      x,
      y + (size + topCurveHeight) / 1.25,
      x,
      y + size
    );
    ctx.bezierCurveTo(
      x,
      y + (size + topCurveHeight) / 1.25,
      x + size / 2,
      y + (size + topCurveHeight) / 2,
      x + size / 2,
      y + topCurveHeight
    );
    ctx.bezierCurveTo(x + size / 2, y, x, y, x, y + topCurveHeight);
    ctx.closePath();
  }

  private renderHeart(dt: number): void {
    const ctx = this.ctx;
    const cx = this.width / 2;
    const cy = this.height / 2;

    // Deep crimson-gold radial screen aura
    const aura = ctx.createRadialGradient(
      cx,
      cy,
      20,
      cx,
      cy,
      Math.max(this.width, this.height) * 0.65
    );
    aura.addColorStop(0, 'rgba(225, 29, 72, 0.32)');
    aura.addColorStop(0.5, 'rgba(251, 191, 36, 0.14)');
    aura.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = aura;
    ctx.fillRect(0, 0, this.width, this.height);

    // Expanding golden & crimson shockwaves
    for (const sw of this.shockwaves) {
      if (this.elapsed < sw.delay) continue;
      sw.radius += (sw.maxRadius - sw.radius) * Math.min(1, dt * 3.1);
      sw.alpha = Math.max(0, 1 - sw.radius / sw.maxRadius);
      ctx.save();
      ctx.strokeStyle = sw.color;
      ctx.globalAlpha *= sw.alpha * 0.72;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(cx, cy, sw.radius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    // Floating luminous hearts
    for (const p of this.particles) {
      if (this.elapsed < p.delay) continue;
      p.life += dt;
      p.x += p.vx * dt + Math.sin(this.elapsed * 2.5 + p.phase) * 18 * dt;
      p.y += p.vy * dt;
      p.rotation += p.vRot * dt;

      const lifeFade = Math.max(0, 1 - p.life / p.maxLife);
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rotation);
      ctx.globalAlpha *= p.alpha * lifeFade;
      ctx.shadowColor = p.color;
      ctx.shadowBlur = 14;
      const g = ctx.createLinearGradient(0, -p.size / 2, 0, p.size / 2);
      g.addColorStop(0, p.secondaryColor);
      g.addColorStop(1, p.color);
      ctx.fillStyle = g;
      this.drawHeartPath(0, -p.size * 0.5, p.size);
      ctx.fill();
      ctx.restore();
    }

    // Giant center pulsing 3D-styled heart (lub-dub beat)
    const beatCycle = (this.elapsed % 0.62) / 0.62;
    const pulse =
      beatCycle < 0.22
        ? 1 + Math.sin((beatCycle / 0.22) * Math.PI) * 0.2
        : beatCycle < 0.45
          ? 1 + Math.sin(((beatCycle - 0.22) / 0.23) * Math.PI) * 0.14
          : 1;

    const heartSize = Math.min(this.width, this.height) * 0.24 * pulse;
    ctx.save();
    ctx.shadowColor = 'rgba(251, 191, 36, 0.65)';
    ctx.shadowBlur = 32;
    const grad = ctx.createRadialGradient(
      cx - heartSize * 0.15,
      cy - heartSize * 0.18,
      heartSize * 0.08,
      cx,
      cy,
      heartSize * 0.75
    );
    grad.addColorStop(0, '#fda4af');
    grad.addColorStop(0.45, '#e11d48');
    grad.addColorStop(1, '#881337');
    ctx.fillStyle = grad;
    this.drawHeartPath(cx, cy - heartSize * 0.48, heartSize);
    ctx.fill();
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = 'rgba(251, 191, 36, 0.85)';
    ctx.stroke();
    ctx.restore();
  }

  private drawLipstickMark(size: number, color: string): void {
    const ctx = this.ctx;
    ctx.fillStyle = color;
    // Upper lip cupid's bow
    ctx.beginPath();
    ctx.moveTo(-size * 0.52, 0);
    ctx.bezierCurveTo(-size * 0.34, -size * 0.34, -size * 0.1, -size * 0.28, 0, -size * 0.14);
    ctx.bezierCurveTo(size * 0.1, -size * 0.28, size * 0.34, -size * 0.34, size * 0.52, 0);
    ctx.bezierCurveTo(size * 0.22, -size * 0.06, -size * 0.22, -size * 0.06, -size * 0.52, 0);
    ctx.closePath();
    ctx.fill();

    // Lower plump lip
    ctx.beginPath();
    ctx.moveTo(-size * 0.48, size * 0.06);
    ctx.bezierCurveTo(-size * 0.24, size * 0.42, size * 0.24, size * 0.42, size * 0.48, size * 0.06);
    ctx.bezierCurveTo(size * 0.18, size * 0.14, -size * 0.18, size * 0.14, -size * 0.48, size * 0.06);
    ctx.closePath();
    ctx.fill();
  }

  private renderKiss(dt: number): void {
    const ctx = this.ctx;

    // Warm blush screen vignette
    const vignette = ctx.createRadialGradient(
      this.width / 2,
      this.height / 2,
      this.width * 0.2,
      this.width / 2,
      this.height / 2,
      Math.max(this.width, this.height) * 0.72
    );
    vignette.addColorStop(0, 'rgba(0,0,0,0)');
    vignette.addColorStop(1, 'rgba(225, 29, 72, 0.26)');
    ctx.fillStyle = vignette;
    ctx.fillRect(0, 0, this.width, this.height);

    for (const p of this.particles) {
      if (this.elapsed < p.delay) continue;
      p.life += dt;

      if (p.phase === 0) {
        // Lipstick kiss stamp with elastic pop-in scale
        const t = Math.min(1, p.life / 0.28);
        const elastic =
          t < 1
            ? Math.sin(-13 * (t + 1) * (Math.PI / 2)) * Math.pow(2, -10 * t) + 1
            : 1;
        const lifeFade = Math.max(0, 1 - Math.max(0, p.life - 1.2) / 1.1);

        ctx.save();
        ctx.translate(p.x, p.y + p.vy * p.life);
        ctx.rotate(p.rotation);
        ctx.scale(elastic, elastic);
        ctx.globalAlpha *= p.alpha * lifeFade;
        ctx.shadowColor = 'rgba(244, 63, 94, 0.55)';
        ctx.shadowBlur = 16;
        this.drawLipstickMark(p.size, p.color);
        ctx.restore();
      } else {
        // Rose-gold dust particle
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.vx *= 0.96;
        p.vy *= 0.96;
        const lifeFade = Math.max(0, 1 - p.life / p.maxLife);
        ctx.save();
        ctx.globalAlpha *= lifeFade;
        ctx.fillStyle = p.color;
        ctx.shadowColor = p.color;
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
    }
  }

  private renderGhost(dt: number): void {
    const ctx = this.ctx;

    // Cold cyan-violet screen chill tint
    ctx.fillStyle = 'rgba(14, 24, 38, 0.34)';
    ctx.fillRect(0, 0, this.width, this.height);

    // Rolling bottom atmospheric fog
    const fogGrad = ctx.createLinearGradient(0, this.height * 0.52, 0, this.height);
    fogGrad.addColorStop(0, 'rgba(103, 232, 249, 0)');
    fogGrad.addColorStop(0.55, 'rgba(103, 232, 249, 0.16)');
    fogGrad.addColorStop(1, 'rgba(167, 139, 250, 0.34)');
    ctx.fillStyle = fogGrad;
    ctx.fillRect(0, this.height * 0.5, this.width, this.height * 0.5);

    // Spectral wisps
    for (const p of this.particles) {
      if (this.elapsed < p.delay) continue;
      p.life += dt;
      p.x += Math.sin(this.elapsed * 2 + p.phase) * 28 * dt;
      p.y += p.vy * dt;
      if (p.y < -20) p.y = this.height + 10;

      ctx.save();
      ctx.globalAlpha *= p.alpha * (0.6 + 0.4 * Math.sin(this.elapsed * 3 + p.phase));
      ctx.fillStyle = p.color;
      ctx.shadowColor = p.color;
      ctx.shadowBlur = 16;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // Gliding translucent glowing-eyed ghosts
    for (const g of this.ghosts) {
      g.x += g.vx * dt;
      g.y = g.baseY + Math.sin(this.elapsed * 2.8 + g.phase) * 28;

      ctx.save();
      ctx.translate(g.x, g.y);
      ctx.scale(g.scale, g.scale);
      ctx.globalAlpha *= g.alpha;
      ctx.shadowColor = 'rgba(103, 232, 249, 0.7)';
      ctx.shadowBlur = 24;

      const bodyGrad = ctx.createLinearGradient(0, -45, 0, 55);
      bodyGrad.addColorStop(0, g.tint);
      bodyGrad.addColorStop(1, 'rgba(255, 255, 255, 0.05)');
      ctx.fillStyle = bodyGrad;

      ctx.beginPath();
      ctx.arc(0, -14, 34, Math.PI, 0, false);
      ctx.lineTo(34, 42);
      ctx.quadraticCurveTo(22, 54, 11, 42);
      ctx.quadraticCurveTo(0, 56, -11, 42);
      ctx.quadraticCurveTo(-22, 54, -34, 42);
      ctx.closePath();
      ctx.fill();

      // Glowing eerie eyes
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.ellipse(-11, -14, 5.5, 7, 0, 0, Math.PI * 2);
      ctx.ellipse(11, -14, 5.5, 7, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#67e8f9';
      ctx.beginPath();
      ctx.arc(-11, -14, 2.4, 0, Math.PI * 2);
      ctx.arc(11, -14, 2.4, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  private renderHorror(dt: number): void {
    const ctx = this.ctx;
    const cx = this.width / 2;
    const cy = this.height / 2;

    // Creeping darkness
    const darkAlpha =
      this.elapsed < 0.25 ? this.elapsed * 2.8 : Math.max(0.25, 0.82 - this.elapsed * 0.14);
    ctx.fillStyle = `rgba(4, 2, 6, ${darkAlpha})`;
    ctx.fillRect(0, 0, this.width, this.height);

    // Brief realistic thunderstorm lightning flashes
    const flashWindow =
      (this.elapsed > 0.04 && this.elapsed < 0.14) ||
      (this.elapsed > 0.22 && this.elapsed < 0.3) ||
      (this.elapsed > 0.86 && this.elapsed < 0.96);

    if (flashWindow) {
      ctx.fillStyle = 'rgba(226, 232, 240, 0.32)';
      ctx.fillRect(0, 0, this.width, this.height);
    }

    for (const bolt of this.bolts) {
      if (this.elapsed < bolt.triggerAt || this.elapsed > bolt.triggerAt + 0.35) {
        continue;
      }
      ctx.save();
      ctx.strokeStyle = '#f8fafc';
      ctx.shadowColor = '#60a5fa';
      ctx.shadowBlur = 22;
      ctx.lineWidth = 3;
      ctx.beginPath();
      bolt.segments.forEach((pt, idx) => {
        if (idx === 0) ctx.moveTo(pt.x, pt.y);
        else ctx.lineTo(pt.x, pt.y);
      });
      ctx.stroke();
      ctx.restore();
    }

    // Emerging spectral skull silhouette & glowing crimson eyes
    const skullAlpha =
      this.elapsed < 0.4
        ? this.elapsed / 0.4
        : Math.max(0, 1 - (this.elapsed - 1.6) / 1.4);
    const skullScale = 0.85 + Math.min(0.45, this.elapsed * 0.22);
    const glitchOffsetX =
      this.elapsed < 0.9 ? Math.sin(this.elapsed * 65) * 6 : 0;

    if (skullAlpha > 0) {
      ctx.save();
      ctx.translate(cx + glitchOffsetX, cy - 12);
      ctx.scale(skullScale, skullScale);
      ctx.globalAlpha *= skullAlpha * 0.92;

      // Chromatic aberration skull glow
      ctx.shadowColor = '#ef4444';
      ctx.shadowBlur = 35;

      // Cranium
      const skullGrad = ctx.createRadialGradient(0, -18, 12, 0, 0, 96);
      skullGrad.addColorStop(0, 'rgba(226, 232, 240, 0.35)');
      skullGrad.addColorStop(0.65, 'rgba(51, 65, 85, 0.42)');
      skullGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = skullGrad;
      ctx.beginPath();
      ctx.arc(0, -16, 72, Math.PI * 0.85, Math.PI * 0.15, false);
      ctx.lineTo(42, 46);
      ctx.lineTo(-42, 46);
      ctx.closePath();
      ctx.fill();

      // Hollow eye sockets + piercing crimson irises
      [-26, 26].forEach((ex) => {
        ctx.fillStyle = '#020617';
        ctx.beginPath();
        ctx.ellipse(ex, -8, 16, 19, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#ef4444';
        ctx.shadowColor = '#ff0033';
        ctx.shadowBlur = 24;
        ctx.beginPath();
        ctx.arc(ex, -8, 6.2, 0, Math.PI * 2);
        ctx.fill();
      });

      // Nasal cavity
      ctx.fillStyle = '#020617';
      ctx.beginPath();
      ctx.moveTo(0, 12);
      ctx.lineTo(-9, 30);
      ctx.lineTo(9, 30);
      ctx.closePath();
      ctx.fill();

      ctx.restore();
    }

    // Drifting crimson embers in darkness
    for (const p of this.particles) {
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      ctx.save();
      ctx.globalAlpha *= 0.55;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  private renderRose(dt: number): void {
    const ctx = this.ctx;
    for (const p of this.particles) {
      if (this.elapsed < p.delay) continue;
      p.life += dt;
      p.x += p.vx * dt + Math.sin(this.elapsed * 2.1 + p.phase) * 42 * dt;
      p.y += p.vy * dt;
      p.rotation += p.vRot * dt;
      p.flip += p.vFlip * dt;

      if (p.y > this.height + 30) {
        p.y = -25;
        p.x = Math.random() * this.width;
      }

      const scaleY = Math.max(0.28, Math.abs(Math.cos(p.flip)));
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rotation);
      ctx.scale(1, scaleY);
      ctx.globalAlpha *= p.alpha;
      ctx.shadowColor = 'rgba(225, 29, 72, 0.35)';
      ctx.shadowBlur = 10;

      const grad = ctx.createLinearGradient(-p.size, -p.size, p.size, p.size);
      grad.addColorStop(0, p.color);
      grad.addColorStop(1, p.secondaryColor);
      ctx.fillStyle = grad;

      // Organic curved rose petal
      ctx.beginPath();
      ctx.moveTo(0, -p.size);
      ctx.bezierCurveTo(p.size * 0.9, -p.size * 0.6, p.size * 0.95, p.size * 0.5, 0, p.size);
      ctx.bezierCurveTo(-p.size * 0.95, p.size * 0.5, -p.size * 0.9, -p.size * 0.6, 0, -p.size);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
  }

  private renderStars(dt: number): void {
    const ctx = this.ctx;
    for (const p of this.particles) {
      if (this.elapsed < p.delay) continue;
      p.life += dt;

      if (p.phase >= 1) {
        // Twinkling stardust
        const twinkle = 0.25 + 0.75 * Math.abs(Math.sin(this.elapsed * 4 + p.phase));
        ctx.save();
        ctx.globalAlpha *= twinkle;
        ctx.fillStyle = p.color;
        ctx.shadowColor = '#fbbf24';
        ctx.shadowBlur = 10;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      } else {
        // Diagonal golden meteor with glowing trail
        p.trail.push({ x: p.x, y: p.y });
        if (p.trail.length > 16) p.trail.shift();
        p.x += p.vx * dt;
        p.y += p.vy * dt;

        if (p.trail.length > 1) {
          for (let i = 1; i < p.trail.length; i++) {
            const frac = i / p.trail.length;
            ctx.save();
            ctx.strokeStyle = p.secondaryColor;
            ctx.globalAlpha *= frac * 0.85;
            ctx.lineWidth = p.size * frac * 1.4;
            ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.moveTo(p.trail[i - 1].x, p.trail[i - 1].y);
            ctx.lineTo(p.trail[i].x, p.trail[i].y);
            ctx.stroke();
            ctx.restore();
          }
        }

        ctx.save();
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = '#fbbf24';
        ctx.shadowBlur = 18;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
    }
  }

  private renderFire(dt: number): void {
    const ctx = this.ctx;

    // Warm molten bottom edge vignette
    const glow = ctx.createLinearGradient(0, this.height * 0.45, 0, this.height);
    glow.addColorStop(0, 'rgba(249, 115, 22, 0)');
    glow.addColorStop(0.7, 'rgba(234, 88, 12, 0.22)');
    glow.addColorStop(1, 'rgba(220, 38, 38, 0.42)');
    ctx.fillStyle = glow;
    ctx.fillRect(0, this.height * 0.45, this.width, this.height * 0.55);

    for (const p of this.particles) {
      if (this.elapsed < p.delay) continue;
      p.life += dt;
      p.x += p.vx * dt + Math.sin(this.elapsed * 5 + p.phase) * 35 * dt;
      p.y += p.vy * dt;

      if (p.y < -20) {
        p.y = this.height + 10;
        p.x = Math.random() * this.width;
        p.life = 0;
      }

      const fade = Math.max(0, 1 - p.life / p.maxLife);
      ctx.save();
      ctx.globalAlpha *= fade;
      ctx.fillStyle = p.color;
      ctx.shadowColor = p.color;
      ctx.shadowBlur = 14;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  private renderFireflies(dt: number): void {
    const ctx = this.ctx;
    for (const p of this.particles) {
      if (this.elapsed < p.delay) continue;
      p.vx += Math.cos(this.elapsed * 1.9 + p.phase) * 32 * dt;
      p.vy += Math.sin(this.elapsed * 2.3 + p.phase) * 26 * dt;
      p.vx = Math.max(-75, Math.min(75, p.vx));
      p.vy = Math.max(-65, Math.min(65, p.vy));

      p.trail.push({ x: p.x, y: p.y });
      if (p.trail.length > 12) p.trail.shift();

      p.x += p.vx * dt;
      p.y += p.vy * dt;

      if (p.x < 12 || p.x > this.width - 12) p.vx *= -1;
      if (p.y < 12 || p.y > this.height - 12) p.vy *= -1;

      const glowPulse = 0.45 + 0.55 * Math.sin(this.elapsed * 4.2 + p.phase);

      if (p.trail.length > 1) {
        for (let i = 1; i < p.trail.length; i++) {
          const frac = i / p.trail.length;
          ctx.save();
          ctx.strokeStyle = p.color;
          ctx.globalAlpha *= frac * 0.45 * glowPulse;
          ctx.lineWidth = p.size * 0.65;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(p.trail[i - 1].x, p.trail[i - 1].y);
          ctx.lineTo(p.trail[i].x, p.trail[i].y);
          ctx.stroke();
          ctx.restore();
        }
      }

      ctx.save();
      ctx.globalAlpha *= glowPulse;
      ctx.fillStyle = p.color;
      ctx.shadowColor = p.color;
      ctx.shadowBlur = 18;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }
}

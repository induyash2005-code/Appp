/* ============================================================================
 * PROCEDURAL WEB AUDIO SYNTHESIZER & HAPTIC VIBRATION ENGINE
 * Zero external audio assets required — generates tactile glass UI chimes,
 * realistic lub-dub heartbeats, horror rumbles, ghostly wind, and game FX.
 * ============================================================================ */

import type { FxType } from '../types/vault';

class ProceduralAudioEngine {
  private ctx: AudioContext | null = null;
  private soundEnabled = true;
  private vibrationEnabled = true;
  private ringtoneTimer: number | null = null;

  public configure(soundEnabled: boolean, vibrationEnabled: boolean): void {
    this.soundEnabled = soundEnabled;
    this.vibrationEnabled = vibrationEnabled;
  }

  private getContext(): AudioContext | null {
    if (!this.soundEnabled || typeof window === 'undefined') return null;
    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext })
          .webkitAudioContext;
      if (!AudioCtx) return null;
      if (!this.ctx) {
        this.ctx = new AudioCtx();
      }
      if (this.ctx.state === 'suspended') {
        void this.ctx.resume();
      }
      return this.ctx;
    } catch {
      return null;
    }
  }

  public vibrate(pattern: number | number[]): void {
    if (!this.vibrationEnabled) return;
    try {
      if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
        navigator.vibrate(pattern);
      }
    } catch {
      // Ignore on unsupported browsers
    }
  }

  /* ---------------- UI & MESSAGING SOUNDS ---------------- */

  public playCalcTap(accent = false): void {
    this.vibrate(8);
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(accent ? 540 : 410, now);
    osc.frequency.exponentialRampToValueAtTime(accent ? 320 : 210, now + 0.045);

    gain.gain.setValueAtTime(0.06, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.055);
  }

  public playVaultUnlock(): void {
    this.vibrate([18, 40, 26]);
    const ctx = this.getContext();
    if (!ctx) return;

    const notes = [523.25, 659.25, 783.99, 1046.5];
    const now = ctx.currentTime;

    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      const t = now + idx * 0.065;
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0.001, t);
      gain.gain.linearRampToValueAtTime(0.085, t + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.34);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.36);
    });
  }

  public playMessageSend(): void {
    this.vibrate(10);
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(480, now);
    osc.frequency.exponentialRampToValueAtTime(780, now + 0.09);

    gain.gain.setValueAtTime(0.055, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.11);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.12);
  }

  public playMessageReceive(): void {
    this.vibrate([12, 30, 12]);
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    [659.25, 880].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const t = now + i * 0.075;
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0.06, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.2);
    });
  }

  public playGameTap(): void {
    this.vibrate(14);
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(520, now);
    osc.frequency.exponentialRampToValueAtTime(280, now + 0.07);
    gain.gain.setValueAtTime(0.07, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.09);
  }

  public playGameWin(): void {
    this.vibrate([24, 45, 32, 45, 50]);
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    [523.25, 659.25, 783.99, 1046.5].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const t = now + i * 0.085;
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0.08, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.37);
    });
  }

  /* ---------------- RINGTONE ---------------- */

  public startRingtone(): void {
    this.stopRingtone();
    const playPulse = () => {
      this.vibrate([120, 120, 120]);
      const ctx = this.getContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      [698.46, 880, 1046.5].forEach((f, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const t = now + idx * 0.14;
        osc.type = 'sine';
        osc.frequency.setValueAtTime(f, t);
        gain.gain.setValueAtTime(0.065, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t);
        osc.stop(t + 0.26);
      });
    };
    playPulse();
    this.ringtoneTimer = window.setInterval(playPulse, 2100);
  }

  public stopRingtone(): void {
    if (this.ringtoneTimer !== null) {
      window.clearInterval(this.ringtoneTimer);
      this.ringtoneTimer = null;
    }
  }

  /* ---------------- 8 FULLSCREEN FX SOUNDSCAPES ---------------- */

  public playFxSound(fx: FxType): void {
    switch (fx) {
      case 'heart':
        this.playHeartbeatFx();
        break;
      case 'kiss':
        this.playKissFx();
        break;
      case 'ghost':
        this.playGhostFx();
        break;
      case 'horror':
        this.playHorrorFx();
        break;
      case 'rose':
        this.playRoseFx();
        break;
      case 'stars':
        this.playStarsFx();
        break;
      case 'fire':
        this.playFireFx();
        break;
      case 'fireflies':
        this.playFirefliesFx();
        break;
    }
  }

  private playHeartbeatFx(): void {
    // Synced lub-dub vibration pattern
    this.vibrate([45, 95, 70, 320, 45, 95, 70, 320, 45, 95, 70]);
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const beats = [0, 0.56, 1.12, 1.68];
    beats.forEach((offset) => {
      // "Lub"
      this.triggerThump(ctx, now + offset, 68, 36, 0.28, 0.12);
      // "Dub"
      this.triggerThump(ctx, now + offset + 0.16, 82, 42, 0.34, 0.14);
    });
  }

  private triggerThump(
    ctx: AudioContext,
    startTime: number,
    fStart: number,
    fEnd: number,
    amp: number,
    dur: number
  ): void {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(fStart, startTime);
    osc.frequency.exponentialRampToValueAtTime(fEnd, startTime + dur);

    gain.gain.setValueAtTime(0.001, startTime);
    gain.gain.linearRampToValueAtTime(amp, startTime + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.001, startTime + dur);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(startTime);
    osc.stop(startTime + dur + 0.02);
  }

  private playKissFx(): void {
    this.vibrate([20, 60, 20, 80, 25]);
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const chimeNotes = [783.99, 987.77, 1174.66, 1567.98];
    chimeNotes.forEach((freq, idx) => {
      const t = now + idx * 0.14;
      // Soft pop
      const pop = ctx.createOscillator();
      const popGain = ctx.createGain();
      pop.type = 'sine';
      pop.frequency.setValueAtTime(320 + idx * 50, t);
      pop.frequency.exponentialRampToValueAtTime(720 + idx * 80, t + 0.06);
      popGain.gain.setValueAtTime(0.08, t);
      popGain.gain.exponentialRampToValueAtTime(0.001, t + 0.07);
      pop.connect(popGain);
      popGain.connect(ctx.destination);
      pop.start(t);
      pop.stop(t + 0.08);

      // Shimmer bell
      const bell = ctx.createOscillator();
      const bellGain = ctx.createGain();
      bell.type = 'triangle';
      bell.frequency.setValueAtTime(freq, t + 0.02);
      bellGain.gain.setValueAtTime(0.055, t + 0.02);
      bellGain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
      bell.connect(bellGain);
      bellGain.connect(ctx.destination);
      bell.start(t + 0.02);
      bell.stop(t + 0.37);
    });
  }

  private playGhostFx(): void {
    this.vibrate([30, 120, 45, 160, 30]);
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    // Eerie theremin/wind glide
    const osc = ctx.createOscillator();
    const lfo = ctx.createOscillator();
    const lfoGain = ctx.createGain();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(340, now);
    osc.frequency.linearRampToValueAtTime(510, now + 0.7);
    osc.frequency.linearRampToValueAtTime(270, now + 1.6);
    osc.frequency.linearRampToValueAtTime(390, now + 2.4);

    lfo.frequency.setValueAtTime(5.5, now);
    lfoGain.gain.setValueAtTime(16, now);
    lfo.connect(lfoGain);
    lfoGain.connect(osc.frequency);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.075, now + 0.45);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 2.5);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    lfo.start(now);
    osc.stop(now + 2.55);
    lfo.stop(now + 2.55);

    // Filtered wind breath noise
    this.triggerFilteredNoise(ctx, now, 2.3, 420, 'bandpass', 0.06);
  }

  private playHorrorFx(): void {
    // Rapid haptic shudder
    this.vibrate([80, 40, 110, 40, 90, 50, 140]);
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    // Deep ominous sub-bass rumble
    const sub = ctx.createOscillator();
    const subGain = ctx.createGain();
    sub.type = 'sawtooth';
    sub.frequency.setValueAtTime(58, now);
    sub.frequency.exponentialRampToValueAtTime(32, now + 1.8);

    const lowpass = ctx.createBiquadFilter();
    lowpass.type = 'lowpass';
    lowpass.frequency.setValueAtTime(180, now);

    subGain.gain.setValueAtTime(0.001, now);
    subGain.gain.linearRampToValueAtTime(0.2, now + 0.06);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 2.0);

    sub.connect(lowpass);
    lowpass.connect(subGain);
    subGain.connect(ctx.destination);
    sub.start(now);
    sub.stop(now + 2.05);

    // Dissonant tritone sting
    [311.13, 440, 622.25].forEach((freq) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, now + 0.04);
      osc.frequency.linearRampToValueAtTime(freq * 0.94, now + 0.85);
      gain.gain.setValueAtTime(0.045, now + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.95);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + 0.04);
      osc.stop(now + 1.0);
    });

    // Lightning crackle burst
    this.triggerFilteredNoise(ctx, now, 0.32, 2400, 'highpass', 0.14);
  }

  private playRoseFx(): void {
    this.vibrate([15, 50, 20]);
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const harp = [523.25, 659.25, 783.99, 987.77, 1318.51];
    harp.forEach((freq, idx) => {
      const t = now + idx * 0.095;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0.05, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.55);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.58);
    });
  }

  private playStarsFx(): void {
    this.vibrate([12, 40, 18, 40, 22]);
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    [880, 1174.66, 1396.91, 1760].forEach((freq, i) => {
      const t = now + i * 0.12;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq * 1.15, t);
      osc.frequency.exponentialRampToValueAtTime(freq, t + 0.18);
      gain.gain.setValueAtTime(0.055, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.42);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.45);
    });
  }

  private playFireFx(): void {
    this.vibrate([35, 35, 45, 50]);
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    this.triggerFilteredNoise(ctx, now, 1.8, 950, 'bandpass', 0.09);
    this.triggerThump(ctx, now, 120, 52, 0.14, 0.24);
  }

  private playFirefliesFx(): void {
    this.vibrate([10, 60, 14]);
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    [1046.5, 1318.51, 1567.98, 2093].forEach((freq, idx) => {
      const t = now + idx * 0.16;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0.04, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.48);
    });
  }

  private triggerFilteredNoise(
    ctx: AudioContext,
    startTime: number,
    duration: number,
    cutoff: number,
    filterType: BiquadFilterType,
    amplitude: number
  ): void {
    const sampleRate = ctx.sampleRate;
    const frameCount = Math.max(1, Math.floor(sampleRate * duration));
    const buffer = ctx.createBuffer(1, frameCount, sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < frameCount; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const source = ctx.createBufferSource();
    source.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = filterType;
    filter.frequency.setValueAtTime(cutoff, startTime);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.001, startTime);
    gain.gain.linearRampToValueAtTime(amplitude, startTime + 0.06);
    gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);

    source.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    source.start(startTime);
    source.stop(startTime + duration + 0.02);
  }
}

export const audioEngine = new ProceduralAudioEngine();

/* ============================================================================
 * SMART CHAT TEXT FX TRIGGER DETECTOR & CATALOG
 * Automatically detects emojis & multilingual keywords to fire fullscreen FX.
 * ============================================================================ */

import type { FxType } from '../types/vault';

export interface FxCatalogItem {
  id: FxType;
  emoji: string;
  label: string;
  subtitle: string;
  accentColor: string;
}

export const FX_CATALOG: FxCatalogItem[] = [
  {
    id: 'heart',
    emoji: '❤️',
    label: 'Royal Heartbeat',
    subtitle: 'Crimson-gold pulse & floating hearts',
    accentColor: '#fb7185',
  },
  {
    id: 'kiss',
    emoji: '💋',
    label: 'Kiss Storm',
    subtitle: 'Ruby lipstick stamps & rose dust',
    accentColor: '#f43f5e',
  },
  {
    id: 'ghost',
    emoji: '👻',
    label: 'Bhoot Haunting',
    subtitle: 'Rolling mist & spectral wisps',
    accentColor: '#67e8f9',
  },
  {
    id: 'horror',
    emoji: '💀',
    label: 'Horror Scare',
    subtitle: 'Lightning flash, glitch & crimson eyes',
    accentColor: '#ef4444',
  },
  {
    id: 'rose',
    emoji: '🌹',
    label: 'Rose Petal Rain',
    subtitle: '3D tumbling velvet rose petals',
    accentColor: '#e11d48',
  },
  {
    id: 'stars',
    emoji: '🌠',
    label: 'Shooting Stars',
    subtitle: 'Diagonal golden meteor trails',
    accentColor: '#fbbf24',
  },
  {
    id: 'fire',
    emoji: '🔥',
    label: 'Golden Embers',
    subtitle: 'Incandescent sparks & molten glow',
    accentColor: '#f97316',
  },
  {
    id: 'fireflies',
    emoji: '🦋',
    label: 'Fireflies',
    subtitle: 'Bioluminescent golden trails',
    accentColor: '#fde047',
  },
];

interface TriggerRule {
  fx: FxType;
  emojis: string[];
  keywords: RegExp[];
}

const TRIGGER_RULES: TriggerRule[] = [
  {
    fx: 'horror',
    emojis: ['💀', '☠️', '👹', '🩸'],
    keywords: [/\bscary\b/i, /\bdarawna\b/i, /\bhorror\b/i, /\bnightmare\b/i, /\bjumpscare\b/i],
  },
  {
    fx: 'ghost',
    emojis: ['👻'],
    keywords: [/\bghost\b/i, /\bbhoot\b/i, /\bhaunt(?:ed|ing)?\b/i, /\bspooky\b/i, /\bphantom\b/i],
  },
  {
    fx: 'kiss',
    emojis: ['💋', '😘'],
    keywords: [/\bkiss(?:es)?\b/i, /\bchumma\b/i, /\bmuah+\b/i, /\bsmooch\b/i],
  },
  {
    fx: 'rose',
    emojis: ['🌹', '🥀'],
    keywords: [/\brose(?:s)?\b/i, /\bgulab\b/i, /\bpetals?\b/i],
  },
  {
    fx: 'fire',
    emojis: ['🔥', '❤️‍🔥'],
    keywords: [/\bfire\b/i, /\baag\b/i, /\bflame(?:s)?\b/i, /\bember(?:s)?\b/i, /\blit\b/i],
  },
  {
    fx: 'stars',
    emojis: ['🌠', '✨', '🌟'],
    keywords: [/\bshooting star(?:s)?\b/i, /\bmeteor(?:s)?\b/i, /\bstardust\b/i, /\bsitara\b/i],
  },
  {
    fx: 'fireflies',
    emojis: ['🦋', '🪲'],
    keywords: [/\bfirefl(?:y|ies)\b/i, /\bjugnu\b/i, /\bbutterfl(?:y|ies)\b/i],
  },
  {
    fx: 'heart',
    emojis: ['❤️', '♥️', '💖', '💘', '💕', '💓', '💗', '❣️'],
    keywords: [/\blove\b/i, /\bdil\b/i, /\bheart(?:beat)?\b/i, /\bpyaar\b/i, /\bishq\b/i],
  },
];

/**
 * Inspects outgoing or incoming chat message text for FX trigger emojis or keywords.
 * Prioritizes explicit emojis first, then keyword regex matches.
 */
export function detectFxTrigger(text: string): FxType | null {
  if (!text || !text.trim()) return null;

  for (const rule of TRIGGER_RULES) {
    for (const emoji of rule.emojis) {
      if (text.includes(emoji)) {
        return rule.fx;
      }
    }
  }

  for (const rule of TRIGGER_RULES) {
    for (const rx of rule.keywords) {
      if (rx.test(text)) {
        return rule.fx;
      }
    }
  }

  return null;
}

export function getFxMeta(fx: FxType): FxCatalogItem {
  return FX_CATALOG.find((item) => item.id === fx) ?? FX_CATALOG[0];
}

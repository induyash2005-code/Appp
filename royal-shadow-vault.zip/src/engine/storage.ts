/* ============================================================================
 * ZERO-SERVER LOCALSTORAGE PERSISTENCE & IMAGE COMPRESSION ENGINE
 * ============================================================================ */

import type {
  ChatMessage,
  FriendContact,
  FriendRequest,
  VaultSettings,
  VaultUser,
} from '../types/vault';

const STORAGE_KEYS = {
  USER: 'rsv_user_v1',
  FRIENDS: 'rsv_friends_v1',
  REQUESTS: 'rsv_requests_v1',
  MESSAGES: 'rsv_messages_v1',
  SETTINGS: 'rsv_settings_v1',
} as const;

export const DEFAULT_SETTINGS: VaultSettings = {
  pin: '1904',
  themeId: 'royal-burgundy',
  customWallpaper: null,
  glassDimmer: 34,
  autoVanishSec: 0,
  fontSize: 'normal',
  autoLockMinutes: 0,
  soundEnabled: true,
  vibrationEnabled: true,
};

function safeReadJson<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function safeWriteJson<T>(key: string, value: T): void {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Handle quota exceeded gracefully without crashing UI
  }
}

export function generateFourDigitCode(exclude?: Set<string>): string {
  for (let attempt = 0; attempt < 50; attempt++) {
    const n = Math.floor(1000 + Math.random() * 9000);
    const code = String(n);
    if (!exclude || !exclude.has(code)) {
      return code;
    }
  }
  return String(Math.floor(1000 + Math.random() * 9000));
}

export async function hashVaultPassword(password: string): Promise<string> {
  const trimmed = password.trim();
  if (typeof window !== 'undefined' && window.crypto?.subtle) {
    try {
      const encoded = new TextEncoder().encode(`rsv_salt_v1:${trimmed}`);
      const digest = await window.crypto.subtle.digest('SHA-256', encoded);
      return Array.from(new Uint8Array(digest))
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');
    } catch {
      // Fallback below
    }
  }
  // Deterministic non-subtle fallback for insecure origins
  let hash = 2166136261;
  for (let i = 0; i < trimmed.length; i++) {
    hash ^= trimmed.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return `fnv_${(hash >>> 0).toString(16)}`;
}

/* ---------------- USER ACCOUNT ---------------- */

export function loadVaultUser(): VaultUser | null {
  return safeReadJson<VaultUser | null>(STORAGE_KEYS.USER, null);
}

export function saveVaultUser(user: VaultUser): void {
  safeWriteJson(STORAGE_KEYS.USER, user);
}

export function clearVaultUser(): void {
  try {
    window.localStorage.removeItem(STORAGE_KEYS.USER);
  } catch {
    // ignore
  }
}

/* ---------------- SETTINGS ---------------- */

export function loadVaultSettings(): VaultSettings {
  const stored = safeReadJson<Partial<VaultSettings>>(STORAGE_KEYS.SETTINGS, {});
  return {
    ...DEFAULT_SETTINGS,
    ...stored,
    pin: stored.pin && stored.pin.length >= 3 ? stored.pin : DEFAULT_SETTINGS.pin,
  };
}

export function saveVaultSettings(settings: VaultSettings): void {
  safeWriteJson(STORAGE_KEYS.SETTINGS, settings);
}

/* ---------------- FRIENDS & REQUESTS ---------------- */

export function loadFriends(): FriendContact[] {
  return safeReadJson<FriendContact[]>(STORAGE_KEYS.FRIENDS, []);
}

export function saveFriends(friends: FriendContact[]): void {
  safeWriteJson(STORAGE_KEYS.FRIENDS, friends);
}

export function loadFriendRequests(): FriendRequest[] {
  return safeReadJson<FriendRequest[]>(STORAGE_KEYS.REQUESTS, []);
}

export function saveFriendRequests(requests: FriendRequest[]): void {
  safeWriteJson(STORAGE_KEYS.REQUESTS, requests);
}

/* ---------------- CHAT MESSAGES ---------------- */

export function loadMessages(): ChatMessage[] {
  const now = Date.now();
  const list = safeReadJson<ChatMessage[]>(STORAGE_KEYS.MESSAGES, []);
  // Purge expired auto-vanish messages on load
  return list.filter((msg) => !msg.expiresAt || msg.expiresAt > now);
}

export function saveMessages(messages: ChatMessage[]): void {
  const now = Date.now();
  const pruned = messages.filter((msg) => !msg.expiresAt || msg.expiresAt > now);
  safeWriteJson(STORAGE_KEYS.MESSAGES, pruned.slice(-400));
}

/* ---------------- IMAGE & AVATAR COMPRESSION ---------------- */

export function generateMonogramAvatar(name: string): string {
  const canvas = document.createElement('canvas');
  canvas.width = 160;
  canvas.height = 160;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  const grad = ctx.createLinearGradient(0, 0, 160, 160);
  grad.addColorStop(0, '#3a1628');
  grad.addColorStop(0.55, '#1d0d17');
  grad.addColorStop(1, '#10080d');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 160, 160);

  ctx.strokeStyle = 'rgba(251, 191, 36, 0.55)';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.arc(80, 80, 74, 0, Math.PI * 2);
  ctx.stroke();

  const initial = (name.trim()[0] || 'R').toUpperCase();
  ctx.fillStyle = '#fde68a';
  ctx.font = '600 66px -apple-system, BlinkMacSystemFont, system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(initial, 80, 84);

  return canvas.toDataURL('image/jpeg', 0.84);
}

export function compressImageFile(
  file: File,
  maxDimension: number,
  quality: number
): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read image file'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Invalid image format'));
      img.onload = () => {
        const scale = Math.min(
          1,
          maxDimension / Math.max(img.width || 1, img.height || 1)
        );
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas context unavailable'));
          return;
        }
        ctx.drawImage(img, 0, 0, w, h);
        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        img.src = '';
        resolve(dataUrl);
      };
      img.src = String(reader.result || '');
    };
    reader.readAsDataURL(file);
  });
}

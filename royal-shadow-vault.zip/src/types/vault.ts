/* ============================================================================
 * ROYAL SHADOW VAULT — DOMAIN TYPES & P2P PROTOCOL DEFINITIONS
 * ============================================================================ */

export type ThemeId =
  | 'royal-burgundy'
  | 'lunar-moon'
  | 'blue-earth'
  | 'starry-sky'
  | 'emerald-forest'
  | 'sakura-night'
  | 'royal-sunset';

export type AutoVanishSeconds = 0 | 10 | 30 | 60;
export type AutoLockMinutes = 0 | 2 | 5;
export type FontSizeOption = 'small' | 'normal' | 'large';

export type FxType =
  | 'heart'
  | 'kiss'
  | 'ghost'
  | 'horror'
  | 'rose'
  | 'stars'
  | 'fire'
  | 'fireflies';

export type VaultScreen = 'calculator' | 'account-gate' | 'home' | 'chat';

export interface VaultUser {
  id: string;
  displayName: string;
  passwordHash: string;
  code: string; // 4-digit P2P code ("1000" - "9999")
  avatarDataUrl: string;
  createdAt: number;
}

export interface FriendContact {
  code: string;
  displayName: string;
  nickname?: string;
  avatarDataUrl: string;
  addedAt: number;
  lastSeenAt?: number;
  muted?: boolean;
}

export interface FriendRequest {
  id: string;
  fromCode: string;
  fromName: string;
  fromAvatar: string;
  timestamp: number;
  direction: 'incoming' | 'outgoing';
}

export type MessageKind = 'text' | 'photo' | 'view-once' | 'voice' | 'fx-pulse';

export interface MessageReplyRef {
  id: string;
  senderCode: string;
  preview: string;
}

export interface ChatReaction {
  emoji: string;
  byCode: string;
}

export interface ChatMessage {
  id: string;
  peerCode: string; // Conversation partner's 4-digit code
  senderCode: string;
  kind: MessageKind;
  text?: string;
  mediaDataUrl?: string; // Compressed data URL (wiped from memory & storage on view-once destroy)
  voiceDurationSec?: number;
  fxType?: FxType;
  timestamp: number;
  seen: boolean;
  edited?: boolean;
  unsent?: boolean;
  viewOnceConsumed?: boolean;
  vanishAfterSec: AutoVanishSeconds;
  expiresAt?: number;
  replyTo?: MessageReplyRef;
  reactions: ChatReaction[];
}

export interface VaultSettings {
  pin: string;
  themeId: ThemeId;
  customWallpaper: string | null;
  glassDimmer: number; // 0 to 85 (%)
  autoVanishSec: AutoVanishSeconds;
  fontSize: FontSizeOption;
  autoLockMinutes: AutoLockMinutes;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
}

/* ---------------- P2P PROTOCOL PACKETS ---------------- */

export type RpsChoice = 'rock' | 'paper' | 'scissors';

export type GameActivityTab = 'rps' | 'ttt' | 'connect4' | 'codraw' | 'watch';

export interface CoDrawStroke {
  id: string;
  color: string;
  width: number;
  points: Array<{ x: number; y: number }>; // Normalized [0..1] coordinates
}

export interface WatchSyncState {
  sourceType: 'youtube' | 'audio';
  youtubeId?: string;
  audioName?: string;
  audioDataUrl?: string;
  playing: boolean;
  currentTimeSec: number;
  updatedAt: number;
  updatedByCode: string;
}

export type P2PPacket =
  | {
      type: 'presence_hello';
      fromCode: string;
      displayName: string;
      avatarDataUrl: string;
      sentAt: number;
    }
  | {
      type: 'presence_ping';
      fromCode: string;
      sentAt: number;
    }
  | {
      type: 'friend_request';
      requestId: string;
      fromCode: string;
      fromName: string;
      fromAvatar: string;
      timestamp: number;
    }
  | {
      type: 'friend_accept';
      requestId: string;
      fromCode: string;
      fromName: string;
      fromAvatar: string;
      timestamp: number;
    }
  | {
      type: 'friend_decline';
      requestId: string;
      fromCode: string;
    }
  | {
      type: 'chat_message';
      message: ChatMessage;
    }
  | {
      type: 'chat_typing';
      fromCode: string;
      isTyping: boolean;
    }
  | {
      type: 'chat_seen';
      fromCode: string;
      messageIds: string[];
    }
  | {
      type: 'chat_react';
      fromCode: string;
      messageId: string;
      emoji: string;
    }
  | {
      type: 'chat_edit';
      fromCode: string;
      messageId: string;
      newText: string;
    }
  | {
      type: 'chat_unsend';
      fromCode: string;
      messageId: string;
    }
  | {
      type: 'chat_view_once_consumed';
      fromCode: string;
      messageId: string;
    }
  | {
      type: 'chat_clear_both';
      fromCode: string;
    }
  | {
      type: 'fx_trigger';
      fromCode: string;
      fx: FxType;
      timestamp: number;
    }
  | {
      type: 'rps_lock';
      fromCode: string;
      roundId: number;
      choice: RpsChoice;
    }
  | {
      type: 'rps_reset';
      fromCode: string;
      roundId: number;
    }
  | {
      type: 'ttt_move';
      fromCode: string;
      index: number;
      symbol: 'X' | 'O';
    }
  | {
      type: 'ttt_reset';
      fromCode: string;
      startingRole: 'host' | 'guest';
    }
  | {
      type: 'c4_move';
      fromCode: string;
      col: number;
      disc: 1 | 2;
    }
  | {
      type: 'c4_reset';
      fromCode: string;
      startingRole: 'host' | 'guest';
    }
  | {
      type: 'codraw_stroke';
      fromCode: string;
      stroke: CoDrawStroke;
    }
  | {
      type: 'codraw_clear';
      fromCode: string;
    }
  | {
      type: 'watch_sync';
      fromCode: string;
      state: WatchSyncState;
    }
  | {
      type: 'call_signal';
      fromCode: string;
      action: 'ringing' | 'accepted' | 'declined' | 'ended' | 'invite_third';
      video: boolean;
      targetThirdCode?: string;
    };

export type PeerConnectionStatus = 'offline' | 'connecting' | 'ready' | 'error';

export interface ActiveCallSession {
  callId: string;
  mode: 'voice' | 'video';
  direction: 'outgoing' | 'incoming';
  status: 'ringing' | 'connected' | 'ended';
  participants: Array<{
    code: string;
    displayName: string;
    avatarDataUrl: string;
    stream?: MediaStream;
  }>;
  startedAt: number | null;
  muted: boolean;
  cameraOff: boolean;
  facingMode: 'user' | 'environment';
  minimized: boolean;
  permissionWarning?: string;
}

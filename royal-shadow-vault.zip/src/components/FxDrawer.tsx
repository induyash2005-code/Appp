/* ============================================================================
 * INTERACTIVE FULLSCREEN FX EMOJI DRAWER
 * - Zero static emoji clutter; every icon launches a synchronized fullscreen
 *   Canvas 2D + CSS + Web Audio + Haptic animation across both devices.
 * ============================================================================ */

import React from 'react';
import { Sparkles, X } from 'lucide-react';
import { FX_CATALOG } from '../engine/fxTriggers';
import type { FxType } from '../types/vault';

interface FxDrawerProps {
  onClose: () => void;
  onTriggerFx: (fx: FxType) => void;
}

export const FxDrawer: React.FC<FxDrawerProps> = ({ onClose, onTriggerFx }) => {
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Animated FX Emoji Drawer"
      className="fixed inset-0 z-40 flex items-end justify-center bg-black/50 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="glass-surface-elevated glass-specular-rim sheet-enter w-full max-w-[540px] rounded-t-[30px] p-5 pb-7 flex flex-col gap-4"
      >
        <div className="w-10 h-1 rounded-full bg-white/20 mx-auto" />

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-4 h-4 text-amber-300" />
            <div>
              <h2 className="text-sm font-semibold text-white">
                Fullscreen Live FX
              </h2>
              <p className="text-[11px] text-white/55">
                Plays simultaneously on both screens with Web Audio &amp; haptics
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close FX Drawer"
            className="w-9 h-9 rounded-full bg-white/[0.06] hover:bg-white/[0.12] flex items-center justify-center text-white/75"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {FX_CATALOG.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                onTriggerFx(item.id);
                onClose();
              }}
              className="group glass-subtle rounded-2xl p-3 flex flex-col items-center text-center gap-1.5 hover:bg-white/[0.11] active:scale-95 transition-all"
            >
              <span
                className="text-2xl leading-none transition-transform duration-200 group-hover:scale-110"
                aria-hidden="true"
              >
                {item.emoji}
              </span>
              <span className="text-xs font-medium text-white truncate w-full">
                {item.label}
              </span>
              <span className="text-[10px] text-white/50 leading-tight line-clamp-2">
                {item.subtitle}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

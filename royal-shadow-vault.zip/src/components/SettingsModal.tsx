/* ============================================================================
 * CLEAN SETTINGS PANEL (7 ROYAL & SCENIC THEMES, DIMMER, WALLPAPER, PIN, TIMERS)
 * ============================================================================ */

import React, { useRef, useState } from 'react';
import { ImagePlus, RotateCcw, Volume2, VolumeX, Vibrate, X } from 'lucide-react';
import type {
  AutoLockMinutes,
  AutoVanishSeconds,
  FontSizeOption,
  VaultSettings,
} from '../types/vault';
import { THEME_LIST } from './ThemeBackdrop';
import { compressImageFile } from '../engine/storage';

interface SettingsModalProps {
  settings: VaultSettings;
  onUpdateSettings: (next: VaultSettings) => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onClose,
}) => {
  const [pinDraft, setPinDraft] = useState(settings.pin);
  const [pinNotice, setPinNotice] = useState('');
  const wallpaperInputRef = useRef<HTMLInputElement | null>(null);

  const handlePinSave = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = pinDraft.replace(/\D/g, '');
    if (cleaned.length < 4 || cleaned.length > 8) {
      setPinNotice('PIN must be 4–8 digits.');
      return;
    }
    onUpdateSettings({ ...settings, pin: cleaned });
    setPinNotice('Calculator PIN updated.');
  };

  const handleWallpaperUpload = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImageFile(file, 1280, 0.78);
      onUpdateSettings({ ...settings, customWallpaper: compressed });
    } catch {
      // ignore bad image
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Vault Settings"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm sm:px-4"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="glass-surface-elevated glass-specular-rim sheet-enter w-full max-w-[540px] max-h-[88vh] rounded-t-[30px] sm:rounded-[30px] flex flex-col overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/[0.08] shrink-0">
          <h2 className="text-base font-semibold text-white">Settings</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Settings"
            className="w-9 h-9 rounded-full bg-white/[0.06] hover:bg-white/[0.12] flex items-center justify-center text-white/75"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-6 overflow-y-auto vault-scroll flex flex-col gap-6">
          {/* 1. 7 Scenic Artwork Themes */}
          <section className="flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-semibold text-white/80">
                Royal &amp; Scenic Themes
              </h3>
              <div className="flex items-center gap-2">
                {settings.customWallpaper && (
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateSettings({ ...settings, customWallpaper: null })
                    }
                    className="text-[11px] text-amber-300 hover:text-amber-200 flex items-center gap-1"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Clear Wallpaper</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => wallpaperInputRef.current?.click()}
                  className="text-[11px] px-2.5 py-1 rounded-lg bg-white/[0.08] hover:bg-white/[0.14] text-white/85 flex items-center gap-1.5"
                >
                  <ImagePlus className="w-3.5 h-3.5 text-amber-300" />
                  <span>Gallery Wallpaper</span>
                </button>
                <input
                  ref={wallpaperInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleWallpaperUpload}
                  className="hidden"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {THEME_LIST.map((theme) => {
                const active =
                  !settings.customWallpaper && settings.themeId === theme.id;
                return (
                  <button
                    key={theme.id}
                    type="button"
                    onClick={() =>
                      onUpdateSettings({
                        ...settings,
                        themeId: theme.id,
                        customWallpaper: null,
                      })
                    }
                    className={`flex items-center gap-3 p-3 rounded-2xl border text-left transition-all ${
                      active
                        ? 'bg-amber-400/15 border-amber-300/60 shadow-[0_0_20px_rgba(251,191,36,0.16)]'
                        : 'bg-white/[0.04] border-white/[0.08] hover:bg-white/[0.08]'
                    }`}
                  >
                    <span
                      className="w-9 h-9 rounded-xl shrink-0 border border-white/15"
                      style={{
                        background: `linear-gradient(135deg, ${theme.swatch[0]}, ${theme.swatch[1]} 60%, ${theme.swatch[2]})`,
                      }}
                    />
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-semibold text-white truncate">
                        {theme.name}
                      </div>
                      <div className="text-[11px] text-white/50 truncate">
                        {theme.subtitle}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </section>

          {/* 2. Glass Dimmer Slider */}
          <section className="flex flex-col gap-2">
            <div className="flex items-center justify-between text-xs">
              <label htmlFor="glass-dimmer-slider" className="font-semibold text-white/80">
                Glass Backdrop Dimmer
              </label>
              <span className="text-amber-300 tabular-nums">
                {settings.glassDimmer}%
              </span>
            </div>
            <input
              id="glass-dimmer-slider"
              type="range"
              min={10}
              max={80}
              value={settings.glassDimmer}
              onChange={(e) =>
                onUpdateSettings({
                  ...settings,
                  glassDimmer: Number(e.target.value),
                })
              }
              className="w-full accent-amber-400 cursor-pointer"
            />
          </section>

          {/* 3. Change Calculator PIN */}
          <section className="flex flex-col gap-2">
            <label
              htmlFor="settings-calc-pin"
              className="text-xs font-semibold text-white/80"
            >
              Calculator Stealth PIN
            </label>
            <form onSubmit={handlePinSave} className="flex items-center gap-2">
              <input
                id="settings-calc-pin"
                type="text"
                inputMode="numeric"
                maxLength={8}
                value={pinDraft}
                onChange={(e) =>
                  setPinDraft(e.target.value.replace(/\D/g, '').slice(0, 8))
                }
                className="flex-1 h-11 px-4 rounded-xl bg-white/[0.06] border border-white/[0.12] text-sm text-white tabular-nums tracking-widest focus:outline-none focus:border-amber-300/60"
              />
              <button
                type="submit"
                className="h-11 px-4 rounded-xl bg-amber-400 hover:bg-amber-300 text-stone-950 text-xs font-semibold transition-colors"
              >
                Save PIN
              </button>
            </form>
            {pinNotice && (
              <p className="text-[11px] text-amber-300">{pinNotice}</p>
            )}
          </section>

          {/* 4. Auto-Vanish Message Timer */}
          <section className="flex flex-col gap-2">
            <span className="text-xs font-semibold text-white/80">
              Auto-Vanish Message Timer
            </span>
            <div className="grid grid-cols-4 gap-1.5 p-1 rounded-2xl bg-white/[0.05] border border-white/[0.08]">
              {([0, 10, 30, 60] as AutoVanishSeconds[]).map((sec) => (
                <button
                  key={sec}
                  type="button"
                  onClick={() =>
                    onUpdateSettings({ ...settings, autoVanishSec: sec })
                  }
                  className={`h-9 rounded-xl text-xs font-medium transition-colors ${
                    settings.autoVanishSec === sec
                      ? 'bg-amber-400 text-stone-950 font-semibold'
                      : 'text-white/70 hover:text-white'
                  }`}
                >
                  {sec === 0 ? 'OFF' : `${sec}s`}
                </button>
              ))}
            </div>
          </section>

          {/* 5. Font Size & Auto-Lock */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <section className="flex flex-col gap-2">
              <span className="text-xs font-semibold text-white/80">
                Message Font Size
              </span>
              <div className="grid grid-cols-3 gap-1 p-1 rounded-2xl bg-white/[0.05] border border-white/[0.08]">
                {(['small', 'normal', 'large'] as FontSizeOption[]).map((sz) => (
                  <button
                    key={sz}
                    type="button"
                    onClick={() =>
                      onUpdateSettings({ ...settings, fontSize: sz })
                    }
                    className={`h-9 rounded-xl text-xs font-medium capitalize transition-colors ${
                      settings.fontSize === sz
                        ? 'bg-amber-400 text-stone-950 font-semibold'
                        : 'text-white/70 hover:text-white'
                    }`}
                  >
                    {sz}
                  </button>
                ))}
              </div>
            </section>

            <section className="flex flex-col gap-2">
              <span className="text-xs font-semibold text-white/80">
                Auto-Lock Inactivity
              </span>
              <div className="grid grid-cols-3 gap-1 p-1 rounded-2xl bg-white/[0.05] border border-white/[0.08]">
                {([0, 2, 5] as AutoLockMinutes[]).map((mins) => (
                  <button
                    key={mins}
                    type="button"
                    onClick={() =>
                      onUpdateSettings({ ...settings, autoLockMinutes: mins })
                    }
                    className={`h-9 rounded-xl text-xs font-medium transition-colors ${
                      settings.autoLockMinutes === mins
                        ? 'bg-amber-400 text-stone-950 font-semibold'
                        : 'text-white/70 hover:text-white'
                    }`}
                  >
                    {mins === 0 ? 'Never' : `${mins}m`}
                  </button>
                ))}
              </div>
            </section>
          </div>

          {/* 6. Sound Effects & Vibration Toggles */}
          <section className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() =>
                onUpdateSettings({
                  ...settings,
                  soundEnabled: !settings.soundEnabled,
                })
              }
              className={`h-12 px-4 rounded-2xl border flex items-center justify-between text-xs font-medium transition-all ${
                settings.soundEnabled
                  ? 'bg-amber-400/15 border-amber-300/50 text-amber-100'
                  : 'bg-white/[0.04] border-white/[0.08] text-white/60'
              }`}
            >
              <span className="flex items-center gap-2">
                {settings.soundEnabled ? (
                  <Volume2 className="w-4 h-4 text-amber-300" />
                ) : (
                  <VolumeX className="w-4 h-4" />
                )}
                <span>Sound FX</span>
              </span>
              <span>{settings.soundEnabled ? 'ON' : 'OFF'}</span>
            </button>

            <button
              type="button"
              onClick={() =>
                onUpdateSettings({
                  ...settings,
                  vibrationEnabled: !settings.vibrationEnabled,
                })
              }
              className={`h-12 px-4 rounded-2xl border flex items-center justify-between text-xs font-medium transition-all ${
                settings.vibrationEnabled
                  ? 'bg-amber-400/15 border-amber-300/50 text-amber-100'
                  : 'bg-white/[0.04] border-white/[0.08] text-white/60'
              }`}
            >
              <span className="flex items-center gap-2">
                <Vibrate className="w-4 h-4 text-amber-300" />
                <span>Vibration</span>
              </span>
              <span>{settings.vibrationEnabled ? 'ON' : 'OFF'}</span>
            </button>
          </section>
        </div>
      </div>
    </div>
  );
};

/* ============================================================================
 * SINGLE-FIELD ADD FRIEND MODAL
 * - Contains ONLY ONE input field: Friend's 4-Digit Code
 * ============================================================================ */

import React, { useState } from 'react';
import { Send, X } from 'lucide-react';

interface AddFriendModalProps {
  myCode: string;
  onClose: () => void;
  onSendRequest: (targetCode: string) => { ok: boolean; message: string };
}

export const AddFriendModal: React.FC<AddFriendModalProps> = ({
  myCode,
  onClose,
  onSendRequest,
}) => {
  const [codeInput, setCodeInput] = useState('');
  const [feedback, setFeedback] = useState<{ ok: boolean; text: string } | null>(
    null
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = codeInput.replace(/\D/g, '').slice(0, 4);
    if (cleaned.length !== 4) {
      setFeedback({ ok: false, text: 'Enter a valid 4-digit code (1000–9999).' });
      return;
    }
    if (cleaned === myCode) {
      setFeedback({ ok: false, text: 'You cannot add your own code.' });
      return;
    }

    const res = onSendRequest(cleaned);
    setFeedback({ ok: res.ok, text: res.message });
    if (res.ok) {
      window.setTimeout(() => onClose(), 900);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Add Friend"
      className="fixed inset-0 z-50 flex items-center justify-center px-4 bg-black/55 backdrop-blur-sm"
    >
      <div className="glass-surface-elevated glass-specular-rim spring-enter w-full max-w-[360px] rounded-[28px] p-6 flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-semibold text-white">Add Friend</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Add Friend modal"
            className="w-9 h-9 rounded-full bg-white/[0.06] hover:bg-white/[0.12] flex items-center justify-center text-white/75 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-3.5">
          <div className="flex flex-col gap-1.5">
            <label
              htmlFor="friend-four-digit-code"
              className="text-xs text-white/65"
            >
              Friend&apos;s 4-Digit Code
            </label>
            <input
              id="friend-four-digit-code"
              type="text"
              inputMode="numeric"
              maxLength={4}
              value={codeInput}
              onChange={(e) =>
                setCodeInput(e.target.value.replace(/\D/g, '').slice(0, 4))
              }
              placeholder="e.g. 4829"
              autoFocus
              className="w-full h-13 px-4 rounded-2xl bg-white/[0.06] border border-white/[0.14] text-center text-xl tracking-[0.35em] font-semibold text-amber-200 tabular-nums placeholder:text-white/25 placeholder:tracking-normal placeholder:text-sm focus:outline-none focus:border-amber-300/60"
            />
          </div>

          {feedback && (
            <p
              className={`text-xs font-medium ${
                feedback.ok ? 'text-amber-300' : 'text-rose-300'
              }`}
            >
              {feedback.text}
            </p>
          )}

          <button
            type="submit"
            className="w-full h-11 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 text-stone-950 font-semibold text-sm flex items-center justify-center gap-2 hover:from-amber-300 hover:to-amber-400 transition-all"
          >
            <Send className="w-4 h-4" />
            <span>Send Request</span>
          </button>
        </form>
      </div>
    </div>
  );
};

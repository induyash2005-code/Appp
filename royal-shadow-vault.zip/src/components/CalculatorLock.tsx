/* ============================================================================
 * COMPACT STEALTH CALCULATOR LOCK (DEFAULT PIN: 1904)
 * - Zero-dependency safe math parser (no eval)
 * - Full-fit responsive clamp() sizing + 44px safe bottom padding
 * - All 5 rows including '=' 100% visible with zero overflow or clipping
 * ============================================================================ */

import React, { useCallback, useEffect, useState } from 'react';
import { Delete } from 'lucide-react';
import {
  evaluateMathExpression,
  isStealthPinMatch,
} from '../engine/mathParser';
import { audioEngine } from '../engine/audioEngine';

interface CalculatorLockProps {
  pin: string;
  onUnlock: () => void;
}

type CalcKeyType = 'digit' | 'op' | 'action' | 'equals';

interface CalcKey {
  label: string;
  value: string;
  type: CalcKeyType;
  ariaLabel: string;
  wide?: boolean;
}

const CALC_KEYS: CalcKey[] = [
  { label: 'C', value: 'C', type: 'action', ariaLabel: 'Clear all' },
  { label: '⌫', value: 'BACK', type: 'action', ariaLabel: 'Backspace' },
  { label: '%', value: '%', type: 'op', ariaLabel: 'Percent' },
  { label: '÷', value: '÷', type: 'op', ariaLabel: 'Divide' },

  { label: '7', value: '7', type: 'digit', ariaLabel: '7' },
  { label: '8', value: '8', type: 'digit', ariaLabel: '8' },
  { label: '9', value: '9', type: 'digit', ariaLabel: '9' },
  { label: '×', value: '×', type: 'op', ariaLabel: 'Multiply' },

  { label: '4', value: '4', type: 'digit', ariaLabel: '4' },
  { label: '5', value: '5', type: 'digit', ariaLabel: '5' },
  { label: '6', value: '6', type: 'digit', ariaLabel: '6' },
  { label: '−', value: '−', type: 'op', ariaLabel: 'Subtract' },

  { label: '1', value: '1', type: 'digit', ariaLabel: '1' },
  { label: '2', value: '2', type: 'digit', ariaLabel: '2' },
  { label: '3', value: '3', type: 'digit', ariaLabel: '3' },
  { label: '+', value: '+', type: 'op', ariaLabel: 'Add' },

  { label: '0', value: '0', type: 'digit', ariaLabel: '0', wide: true },
  { label: '.', value: '.', type: 'digit', ariaLabel: 'Decimal point' },
  { label: '=', value: '=', type: 'equals', ariaLabel: 'Equals' },
];

const OPERATORS = new Set(['+', '−', '×', '÷', '%']);

export const CalculatorLock: React.FC<CalculatorLockProps> = ({
  pin,
  onUnlock,
}) => {
  const [expression, setExpression] = useState<string>('');
  const [resultPreview, setResultPreview] = useState<string>('0');
  const [justEvaluated, setJustEvaluated] = useState<boolean>(false);
  const [unlocking, setUnlocking] = useState<boolean>(false);

  const handlePress = useCallback(
    (keyVal: string) => {
      if (unlocking) return;

      if (keyVal === 'C') {
        audioEngine.playCalcTap(false);
        setExpression('');
        setResultPreview('0');
        setJustEvaluated(false);
        return;
      }

      if (keyVal === 'BACK') {
        audioEngine.playCalcTap(false);
        setExpression((prev) => {
          const next = prev.slice(0, -1);
          if (!next) {
            setResultPreview('0');
          } else {
            const evalRes = evaluateMathExpression(next);
            if (evalRes.ok) setResultPreview(evalRes.value);
          }
          return next;
        });
        setJustEvaluated(false);
        return;
      }

      if (keyVal === '=') {
        if (isStealthPinMatch(expression, pin)) {
          setUnlocking(true);
          audioEngine.playVaultUnlock();
          window.setTimeout(() => {
            onUnlock();
          }, 260);
          return;
        }
        audioEngine.playCalcTap(true);
        const evalRes = evaluateMathExpression(expression);
        setResultPreview(evalRes.value);
        if (evalRes.ok) {
          setExpression(evalRes.value);
        }
        setJustEvaluated(true);
        return;
      }

      audioEngine.playCalcTap(OPERATORS.has(keyVal));

      setExpression((prev) => {
        const isOp = OPERATORS.has(keyVal);
        let base = prev;

        if (justEvaluated && !isOp) {
          base = '';
        }
        setJustEvaluated(false);

        if (isOp) {
          if (!base && keyVal !== '−') return prev;
          const last = base.slice(-1);
          if (OPERATORS.has(last)) {
            return base.slice(0, -1) + keyVal;
          }
          return base + keyVal;
        }

        if (keyVal === '.') {
          // Prevent two decimals in the current number segment
          const parts = base.split(/[+−×÷%]/);
          const currentNum = parts[parts.length - 1] || '';
          if (currentNum.includes('.')) return prev;
          if (!currentNum) return base + '0.';
          return base + '.';
        }

        if (base === '0') {
          return keyVal;
        }
        return base + keyVal;
      });
    },
    [expression, justEvaluated, onUnlock, pin, unlocking]
  );

  useEffect(() => {
    if (!expression) {
      setResultPreview('0');
      return;
    }
    const last = expression.slice(-1);
    if (!OPERATORS.has(last)) {
      const res = evaluateMathExpression(expression);
      if (res.ok) setResultPreview(res.value);
    }
  }, [expression]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key >= '0' && e.key <= '9') {
        handlePress(e.key);
      } else if (e.key === '.') {
        handlePress('.');
      } else if (e.key === '+') {
        handlePress('+');
      } else if (e.key === '-') {
        handlePress('−');
      } else if (e.key === '*') {
        handlePress('×');
      } else if (e.key === '/') {
        e.preventDefault();
        handlePress('÷');
      } else if (e.key === '%') {
        handlePress('%');
      } else if (e.key === 'Backspace') {
        handlePress('BACK');
      } else if (e.key === 'Escape' || e.key.toLowerCase() === 'c') {
        handlePress('C');
      } else if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault();
        handlePress('=');
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handlePress]);

  return (
    <main
      aria-label="Calculator"
      className={`relative z-10 w-full h-full flex flex-col items-center justify-end sm:justify-center px-4 pt-4 calc-safe-pad transition-all duration-300 ${
        unlocking ? 'opacity-0 scale-95' : 'opacity-100 scale-100'
      }`}
    >
      <section className="glass-surface glass-specular-rim w-full max-w-[380px] rounded-[30px] p-4 sm:p-5 flex flex-col gap-3">
        {/* Display Panel */}
        <div className="px-2 pt-3 pb-2 flex flex-col items-end justify-end min-h-[clamp(86px,15vh,124px)] overflow-hidden">
          <div
            data-testid="calc-expression"
            className="w-full text-right text-white/55 tabular-nums truncate text-[clamp(1rem,2.8vw,1.25rem)] min-h-[26px]"
          >
            {expression || ' '}
          </div>
          <div
            data-testid="calc-display"
            className="w-full text-right font-light text-white tabular-nums tracking-tight truncate text-[clamp(2.2rem,6vw,3.35rem)] leading-tight"
          >
            {resultPreview}
          </div>
        </div>

        {/* 5-Row Compact Frosted Keypad */}
        <div className="grid grid-cols-4 gap-[clamp(8px,1.8vw,12px)]">
          {CALC_KEYS.map((k) => {
            const baseHeight = 'h-[clamp(50px,8.6vh,68px)]';
            const spanClass = k.wide ? 'col-span-2' : '';

            let styleClass =
              'bg-white/[0.07] hover:bg-white/[0.12] text-white border border-white/[0.1]';
            if (k.type === 'action') {
              styleClass =
                'bg-white/[0.12] hover:bg-white/[0.18] text-white/90 border border-white/[0.14]';
            } else if (k.type === 'op') {
              styleClass =
                'bg-amber-400/15 hover:bg-amber-400/25 text-amber-200 border border-amber-300/25';
            } else if (k.type === 'equals') {
              styleClass =
                'bg-gradient-to-br from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-stone-950 font-semibold border border-amber-200/50 shadow-[0_8px_24px_rgba(251,191,36,0.28)]';
            }

            return (
              <button
                key={k.label}
                type="button"
                aria-label={k.ariaLabel}
                onClick={() => handlePress(k.value)}
                className={`calc-btn ${baseHeight} ${spanClass} ${styleClass} rounded-2xl flex items-center justify-center text-[clamp(1.15rem,2.8vw,1.45rem)] font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-300/70`}
              >
                {k.value === 'BACK' ? (
                  <Delete className="w-5 h-5" strokeWidth={1.9} />
                ) : (
                  k.label
                )}
              </button>
            );
          })}
        </div>
      </section>
    </main>
  );
};

/* ============================================================================
 * 7 ROYAL & SCENIC ARTWORK THEMES + AMBIENT MOTION + CUSTOM WALLPAPER
 * 1. Royal Burgundy & Gold   2. Lunar Moon        3. Blue Earth
 * 4. Starry Sky              5. Emerald Forest    6. Sakura Night
 * 7. Royal Sunset
 * ============================================================================ */

import React, { useEffect, useRef } from 'react';
import type { ThemeId } from '../types/vault';

export interface ThemeMeta {
  id: ThemeId;
  name: string;
  subtitle: string;
  swatch: [string, string, string];
}

export const THEME_LIST: ThemeMeta[] = [
  {
    id: 'royal-burgundy',
    name: 'Royal Burgundy & Gold',
    subtitle: 'OLED obsidian, velvet burgundy & champagne aura',
    swatch: ['#070407', '#3a1020', '#fbbf24'],
  },
  {
    id: 'lunar-moon',
    name: 'Lunar Moon',
    subtitle: 'Detailed cratered full moon & starry mist',
    swatch: ['#070b14', '#1e293b', '#e2e8f0'],
  },
  {
    id: 'blue-earth',
    name: 'Blue Earth',
    subtitle: 'Illuminated horizon from deep space',
    swatch: ['#030712', '#0c4a6e', '#38bdf8'],
  },
  {
    id: 'starry-sky',
    name: 'Starry Sky',
    subtitle: 'Deep cosmic nebula & twinkling constellations',
    swatch: ['#050510', '#312e81', '#fde68a'],
  },
  {
    id: 'emerald-forest',
    name: 'Emerald Forest',
    subtitle: 'Misty pine silhouettes & golden fireflies',
    swatch: ['#03110c', '#064e3b', '#fde047'],
  },
  {
    id: 'sakura-night',
    name: 'Sakura Night',
    subtitle: 'Crescent moon & drifting cherry blossoms',
    swatch: ['#120814', '#4c1d3d', '#f9a8d4'],
  },
  {
    id: 'royal-sunset',
    name: 'Royal Sunset',
    subtitle: 'Golden-amber twilight over mountain ridges',
    swatch: ['#140a14', '#7c2d12', '#f59e0b'],
  },
];

interface ThemeBackdropProps {
  themeId: ThemeId;
  customWallpaper: string | null;
  glassDimmer: number;
}

interface AmbientMote {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  phase: number;
  speed: number;
}

export const ThemeBackdrop: React.FC<ThemeBackdropProps> = ({
  themeId,
  customWallpaper,
  glassDimmer,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const prefersReduced =
      typeof window !== 'undefined' &&
      window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

    let width = window.innerWidth;
    let height = window.innerHeight;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const resize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener('resize', resize);

    const moteCount =
      themeId === 'starry-sky' || themeId === 'lunar-moon' || themeId === 'blue-earth'
        ? 55
        : themeId === 'emerald-forest' || themeId === 'sakura-night'
          ? 28
          : 22;

    const motes: AmbientMote[] = Array.from({ length: moteCount }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * (themeId === 'sakura-night' ? 18 : 10),
      vy:
        themeId === 'sakura-night'
          ? 12 + Math.random() * 18
          : themeId === 'royal-burgundy' || themeId === 'emerald-forest'
            ? -(4 + Math.random() * 10)
            : (Math.random() - 0.5) * 4,
      r: themeId === 'emerald-forest' ? 1.8 + Math.random() * 2.2 : 0.8 + Math.random() * 1.8,
      phase: Math.random() * Math.PI * 2,
      speed: 0.7 + Math.random() * 1.6,
    }));

    let rafId = 0;
    let last = performance.now();
    let frameAccum = 0;

    const draw = (now: number) => {
      const rawDt = Math.min(0.05, Math.max(0.001, (now - last) / 1000));
      last = now;
      frameAccum += rawDt;

      // Throttle subtle background ambient motion to ~30fps for smooth low-CPU efficiency
      if (frameAccum < 0.033 && !prefersReduced) {
        rafId = window.requestAnimationFrame(draw);
        return;
      }
      const dt = frameAccum;
      frameAccum = 0;
      const t = now / 1000;

      ctx.clearRect(0, 0, width, height);

      for (const m of motes) {
        if (!prefersReduced) {
          m.x += m.vx * dt;
          m.y += m.vy * dt;
          if (m.x < -10) m.x = width + 10;
          if (m.x > width + 10) m.x = -10;
          if (m.y < -10) m.y = height + 10;
          if (m.y > height + 10) m.y = -10;
        }

        const pulse = 0.3 + 0.7 * Math.abs(Math.sin(t * m.speed + m.phase));
        const fill =
          themeId === 'emerald-forest'
            ? '#fde047'
            : themeId === 'sakura-night'
              ? '#f9a8d4'
              : themeId === 'royal-burgundy' || themeId === 'royal-sunset'
                ? '#fde68a'
                : '#e2e8f0';

        ctx.save();
        ctx.fillStyle = fill;

        // Soft outer halo without expensive shadowBlur
        ctx.globalAlpha = pulse * 0.2;
        ctx.beginPath();
        ctx.arc(m.x, m.y, m.r * 2.4, 0, Math.PI * 2);
        ctx.fill();

        // Crisp core
        ctx.globalAlpha = pulse * 0.78;
        ctx.beginPath();
        if (themeId === 'sakura-night') {
          ctx.ellipse(m.x, m.y, m.r * 1.8, m.r * 1.1, t + m.phase, 0, Math.PI * 2);
        } else {
          ctx.arc(m.x, m.y, m.r, 0, Math.PI * 2);
        }
        ctx.fill();
        ctx.restore();
      }

      if (!prefersReduced) {
        rafId = window.requestAnimationFrame(draw);
      }
    };

    rafId = window.requestAnimationFrame(draw);

    return () => {
      window.removeEventListener('resize', resize);
      window.cancelAnimationFrame(rafId);
    };
  }, [themeId]);

  return (
    <div
      aria-hidden="true"
      className="fixed inset-0 z-0 overflow-hidden pointer-events-none select-none"
    >
      {/* Custom Uploaded Wallpaper Layer */}
      {customWallpaper ? (
        <img
          src={customWallpaper}
          alt=""
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover"
        />
      ) : (
        <ScenicSvgArtwork themeId={themeId} />
      )}

      {/* Subtle Live Ambient Canvas Motion */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none"
      />

      {/* User-Controlled Glass Dimmer Scrim */}
      <div
        className="absolute inset-0 transition-opacity duration-300"
        style={{
          backgroundColor: `rgba(5, 3, 8, ${Math.min(0.88, Math.max(0.08, glassDimmer / 100))})`,
        }}
      />
    </div>
  );
};

const ScenicSvgArtwork: React.FC<{ themeId: ThemeId }> = ({ themeId }) => {
  switch (themeId) {
    case 'royal-burgundy':
      return (
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 1200 900"
          preserveAspectRatio="xMidYMid slice"
        >
          <defs>
            <radialGradient id="rbBg" cx="50%" cy="22%" r="80%">
              <stop offset="0%" stopColor="#4c1228" />
              <stop offset="48%" stopColor="#1e0812" />
              <stop offset="100%" stopColor="#070407" />
            </radialGradient>
            <radialGradient id="rbGold" cx="50%" cy="18%" r="45%">
              <stop offset="0%" stopColor="rgba(251,191,36,0.22)" />
              <stop offset="100%" stopColor="rgba(251,191,36,0)" />
            </radialGradient>
          </defs>
          <rect width="1200" height="900" fill="url(#rbBg)" />
          <rect width="1200" height="900" fill="url(#rbGold)" />
          <path
            d="M0 700 Q300 610 600 680 T1200 640 L1200 900 L0 900 Z"
            fill="rgba(56, 12, 30, 0.45)"
          />
          <path
            d="M0 770 Q420 710 820 790 T1200 750 L1200 900 L0 900 Z"
            fill="rgba(16, 6, 12, 0.72)"
          />
        </svg>
      );

    case 'lunar-moon':
      return (
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 1200 900"
          preserveAspectRatio="xMidYMid slice"
        >
          <defs>
            <linearGradient id="lmSky" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#050811" />
              <stop offset="60%" stopColor="#0f172a" />
              <stop offset="100%" stopColor="#1e293b" />
            </linearGradient>
            <radialGradient id="lmHalo" cx="72%" cy="24%" r="36%">
              <stop offset="0%" stopColor="rgba(226,232,240,0.42)" />
              <stop offset="50%" stopColor="rgba(148,163,184,0.12)" />
              <stop offset="100%" stopColor="rgba(15,23,42,0)" />
            </radialGradient>
            <radialGradient id="lmDisc" cx="38%" cy="35%" r="65%">
              <stop offset="0%" stopColor="#f8fafc" />
              <stop offset="70%" stopColor="#cbd5e1" />
              <stop offset="100%" stopColor="#94a3b8" />
            </radialGradient>
          </defs>
          <rect width="1200" height="900" fill="url(#lmSky)" />
          <rect width="1200" height="900" fill="url(#lmHalo)" />
          {/* Full Moon with craters */}
          <circle cx="860" cy="215" r="108" fill="url(#lmDisc)" />
          <circle cx="826" cy="184" r="18" fill="rgba(100,116,139,0.28)" />
          <circle cx="892" cy="245" r="24" fill="rgba(100,116,139,0.22)" />
          <circle cx="835" cy="256" r="11" fill="rgba(100,116,139,0.24)" />
          <circle cx="896" cy="180" r="9" fill="rgba(100,116,139,0.2)" />
          {/* Night mountain mist */}
          <path
            d="M0 680 Q260 600 540 670 T1200 620 L1200 900 L0 900 Z"
            fill="rgba(15, 23, 42, 0.72)"
          />
          <path
            d="M0 760 Q360 700 760 775 T1200 740 L1200 900 L0 900 Z"
            fill="rgba(5, 8, 17, 0.9)"
          />
        </svg>
      );

    case 'blue-earth':
      return (
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 1200 900"
          preserveAspectRatio="xMidYMid slice"
        >
          <defs>
            <linearGradient id="beSpace" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#02050d" />
              <stop offset="100%" stopColor="#051226" />
            </linearGradient>
            <radialGradient id="beAtmo" cx="50%" cy="118%" r="72%">
              <stop offset="68%" stopColor="#03152e" />
              <stop offset="84%" stopColor="#0284c7" />
              <stop offset="90%" stopColor="#7dd3fc" />
              <stop offset="96%" stopColor="rgba(56,189,248,0.22)" />
              <stop offset="100%" stopColor="rgba(2,5,13,0)" />
            </radialGradient>
          </defs>
          <rect width="1200" height="900" fill="url(#beSpace)" />
          <circle cx="600" cy="1120" r="640" fill="url(#beAtmo)" />
          {/* Atmospheric limb highlight */}
          <path
            d="M-40 710 Q600 410 1240 710"
            fill="none"
            stroke="rgba(125,211,252,0.55)"
            strokeWidth="6"
          />
        </svg>
      );

    case 'starry-sky':
      return (
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 1200 900"
          preserveAspectRatio="xMidYMid slice"
        >
          <defs>
            <radialGradient id="ssNebula1" cx="28%" cy="30%" r="55%">
              <stop offset="0%" stopColor="rgba(99,102,241,0.34)" />
              <stop offset="100%" stopColor="rgba(5,5,16,0)" />
            </radialGradient>
            <radialGradient id="ssNebula2" cx="76%" cy="62%" r="50%">
              <stop offset="0%" stopColor="rgba(251,191,36,0.16)" />
              <stop offset="100%" stopColor="rgba(5,5,16,0)" />
            </radialGradient>
          </defs>
          <rect width="1200" height="900" fill="#050510" />
          <rect width="1200" height="900" fill="url(#ssNebula1)" />
          <rect width="1200" height="900" fill="url(#ssNebula2)" />
          {/* Constellation lines */}
          <g stroke="rgba(253,230,138,0.22)" strokeWidth="1.2">
            <line x1="210" y1="180" x2="340" y2="240" />
            <line x1="340" y1="240" x2="450" y2="170" />
            <line x1="450" y1="170" x2="570" y2="260" />
            <line x1="820" y1="190" x2="910" y2="290" />
            <line x1="910" y1="290" x2="1030" y2="240" />
          </g>
          <g fill="#fef3c7">
            <circle cx="210" cy="180" r="2.8" />
            <circle cx="340" cy="240" r="3.4" />
            <circle cx="450" cy="170" r="2.5" />
            <circle cx="570" cy="260" r="3" />
            <circle cx="820" cy="190" r="3.2" />
            <circle cx="910" cy="290" r="2.6" />
            <circle cx="1030" cy="240" r="3.4" />
          </g>
        </svg>
      );

    case 'emerald-forest':
      return (
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 1200 900"
          preserveAspectRatio="xMidYMid slice"
        >
          <defs>
            <linearGradient id="efSky" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#02110b" />
              <stop offset="55%" stopColor="#063729" />
              <stop offset="100%" stopColor="#041b13" />
            </linearGradient>
          </defs>
          <rect width="1200" height="900" fill="url(#efSky)" />
          {/* Layered misty ridges & pine silhouettes */}
          <path
            d="M0 590 L80 510 L140 570 L230 470 L310 560 L410 490 L510 580 L620 465 L730 575 L840 485 L950 570 L1060 475 L1200 585 L1200 900 L0 900 Z"
            fill="rgba(6, 78, 59, 0.52)"
          />
          <path
            d="M0 680 L100 600 L190 675 L290 580 L390 680 L500 595 L610 685 L720 585 L840 675 L960 590 L1080 685 L1200 610 L1200 900 L0 900 Z"
            fill="rgba(4, 47, 36, 0.8)"
          />
          <path
            d="M0 770 L140 710 L260 780 L420 700 L580 785 L760 710 L920 785 L1080 715 L1200 775 L1200 900 L0 900 Z"
            fill="#02130d"
          />
        </svg>
      );

    case 'sakura-night':
      return (
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 1200 900"
          preserveAspectRatio="xMidYMid slice"
        >
          <defs>
            <linearGradient id="snSky" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#0d0612" />
              <stop offset="60%" stopColor="#2a102b" />
              <stop offset="100%" stopColor="#140814" />
            </linearGradient>
            <radialGradient id="snGlow" cx="76%" cy="22%" r="35%">
              <stop offset="0%" stopColor="rgba(249,168,212,0.34)" />
              <stop offset="100%" stopColor="rgba(42,16,43,0)" />
            </radialGradient>
          </defs>
          <rect width="1200" height="900" fill="url(#snSky)" />
          <rect width="1200" height="900" fill="url(#snGlow)" />
          {/* Crescent Moon */}
          <path
            d="M910 130 A86 86 0 1 0 980 270 A68 68 0 1 1 910 130 Z"
            fill="#fde68a"
            opacity="0.92"
          />
          {/* Sakura branch silhouette */}
          <path
            d="M-20 260 Q220 210 420 290 T720 250"
            fill="none"
            stroke="#1f0a1d"
            strokeWidth="14"
            strokeLinecap="round"
          />
          <g fill="#f472b6" opacity="0.55">
            <circle cx="180" cy="228" r="26" />
            <circle cx="290" cy="252" r="22" />
            <circle cx="420" cy="286" r="28" />
            <circle cx="560" cy="264" r="20" />
            <circle cx="690" cy="248" r="24" />
          </g>
        </svg>
      );

    case 'royal-sunset':
      return (
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 1200 900"
          preserveAspectRatio="xMidYMid slice"
        >
          <defs>
            <linearGradient id="rsSky" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#120918" />
              <stop offset="45%" stopColor="#581c3a" />
              <stop offset="78%" stopColor="#b45309" />
              <stop offset="100%" stopColor="#f59e0b" />
            </linearGradient>
            <radialGradient id="rsSun" cx="50%" cy="56%" r="32%">
              <stop offset="0%" stopColor="#fef3c7" />
              <stop offset="45%" stopColor="#f59e0b" />
              <stop offset="100%" stopColor="rgba(245,158,11,0)" />
            </radialGradient>
          </defs>
          <rect width="1200" height="900" fill="url(#rsSky)" />
          <circle cx="600" cy="510" r="145" fill="url(#rsSun)" />
          {/* Layered mountain ridges */}
          <path
            d="M0 590 Q240 500 480 575 T960 540 L1200 585 L1200 900 L0 900 Z"
            fill="rgba(69, 20, 36, 0.72)"
          />
          <path
            d="M0 680 Q320 605 640 675 T1200 645 L1200 900 L0 900 Z"
            fill="rgba(34, 12, 24, 0.88)"
          />
          <path
            d="M0 770 Q420 710 820 785 T1200 755 L1200 900 L0 900 Z"
            fill="#11060e"
          />
        </svg>
      );
  }
};

/* ============================================================================
 * 2-SECOND HOLD-TO-VIEW PHOTO VIEWER (ANTI-SCREENSHOT HARDENED)
 * - Image ONLY reveals while finger/pointer is held down (pointerdown)
 * - Glowing 2.0-second circular SVG countdown ring around the viewer
 * - Immediately blacks out & destroys image reference on:
 *   pointerup | pointercancel | window blur | visibilitychange | 2.0s expiry
 *
 * NATIVE ANDROID APK HOOK (WindowManager.LayoutParams.FLAG_SECURE):
 * When wrapped inside an Android WebView / Capacitor / Cordova shell, expose:
 *   window.AndroidVaultBridge?.setSecureScreen(true | false)
 * Calling setSecureScreen(true) triggers on the Android UI thread:
 *   activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
 * Calling setSecureScreen(false) clears FLAG_SECURE upon close:
 *   activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
 * ============================================================================ */

import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Eye, ShieldAlert, X } from 'lucide-react';

interface ViewOnceViewerProps {
  messageId: string;
  senderName: string;
  mediaDataUrl: string;
  onConsumeDestroy: (messageId: string) => void;
  onClose: () => void;
}

const HOLD_DURATION_MS = 2000;

declare global {
  interface Window {
    AndroidVaultBridge?: {
      setSecureScreen?: (secure: boolean) => void;
    };
  }
}

export const ViewOnceViewer: React.FC<ViewOnceViewerProps> = ({
  messageId,
  senderName,
  mediaDataUrl,
  onConsumeDestroy,
  onClose,
}) => {
  const [holding, setHolding] = useState(false);
  const [elapsedMs, setElapsedMs] = useState(0);
  const [destroyed, setDestroyed] = useState(false);

  const rafRef = useRef<number | null>(null);
  const startTsRef = useRef<number>(0);
  const imgRef = useRef<HTMLImageElement | null>(null);
  const consumedRef = useRef<boolean>(false);

  // Engage Android FLAG_SECURE bridge if present
  useEffect(() => {
    try {
      window.AndroidVaultBridge?.setSecureScreen?.(true);
    } catch {
      // ignore on web
    }
    return () => {
      try {
        window.AndroidVaultBridge?.setSecureScreen?.(false);
      } catch {
        // ignore on web
      }
    };
  }, []);

  const destroyMediaNow = useCallback(() => {
    if (consumedRef.current) return;
    consumedRef.current = true;
    setHolding(false);
    setDestroyed(true);

    if (rafRef.current !== null) {
      window.cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }

    // Scrub image element from DOM & memory
    if (imgRef.current) {
      imgRef.current.src = '';
      imgRef.current.removeAttribute('src');
    }

    onConsumeDestroy(messageId);
  }, [messageId, onConsumeDestroy]);

  // Anti-screenshot: destroy immediately if window loses focus or tab switches
  useEffect(() => {
    const onBlur = () => {
      if (holding || !consumedRef.current) {
        destroyMediaNow();
      }
    };
    const onVisibility = () => {
      if (document.hidden) {
        destroyMediaNow();
      }
    };
    window.addEventListener('blur', onBlur);
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      window.removeEventListener('blur', onBlur);
      document.removeEventListener('visibilitychange', onVisibility);
      if (rafRef.current !== null) {
        window.cancelAnimationFrame(rafRef.current);
      }
    };
  }, [destroyMediaNow, holding]);

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (destroyed || consumedRef.current) return;
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // ignore
    }

    setHolding(true);
    startTsRef.current = performance.now();

    const step = (now: number) => {
      const dt = now - startTsRef.current;
      if (dt >= HOLD_DURATION_MS) {
        setElapsedMs(HOLD_DURATION_MS);
        destroyMediaNow();
        return;
      }
      setElapsedMs(dt);
      rafRef.current = window.requestAnimationFrame(step);
    };

    rafRef.current = window.requestAnimationFrame(step);
  };

  const handlePointerRelease = () => {
    if (holding && !destroyed) {
      destroyMediaNow();
    }
  };

  const remainingSec = Math.max(0, (HOLD_DURATION_MS - elapsedMs) / 1000);
  const progress = Math.min(1, elapsedMs / HOLD_DURATION_MS);
  const circumference = 2 * Math.PI * 26;
  const dashOffset = circumference * progress;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="2-Second View-Once Photo"
      onContextMenu={(e) => e.preventDefault()}
      className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center select-none"
      style={{ touchAction: 'none' }}
    >
      {/* Top Bar */}
      <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between px-4 py-4 bg-gradient-to-b from-black/80 to-transparent">
        <div className="flex items-center gap-3">
          <div className="relative w-14 h-14 flex items-center justify-center">
            <svg className="w-14 h-14 -rotate-90" viewBox="0 0 60 60">
              <circle
                cx="30"
                cy="30"
                r="26"
                fill="none"
                stroke="rgba(255,255,255,0.16)"
                strokeWidth="3.5"
              />
              <circle
                cx="30"
                cy="30"
                r="26"
                fill="none"
                stroke="#fbbf24"
                strokeWidth="3.5"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={dashOffset}
                style={{
                  filter: 'drop-shadow(0 0 8px rgba(251, 191, 36, 0.8))',
                }}
              />
            </svg>
            <span className="absolute text-xs font-semibold text-amber-200 tabular-nums">
              {remainingSec.toFixed(1)}s
            </span>
          </div>
          <div>
            <div className="text-sm font-semibold text-white">{senderName}</div>
            <div className="text-xs text-white/60">
              {destroyed
                ? 'Photo destroyed'
                : holding
                  ? 'Revealing · Release to destroy'
                  : 'Press & hold anywhere for 2s'}
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={() => {
            if (!destroyed) destroyMediaNow();
            onClose();
          }}
          aria-label="Close View-Once Viewer"
          className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Hold Surface */}
      <div
        onPointerDown={handlePointerDown}
        onPointerUp={handlePointerRelease}
        onPointerCancel={handlePointerRelease}
        className="w-full h-full flex items-center justify-center px-4 cursor-pointer"
      >
        {!destroyed && holding ? (
          <img
            ref={imgRef}
            src={mediaDataUrl}
            alt="View once media"
            referrerPolicy="no-referrer"
            draggable={false}
            className="max-w-full max-h-[82vh] rounded-2xl object-contain shadow-[0_0_50px_rgba(251,191,36,0.22)] pointer-events-none"
          />
        ) : destroyed ? (
          <div className="glass-surface rounded-3xl px-7 py-6 flex flex-col items-center gap-3 text-center max-w-xs">
            <ShieldAlert className="w-8 h-8 text-amber-300" />
            <div className="text-sm font-semibold text-white">
              Media Permanently Destroyed
            </div>
            <p className="text-xs text-white/60">
              Cleared from memory and locked on both sides.
            </p>
            <button
              type="button"
              onClick={onClose}
              className="mt-1 px-5 py-2.5 rounded-xl bg-amber-400 text-stone-950 text-xs font-semibold"
            >
              Return to Chat
            </button>
          </div>
        ) : (
          <div className="glass-surface golden-aura-card rounded-3xl px-8 py-8 flex flex-col items-center gap-3 text-center max-w-xs pointer-events-none">
            <div className="w-14 h-14 rounded-full bg-amber-400/15 border border-amber-300/40 flex items-center justify-center text-amber-200">
              <Eye className="w-7 h-7" />
            </div>
            <div className="text-base font-semibold text-white">
              Hold to View · 2.0s
            </div>
            <p className="text-xs text-white/65 leading-relaxed">
              Keep your finger pressed on the screen. Lifting or switching tabs
              instantly destroys the photo.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

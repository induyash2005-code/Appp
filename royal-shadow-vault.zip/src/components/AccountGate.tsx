/* ============================================================================
 * ZERO-SERVER PERSONAL ACCOUNT GATE
 * - No preset/dummy accounts
 * - Creates personal account with Display Name + Password + Compressed Photo
 * - Assigns auto-unique 4-digit P2P code (1000-9999)
 * - Returning user unlocks with personal password or resets local vault
 * ============================================================================ */

import React, { useRef, useState } from 'react';
import { Camera, Lock, ShieldCheck, UserPlus } from 'lucide-react';
import type { VaultUser } from '../types/vault';
import {
  compressImageFile,
  generateFourDigitCode,
  generateMonogramAvatar,
  hashVaultPassword,
} from '../engine/storage';

interface AccountGateProps {
  existingUser: VaultUser | null;
  onAuthenticated: (user: VaultUser) => void;
  onLockBack: () => void;
}

export const AccountGate: React.FC<AccountGateProps> = ({
  existingUser,
  onAuthenticated,
  onLockBack,
}) => {
  const [displayName, setDisplayName] = useState('');
  const [password, setPassword] = useState('');
  const [avatarDataUrl, setAvatarDataUrl] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError('');
    try {
      const compressed = await compressImageFile(file, 220, 0.8);
      setAvatarDataUrl(compressed);
    } catch {
      setError('Could not process that image. Please choose another photo.');
    }
  };

  const handleCreateAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = displayName.trim();
    if (trimmedName.length < 2) {
      setError('Display name must be at least 2 characters.');
      return;
    }
    if (password.trim().length < 4) {
      setError('Password must be at least 4 characters.');
      return;
    }

    setSubmitting(true);
    setError('');
    try {
      const passwordHash = await hashVaultPassword(password);
      const user: VaultUser = {
        id: `usr_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        displayName: trimmedName,
        passwordHash,
        code: generateFourDigitCode(),
        avatarDataUrl: avatarDataUrl || generateMonogramAvatar(trimmedName),
        createdAt: Date.now(),
      };
      onAuthenticated(user);
    } finally {
      setSubmitting(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!existingUser) return;
    if (!password.trim()) {
      setError('Please enter your vault password.');
      return;
    }

    setSubmitting(true);
    setError('');
    try {
      const candidate = await hashVaultPassword(password);
      if (candidate !== existingUser.passwordHash) {
        setError('Incorrect password. Please try again.');
        return;
      }
      onAuthenticated(existingUser);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <main className="relative z-10 w-full h-full flex items-center justify-center px-4 py-6 overflow-y-auto vault-scroll">
      <section className="glass-surface-elevated glass-specular-rim spring-enter w-full max-w-[420px] rounded-[28px] p-6 sm:p-7 flex flex-col gap-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400/15 border border-amber-300/30 flex items-center justify-center text-amber-300">
              {existingUser ? (
                <ShieldCheck className="w-5 h-5" />
              ) : (
                <UserPlus className="w-5 h-5" />
              )}
            </div>
            <div>
              <h1 className="text-lg font-semibold text-white tracking-tight">
                {existingUser ? 'Unlock Personal Vault' : 'Create Personal Identity'}
              </h1>
              <p className="text-xs text-white/60">
                {existingUser
                  ? 'Zero-server local profile'
                  : 'Stored locally · Auto-assigned 4-digit P2P code'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onLockBack}
            aria-label="Return to Calculator"
            className="w-10 h-10 rounded-full glass-subtle flex items-center justify-center text-white/75 hover:text-white hover:bg-white/10 transition-colors"
          >
            <Lock className="w-4 h-4" />
          </button>
        </div>

        {existingUser ? (
          <form onSubmit={handleLogin} className="flex flex-col gap-4">
            <div className="flex items-center gap-3.5 p-3.5 rounded-2xl bg-white/[0.04] border border-white/[0.08]">
              <img
                src={existingUser.avatarDataUrl}
                alt={existingUser.displayName}
                referrerPolicy="no-referrer"
                className="w-12 h-12 rounded-full object-cover golden-aura-ring"
              />
              <div className="min-w-0 flex-1">
                <div className="text-sm font-semibold text-white truncate">
                  {existingUser.displayName}
                </div>
                <div className="text-xs text-amber-300/90 tabular-nums">
                  Code · {existingUser.code}
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <label
                htmlFor="vault-login-password"
                className="text-xs font-medium text-white/75"
              >
                Vault Password
              </label>
              <input
                id="vault-login-password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                autoFocus
                className="w-full h-12 px-4 rounded-2xl bg-white/[0.06] border border-white/[0.12] text-sm text-white placeholder:text-white/35 focus:outline-none focus:border-amber-300/60"
              />
            </div>

            {error && (
              <p role="alert" className="text-xs text-rose-300 font-medium">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full h-12 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 text-stone-950 font-semibold text-sm hover:from-amber-300 hover:to-amber-400 transition-all disabled:opacity-60"
            >
              {submitting ? 'Verifying...' : 'Enter Vault'}
            </button>
          </form>
        ) : (
          <form onSubmit={handleCreateAccount} className="flex flex-col gap-4">
            {/* Avatar Picker */}
            <div className="flex items-center gap-4">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                aria-label="Upload Profile Photo"
                className="relative w-16 h-16 rounded-full bg-white/[0.06] border border-white/[0.18] flex items-center justify-center overflow-hidden hover:border-amber-300/60 transition-colors shrink-0"
              >
                {avatarDataUrl ? (
                  <img
                    src={avatarDataUrl}
                    alt="Selected profile"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <Camera className="w-6 h-6 text-amber-200/80" />
                )}
              </button>
              <div className="flex flex-col gap-0.5">
                <span className="text-sm font-medium text-white">
                  Profile Photo
                </span>
                <span className="text-xs text-white/55">
                  Optional · Compressed locally before P2P share
                </span>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handlePhotoSelect}
                className="hidden"
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <label
                htmlFor="vault-display-name"
                className="text-xs font-medium text-white/75"
              >
                Display Name
              </label>
              <input
                id="vault-display-name"
                type="text"
                maxLength={28}
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="e.g. Aarav, Elena"
                required
                className="w-full h-12 px-4 rounded-2xl bg-white/[0.06] border border-white/[0.12] text-sm text-white placeholder:text-white/35 focus:outline-none focus:border-amber-300/60"
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <label
                htmlFor="vault-create-password"
                className="text-xs font-medium text-white/75"
              >
                Account Password
              </label>
              <input
                id="vault-create-password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Minimum 4 characters"
                required
                className="w-full h-12 px-4 rounded-2xl bg-white/[0.06] border border-white/[0.12] text-sm text-white placeholder:text-white/35 focus:outline-none focus:border-amber-300/60"
              />
            </div>

            {error && (
              <p role="alert" className="text-xs text-rose-300 font-medium">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full h-12 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 text-stone-950 font-semibold text-sm hover:from-amber-300 hover:to-amber-400 transition-all disabled:opacity-60 shadow-[0_10px_28px_rgba(251,191,36,0.24)]"
            >
              {submitting ? 'Generating 4-Digit Code...' : 'Create & Assign Code'}
            </button>
          </form>
        )}
      </section>
    </main>
  );
};

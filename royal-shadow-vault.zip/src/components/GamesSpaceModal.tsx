/* ============================================================================
 * TOP 3 CURATED LIVE P2P GAMES + CO-DRAW + WATCH & LISTEN TOGETHER
 * 1. Stone Paper Scissor (Secret Choice Lock + 3-2-1 Shake Reveal + Scoreboard)
 * 2. Tic-Tac-Toe (Strictly 1-Touch Per Turn + Glowing SVG Strike-Through)
 * 3. Connect 4 (6x7 Gravity Drop + Strictly 1-Touch Per Turn + 4-in-a-Row Glow)
 * 4. Minimal Live Co-Draw (5 Colors, Width Toggle, Quadratic Bezier Sync)
 * 5. Watch & Listen Together (Local MP3/Audio + YouTube / Shorts IFrame API Sync)
 * ============================================================================ */

import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Eraser,
  Film,
  Music,
  Palette,
  Pause,
  Play,
  RotateCcw,
  Trash2,
  X,
} from 'lucide-react';
import type {
  CoDrawStroke,
  GameActivityTab,
  P2PPacket,
  RpsChoice,
  WatchSyncState,
} from '../types/vault';
import {
  C4_COLS,
  C4_ROWS,
  canPlayConnect4Move,
  canPlayTttMove,
  createConnect4Board,
  evaluateConnect4,
  evaluateTicTacToe,
  getConnect4DropRow,
  getTttStrikeCoords,
  resolvePeerRole,
  resolveRpsRound,
  type C4Board,
  type TttCell,
} from '../engine/gameRules';
import { audioEngine } from '../engine/audioEngine';

interface GamesSpaceModalProps {
  myCode: string;
  peerCode: string;
  peerName: string;
  peerOnline: boolean;
  incomingPacket: { seq: number; packet: P2PPacket } | null;
  onSendPacket: (packet: P2PPacket) => void;
  onClose: () => void;
}

const CODRAW_COLORS = ['#fbbf24', '#fb7185', '#38bdf8', '#a78bfa', '#f8fafc'];

declare global {
  interface Window {
    YT?: {
      Player: new (
        element: HTMLElement | string,
        config: {
          videoId?: string;
          playerVars?: Record<string, number | string>;
          events?: {
            onReady?: (e: { target: YTPlayerInstance }) => void;
            onStateChange?: (e: { data: number; target: YTPlayerInstance }) => void;
          };
        }
      ) => YTPlayerInstance;
      PlayerState?: {
        PLAYING: number;
        PAUSED: number;
      };
    };
    onYouTubeIframeAPIReady?: () => void;
  }
}

interface YTPlayerInstance {
  loadVideoById: (id: string, startSeconds?: number) => void;
  playVideo: () => void;
  pauseVideo: () => void;
  seekTo: (seconds: number, allowSeekAhead: boolean) => void;
  getCurrentTime: () => number;
  getPlayerState: () => number;
  destroy: () => void;
}

export function extractYouTubeVideoId(url: string): string | null {
  const trimmed = url.trim();
  if (!trimmed) return null;
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/shorts\/|youtube\.com\/embed\/)([A-Za-z0-9_-]{11})/,
    /^([A-Za-z0-9_-]{11})$/,
  ];
  for (const rx of patterns) {
    const match = trimmed.match(rx);
    if (match?.[1]) return match[1];
  }
  return null;
}

export const GamesSpaceModal: React.FC<GamesSpaceModalProps> = ({
  myCode,
  peerCode,
  peerName,
  peerOnline,
  incomingPacket,
  onSendPacket,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<GameActivityTab>('rps');
  const myRole = resolvePeerRole(myCode, peerCode);
  const myTttSymbol: 'X' | 'O' = myRole === 'host' ? 'X' : 'O';
  const myC4Disc: 1 | 2 = myRole === 'host' ? 1 : 2;

  /* ---------------- 1. STONE PAPER SCISSOR STATE ---------------- */
  const [rpsRoundId, setRpsRoundId] = useState(1);
  const [myRpsChoice, setMyRpsChoice] = useState<RpsChoice | null>(null);
  const [peerRpsChoice, setPeerRpsChoice] = useState<RpsChoice | null>(null);
  const [rpsCountdown, setRpsCountdown] = useState<number | null>(null);
  const [rpsRevealed, setRpsRevealed] = useState(false);
  const [rpsScore, setRpsScore] = useState({ me: 0, peer: 0, draw: 0 });

  /* ---------------- 2. TIC-TAC-TOE STATE ---------------- */
  const [tttBoard, setTttBoard] = useState<TttCell[]>(Array(9).fill(null));
  const [tttTurn, setTttTurn] = useState<'X' | 'O'>('X');
  const [tttLockedWaiting, setTttLockedWaiting] = useState(false);

  /* ---------------- 3. CONNECT 4 STATE ---------------- */
  const [c4Board, setC4Board] = useState<C4Board>(() => createConnect4Board());
  const [c4Turn, setC4Turn] = useState<1 | 2>(1);
  const [c4LockedWaiting, setC4LockedWaiting] = useState(false);
  const [c4LastDrop, setC4LastDrop] = useState<{ row: number; col: number } | null>(
    null
  );

  /* ---------------- 4. CO-DRAW STATE ---------------- */
  const drawCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [drawColor, setDrawColor] = useState(CODRAW_COLORS[0]);
  const [drawWidth, setDrawWidth] = useState<number>(4);
  const [strokes, setStrokes] = useState<CoDrawStroke[]>([]);
  const activeStrokeRef = useRef<CoDrawStroke | null>(null);

  /* ---------------- 5. WATCH & LISTEN TOGETHER STATE ---------------- */
  const [ytInput, setYtInput] = useState('');
  const [watchState, setWatchState] = useState<WatchSyncState | null>(null);
  const ytContainerRef = useRef<HTMLDivElement | null>(null);
  const ytPlayerRef = useRef<YTPlayerInstance | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioFileInputRef = useRef<HTMLInputElement | null>(null);
  const ignoreNextSyncRef = useRef(false);

  /* ---------------- HANDLE INCOMING P2P GAME PACKETS ---------------- */
  useEffect(() => {
    if (!incomingPacket) return;
    const pkt = incomingPacket.packet;

    if (pkt.type === 'rps_lock') {
      if (pkt.roundId === rpsRoundId) {
        setPeerRpsChoice(pkt.choice);
      }
    } else if (pkt.type === 'rps_reset') {
      setRpsRoundId(pkt.roundId);
      setMyRpsChoice(null);
      setPeerRpsChoice(null);
      setRpsCountdown(null);
      setRpsRevealed(false);
    } else if (pkt.type === 'ttt_move') {
      setTttBoard((prev) => {
        if (prev[pkt.index] !== null) return prev;
        const next = [...prev];
        next[pkt.index] = pkt.symbol;
        return next;
      });
      setTttTurn(pkt.symbol === 'X' ? 'O' : 'X');
      setTttLockedWaiting(false);
      audioEngine.playGameTap();
    } else if (pkt.type === 'ttt_reset') {
      setTttBoard(Array(9).fill(null));
      setTttTurn(pkt.startingRole === 'host' ? 'X' : 'O');
      setTttLockedWaiting(false);
    } else if (pkt.type === 'c4_move') {
      setC4Board((prev) => {
        const row = getConnect4DropRow(prev, pkt.col);
        if (row === -1) return prev;
        const next = prev.map((r) => [...r]);
        next[row][pkt.col] = pkt.disc;
        setC4LastDrop({ row, col: pkt.col });
        return next;
      });
      setC4Turn(pkt.disc === 1 ? 2 : 1);
      setC4LockedWaiting(false);
      audioEngine.playGameTap();
    } else if (pkt.type === 'c4_reset') {
      setC4Board(createConnect4Board());
      setC4Turn(pkt.startingRole === 'host' ? 1 : 2);
      setC4LockedWaiting(false);
      setC4LastDrop(null);
    } else if (pkt.type === 'codraw_stroke') {
      setStrokes((prev) => [...prev, pkt.stroke]);
    } else if (pkt.type === 'codraw_clear') {
      setStrokes([]);
    } else if (pkt.type === 'watch_sync') {
      ignoreNextSyncRef.current = true;
      setWatchState(pkt.state);
    }
  }, [incomingPacket, rpsRoundId]);

  /* ---------------- RPS COUNTDOWN & REVEAL ---------------- */
  useEffect(() => {
    if (!myRpsChoice || !peerRpsChoice || rpsRevealed) return;
    setRpsCountdown(3);
    audioEngine.playGameTap();

    const t1 = window.setTimeout(() => {
      setRpsCountdown(2);
      audioEngine.playGameTap();
    }, 520);
    const t2 = window.setTimeout(() => {
      setRpsCountdown(1);
      audioEngine.playGameTap();
    }, 1040);
    const t3 = window.setTimeout(() => {
      setRpsCountdown(null);
      setRpsRevealed(true);
      const outcome = resolveRpsRound(myRpsChoice, peerRpsChoice);
      setRpsScore((prev) => ({
        me: prev.me + (outcome === 'win' ? 1 : 0),
        peer: prev.peer + (outcome === 'lose' ? 1 : 0),
        draw: prev.draw + (outcome === 'draw' ? 1 : 0),
      }));
      if (outcome === 'win') audioEngine.playGameWin();
      else audioEngine.playGameTap();
    }, 1560);

    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
      window.clearTimeout(t3);
    };
  }, [myRpsChoice, peerRpsChoice, rpsRevealed]);

  const handleRpsPick = (choice: RpsChoice) => {
    if (myRpsChoice) return;
    audioEngine.playGameTap();
    setMyRpsChoice(choice);
    if (peerOnline) {
      onSendPacket({
        type: 'rps_lock',
        fromCode: myCode,
        roundId: rpsRoundId,
        choice,
      });
    } else {
      // Offline preview opponent pick so game remains testable locally
      const choices: RpsChoice[] = ['rock', 'paper', 'scissors'];
      const sim = choices[Math.floor(Math.random() * choices.length)];
      window.setTimeout(() => setPeerRpsChoice(sim), 380);
    }
  };

  const handleRpsReset = () => {
    const nextRound = rpsRoundId + 1;
    setRpsRoundId(nextRound);
    setMyRpsChoice(null);
    setPeerRpsChoice(null);
    setRpsCountdown(null);
    setRpsRevealed(false);
    if (peerOnline) {
      onSendPacket({ type: 'rps_reset', fromCode: myCode, roundId: nextRound });
    }
  };

  /* ---------------- TIC-TAC-TOE HANDLERS ---------------- */
  const tttResult = evaluateTicTacToe(tttBoard);

  const handleTttCellTap = (index: number) => {
    const effectiveSymbol = peerOnline ? myTttSymbol : tttTurn;
    if (
      !canPlayTttMove({
        board: tttBoard,
        index,
        mySymbol: effectiveSymbol,
        currentTurn: tttTurn,
        lockedWaitingPeer: peerOnline ? tttLockedWaiting : false,
      })
    ) {
      return;
    }

    audioEngine.playGameTap();
    const nextBoard = [...tttBoard];
    nextBoard[index] = effectiveSymbol;
    setTttBoard(nextBoard);
    const res = evaluateTicTacToe(nextBoard);
    if (res.winner === effectiveSymbol) {
      audioEngine.playGameWin();
    }

    const nextTurn = effectiveSymbol === 'X' ? 'O' : 'X';
    setTttTurn(nextTurn);

    if (peerOnline) {
      // Strictly lock grid immediately after 1 tap until opponent move arrives
      setTttLockedWaiting(true);
      onSendPacket({
        type: 'ttt_move',
        fromCode: myCode,
        index,
        symbol: effectiveSymbol,
      });
    }
  };

  const handleTttReset = () => {
    setTttBoard(Array(9).fill(null));
    setTttTurn('X');
    setTttLockedWaiting(false);
    if (peerOnline) {
      onSendPacket({
        type: 'ttt_reset',
        fromCode: myCode,
        startingRole: 'host',
      });
    }
  };

  /* ---------------- CONNECT 4 HANDLERS ---------------- */
  const c4Result = evaluateConnect4(c4Board);

  const handleC4ColTap = (col: number) => {
    const effectiveDisc = peerOnline ? myC4Disc : c4Turn;
    if (
      !canPlayConnect4Move({
        board: c4Board,
        col,
        myDisc: effectiveDisc,
        currentTurn: c4Turn,
        lockedWaitingPeer: peerOnline ? c4LockedWaiting : false,
      })
    ) {
      return;
    }

    const row = getConnect4DropRow(c4Board, col);
    if (row === -1) return;

    audioEngine.playGameTap();
    const nextBoard = c4Board.map((r) => [...r]);
    nextBoard[row][col] = effectiveDisc;
    setC4Board(nextBoard);
    setC4LastDrop({ row, col });

    const res = evaluateConnect4(nextBoard);
    if (res.winner === effectiveDisc) {
      audioEngine.playGameWin();
    }

    setC4Turn(effectiveDisc === 1 ? 2 : 1);

    if (peerOnline) {
      setC4LockedWaiting(true);
      onSendPacket({
        type: 'c4_move',
        fromCode: myCode,
        col,
        disc: effectiveDisc,
      });
    }
  };

  const handleC4Reset = () => {
    setC4Board(createConnect4Board());
    setC4Turn(1);
    setC4LockedWaiting(false);
    setC4LastDrop(null);
    if (peerOnline) {
      onSendPacket({
        type: 'c4_reset',
        fromCode: myCode,
        startingRole: 'host',
      });
    }
  };

  /* ---------------- CO-DRAW QUADRATIC BEZIER ENGINE ---------------- */
  const renderAllStrokes = useCallback(() => {
    const canvas = drawCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    const drawStroke = (stroke: CoDrawStroke) => {
      if (stroke.points.length < 2) return;
      ctx.save();
      ctx.strokeStyle = stroke.color;
      ctx.lineWidth = stroke.width;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.shadowColor = stroke.color;
      ctx.shadowBlur = 4;

      ctx.beginPath();
      const p0 = stroke.points[0];
      ctx.moveTo(p0.x * w, p0.y * h);

      for (let i = 1; i < stroke.points.length - 1; i++) {
        const curr = stroke.points[i];
        const next = stroke.points[i + 1];
        const midX = ((curr.x + next.x) / 2) * w;
        const midY = ((curr.y + next.y) / 2) * h;
        ctx.quadraticCurveTo(curr.x * w, curr.y * h, midX, midY);
      }

      const last = stroke.points[stroke.points.length - 1];
      ctx.lineTo(last.x * w, last.y * h);
      ctx.stroke();
      ctx.restore();
    };

    for (const s of strokes) {
      drawStroke(s);
    }
    if (activeStrokeRef.current) {
      drawStroke(activeStrokeRef.current);
    }
  }, [strokes]);

  useEffect(() => {
    if (activeTab === 'codraw') {
      renderAllStrokes();
    }
  }, [activeTab, renderAllStrokes]);

  const getNormPoint = (
    e: React.PointerEvent<HTMLCanvasElement>
  ): { x: number; y: number } => {
    const rect = e.currentTarget.getBoundingClientRect();
    return {
      x: Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width)),
      y: Math.min(1, Math.max(0, (e.clientY - rect.top) / rect.height)),
    };
  };

  const onDrawPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    const pt = getNormPoint(e);
    activeStrokeRef.current = {
      id: `stk_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      color: drawColor,
      width: drawWidth,
      points: [pt, pt],
    };
    renderAllStrokes();
  };

  const onDrawPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!activeStrokeRef.current) return;
    const pt = getNormPoint(e);
    activeStrokeRef.current.points.push(pt);
    renderAllStrokes();
  };

  const onDrawPointerUp = () => {
    if (!activeStrokeRef.current) return;
    const finished = activeStrokeRef.current;
    activeStrokeRef.current = null;
    setStrokes((prev) => [...prev, finished]);
    if (peerOnline) {
      onSendPacket({
        type: 'codraw_stroke',
        fromCode: myCode,
        stroke: finished,
      });
    }
  };

  const handleClearCoDraw = () => {
    setStrokes([]);
    if (peerOnline) {
      onSendPacket({ type: 'codraw_clear', fromCode: myCode });
    }
  };

  /* ---------------- WATCH & LISTEN TOGETHER (YOUTUBE IFRAME API + MP3) ---------------- */
  useEffect(() => {
    if (activeTab !== 'watch' || watchState?.sourceType !== 'youtube' || !watchState.youtubeId) {
      return;
    }

    const mountPlayer = () => {
      if (!ytContainerRef.current || !window.YT?.Player) return;
      if (!ytPlayerRef.current) {
        ytPlayerRef.current = new window.YT.Player(ytContainerRef.current, {
          videoId: watchState.youtubeId,
          playerVars: {
            playsinline: 1,
            rel: 0,
            modestbranding: 1,
          },
          events: {
            onReady: (ev) => {
              if (watchState.currentTimeSec > 0) {
                ev.target.seekTo(watchState.currentTimeSec, true);
              }
              if (watchState.playing) ev.target.playVideo();
            },
            onStateChange: (ev) => {
              if (ignoreNextSyncRef.current) {
                ignoreNextSyncRef.current = false;
                return;
              }
              const playingState = window.YT?.PlayerState?.PLAYING ?? 1;
              const pausedState = window.YT?.PlayerState?.PAUSED ?? 2;
              if (ev.data === playingState || ev.data === pausedState) {
                const nextState: WatchSyncState = {
                  sourceType: 'youtube',
                  youtubeId: watchState.youtubeId,
                  playing: ev.data === playingState,
                  currentTimeSec: ev.target.getCurrentTime() || 0,
                  updatedAt: Date.now(),
                  updatedByCode: myCode,
                };
                setWatchState(nextState);
                if (peerOnline) {
                  onSendPacket({ type: 'watch_sync', fromCode: myCode, state: nextState });
                }
              }
            },
          },
        });
      } else {
        const player = ytPlayerRef.current;
        if (ignoreNextSyncRef.current) {
          ignoreNextSyncRef.current = false;
          if (Math.abs((player.getCurrentTime?.() || 0) - watchState.currentTimeSec) > 1.5) {
            player.seekTo(watchState.currentTimeSec, true);
          }
          if (watchState.playing) player.playVideo();
          else player.pauseVideo();
        }
      }
    };

    if (window.YT?.Player) {
      mountPlayer();
    } else {
      const existingScript = document.querySelector(
        'script[src="https://www.youtube.com/iframe_api"]'
      );
      if (!existingScript) {
        const script = document.createElement('script');
        script.src = 'https://www.youtube.com/iframe_api';
        document.body.appendChild(script);
      }
      window.onYouTubeIframeAPIReady = mountPlayer;
    }
  }, [activeTab, myCode, onSendPacket, peerOnline, watchState]);

  useEffect(() => {
    if (
      watchState?.sourceType === 'audio' &&
      audioRef.current &&
      ignoreNextSyncRef.current
    ) {
      ignoreNextSyncRef.current = false;
      const el = audioRef.current;
      if (Math.abs(el.currentTime - watchState.currentTimeSec) > 1.2) {
        el.currentTime = watchState.currentTimeSec;
      }
      if (watchState.playing) {
        void el.play().catch(() => {});
      } else {
        el.pause();
      }
    }
  }, [watchState]);

  useEffect(() => {
    return () => {
      try {
        ytPlayerRef.current?.destroy();
      } catch {
        // ignore
      }
      ytPlayerRef.current = null;
    };
  }, []);

  const handleLoadYoutube = (e: React.FormEvent) => {
    e.preventDefault();
    const id = extractYouTubeVideoId(ytInput);
    if (!id) return;
    if (ytPlayerRef.current) {
      ytPlayerRef.current.loadVideoById(id, 0);
    }
    const next: WatchSyncState = {
      sourceType: 'youtube',
      youtubeId: id,
      playing: true,
      currentTimeSec: 0,
      updatedAt: Date.now(),
      updatedByCode: myCode,
    };
    setWatchState(next);
    if (peerOnline) {
      onSendPacket({ type: 'watch_sync', fromCode: myCode, state: next });
    }
  };

  const handleAudioUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result || '');
      const next: WatchSyncState = {
        sourceType: 'audio',
        audioName: file.name,
        audioDataUrl: dataUrl,
        playing: false,
        currentTimeSec: 0,
        updatedAt: Date.now(),
        updatedByCode: myCode,
      };
      setWatchState(next);
      if (peerOnline) {
        onSendPacket({ type: 'watch_sync', fromCode: myCode, state: next });
      }
    };
    reader.readAsDataURL(file);
  };

  const toggleLocalAudio = () => {
    if (!audioRef.current || !watchState || watchState.sourceType !== 'audio') return;
    const el = audioRef.current;
    const willPlay = el.paused;
    if (willPlay) void el.play().catch(() => {});
    else el.pause();

    const next: WatchSyncState = {
      ...watchState,
      playing: willPlay,
      currentTimeSec: el.currentTime || 0,
      updatedAt: Date.now(),
      updatedByCode: myCode,
    };
    setWatchState(next);
    if (peerOnline) {
      onSendPacket({ type: 'watch_sync', fromCode: myCode, state: next });
    }
  };

  /* ---------------- RENDER ---------------- */
  const tabs: Array<{ id: GameActivityTab; label: string; emoji: string }> = [
    { id: 'rps', label: 'RPS', emoji: '✊' },
    { id: 'ttt', label: 'Tic-Tac-Toe', emoji: '⭕' },
    { id: 'connect4', label: 'Connect 4', emoji: '🔴' },
    { id: 'codraw', label: 'Co-Draw', emoji: '🎨' },
    { id: 'watch', label: 'Watch', emoji: '🎬' },
  ];

  const rpsOutcome =
    rpsRevealed && myRpsChoice && peerRpsChoice
      ? resolveRpsRound(myRpsChoice, peerRpsChoice)
      : null;

  const rpsEmojiMap: Record<RpsChoice, string> = {
    rock: '✊',
    paper: '✋',
    scissors: '✌️',
  };

  const tttStatusText = (() => {
    if (tttResult.winner === 'draw') return 'Draw Match';
    if (tttResult.winner) {
      if (!peerOnline) return `${tttResult.winner} Wins!`;
      return tttResult.winner === myTttSymbol ? 'You Won!' : `${peerName} Won`;
    }
    if (!peerOnline) return `Local Turn: ${tttTurn}`;
    if (tttLockedWaiting || tttTurn !== myTttSymbol) {
      return `Turn Locked · Waiting for ${peerName}`;
    }
    return `Your Turn (${myTttSymbol})`;
  })();

  const c4StatusText = (() => {
    if (c4Result.winner === 'draw') return 'Board Full · Draw';
    if (c4Result.winner) {
      if (!peerOnline)
        return c4Result.winner === 1 ? 'Rose Discs Win!' : 'Amber Discs Win!';
      return c4Result.winner === myC4Disc ? 'You Won!' : `${peerName} Won`;
    }
    if (!peerOnline)
      return c4Turn === 1 ? 'Turn: Rose Disc' : 'Turn: Amber Disc';
    if (c4LockedWaiting || c4Turn !== myC4Disc) {
      return `Turn Locked · Waiting for ${peerName}`;
    }
    return `Your Turn (${myC4Disc === 1 ? 'Rose' : 'Amber'})`;
  })();

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Games and Shared Space"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/65 backdrop-blur-sm sm:px-4"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="glass-surface-elevated glass-specular-rim sheet-enter w-full max-w-[580px] max-h-[90vh] rounded-t-[30px] sm:rounded-[30px] flex flex-col overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.08] shrink-0">
          <div>
            <h2 className="text-base font-semibold text-white">
              Games &amp; Shared Space
            </h2>
            <p className="text-[11px] text-white/55">
              {peerOnline
                ? `Live P2P Synced with ${peerName}`
                : `Offline Practice Mode (${peerName} offline)`}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Games and Shared Space"
            className="w-9 h-9 rounded-full bg-white/[0.06] hover:bg-white/[0.12] flex items-center justify-center text-white/75"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Activity Switcher */}
        <div className="px-4 pt-3 pb-2 border-b border-white/[0.06] flex items-center gap-1.5 overflow-x-auto shrink-0">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`h-9 px-3.5 rounded-xl text-xs font-medium whitespace-nowrap shrink-0 flex items-center gap-1.5 transition-all ${
                activeTab === tab.id
                  ? 'bg-amber-400 text-stone-950 font-semibold'
                  : 'bg-white/[0.05] text-white/70 hover:text-white hover:bg-white/[0.1]'
              }`}
            >
              <span aria-hidden="true">{tab.emoji}</span>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto vault-scroll flex-1">
          {/* 1. STONE PAPER SCISSOR */}
          {activeTab === 'rps' && (
            <div className="flex flex-col items-center gap-5">
              {/* Scoreboard */}
              <div className="w-full grid grid-cols-3 gap-2 glass-subtle rounded-2xl p-3 text-center">
                <div>
                  <div className="text-[11px] text-white/55">You</div>
                  <div className="text-xl font-bold text-amber-300 tabular-nums">
                    {rpsScore.me}
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-white/55">Draws</div>
                  <div className="text-xl font-bold text-white/80 tabular-nums">
                    {rpsScore.draw}
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-white/55 truncate">
                    {peerName}
                  </div>
                  <div className="text-xl font-bold text-rose-300 tabular-nums">
                    {rpsScore.peer}
                  </div>
                </div>
              </div>

              {/* Arena */}
              <div className="w-full glass-subtle rounded-3xl p-6 flex items-center justify-around min-h-[150px]">
                <div className="flex flex-col items-center gap-2">
                  <div
                    className={`w-20 h-20 rounded-2xl bg-white/[0.06] border border-white/15 flex items-center justify-center text-4xl ${
                      rpsCountdown !== null ? 'animate-bounce' : ''
                    }`}
                  >
                    {rpsCountdown !== null
                      ? '✊'
                      : myRpsChoice
                        ? rpsEmojiMap[myRpsChoice]
                        : '❓'}
                  </div>
                  <span className="text-xs text-white/70">
                    {myRpsChoice ? 'Locked In' : 'Choose'}
                  </span>
                </div>

                <div className="text-center">
                  {rpsCountdown !== null ? (
                    <span className="text-3xl font-bold text-amber-300 tabular-nums">
                      {rpsCountdown}
                    </span>
                  ) : rpsOutcome ? (
                    <span
                      className={`text-sm font-bold px-3 py-1.5 rounded-xl ${
                        rpsOutcome === 'win'
                          ? 'bg-amber-400/20 text-amber-200 border border-amber-300/40'
                          : rpsOutcome === 'lose'
                            ? 'bg-rose-500/20 text-rose-200 border border-rose-400/40'
                            : 'bg-white/10 text-white'
                      }`}
                    >
                      {rpsOutcome === 'win'
                        ? 'You Win!'
                        : rpsOutcome === 'lose'
                          ? `${peerName} Wins`
                          : 'Draw!'}
                    </span>
                  ) : (
                    <span className="text-xs text-white/45">VS</span>
                  )}
                </div>

                <div className="flex flex-col items-center gap-2">
                  <div
                    className={`w-20 h-20 rounded-2xl bg-white/[0.06] border border-white/15 flex items-center justify-center text-4xl ${
                      rpsCountdown !== null ? 'animate-bounce' : ''
                    }`}
                  >
                    {rpsCountdown !== null
                      ? '✊'
                      : rpsRevealed && peerRpsChoice
                        ? rpsEmojiMap[peerRpsChoice]
                        : peerRpsChoice
                          ? '🔒'
                          : '⏳'}
                  </div>
                  <span className="text-xs text-white/70 truncate max-w-[90px]">
                    {peerRpsChoice ? 'Locked' : 'Waiting'}
                  </span>
                </div>
              </div>

              {/* Secret Choice Controls */}
              <div className="w-full grid grid-cols-3 gap-2.5">
                {(['rock', 'paper', 'scissors'] as RpsChoice[]).map((choice) => (
                  <button
                    key={choice}
                    type="button"
                    disabled={Boolean(myRpsChoice)}
                    onClick={() => handleRpsPick(choice)}
                    className={`h-14 rounded-2xl border flex items-center justify-center gap-2 text-sm font-semibold capitalize transition-all ${
                      myRpsChoice === choice
                        ? 'bg-amber-400/25 border-amber-300 text-amber-200'
                        : 'bg-white/[0.06] border-white/[0.12] text-white hover:bg-white/[0.12] disabled:opacity-45'
                    }`}
                  >
                    <span className="text-xl">{rpsEmojiMap[choice]}</span>
                    <span>{choice}</span>
                  </button>
                ))}
              </div>

              {rpsRevealed && (
                <button
                  type="button"
                  onClick={handleRpsReset}
                  className="px-5 py-2.5 rounded-xl bg-amber-400 text-stone-950 text-xs font-semibold flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Play Next Round</span>
                </button>
              )}
            </div>
          )}

          {/* 2. TIC-TAC-TOE (STRICTLY 1-TOUCH TURN LOCKED) */}
          {activeTab === 'ttt' && (
            <div className="flex flex-col items-center gap-4">
              <div className="w-full flex items-center justify-between px-1">
                <span
                  data-testid="ttt-status"
                  className="text-xs font-semibold text-amber-200"
                >
                  {tttStatusText}
                </span>
                <button
                  type="button"
                  onClick={handleTttReset}
                  className="px-3 py-1.5 rounded-xl bg-white/[0.08] hover:bg-white/[0.14] text-xs text-white flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset</span>
                </button>
              </div>

              <div className="relative w-full max-w-[300px] aspect-square">
                <div
                  className={`grid grid-cols-3 gap-2.5 w-full h-full ${
                    peerOnline && (tttLockedWaiting || tttTurn !== myTttSymbol)
                      ? 'opacity-75 pointer-events-none'
                      : ''
                  }`}
                >
                  {tttBoard.map((cell, idx) => (
                    <button
                      key={idx}
                      type="button"
                      aria-label={`Tic Tac Toe cell ${idx + 1} ${cell || 'empty'}`}
                      onClick={() => handleTttCellTap(idx)}
                      className="glass-subtle rounded-2xl flex items-center justify-center text-3xl font-bold hover:bg-white/[0.12] transition-all"
                    >
                      <span
                        className={
                          cell === 'X' ? 'text-amber-300' : 'text-rose-300'
                        }
                      >
                        {cell}
                      </span>
                    </button>
                  ))}
                </div>

                {/* Glowing SVG Strike-Through on Win */}
                {tttResult.line && (
                  <svg
                    viewBox="0 0 300 300"
                    className="absolute inset-0 w-full h-full pointer-events-none"
                  >
                    {(() => {
                      const coords = getTttStrikeCoords(tttResult.line);
                      return (
                        <line
                          x1={coords.x1}
                          y1={coords.y1}
                          x2={coords.x2}
                          y2={coords.y2}
                          stroke="#fbbf24"
                          strokeWidth="8"
                          strokeLinecap="round"
                          style={{
                            filter:
                              'drop-shadow(0 0 10px rgba(251, 191, 36, 0.9))',
                          }}
                        />
                      );
                    })()}
                  </svg>
                )}
              </div>
            </div>
          )}

          {/* 3. CONNECT 4 (6x7 DROP STRATEGY) */}
          {activeTab === 'connect4' && (
            <div className="flex flex-col items-center gap-4">
              <div className="w-full flex items-center justify-between px-1">
                <span
                  data-testid="c4-status"
                  className="text-xs font-semibold text-amber-200"
                >
                  {c4StatusText}
                </span>
                <button
                  type="button"
                  onClick={handleC4Reset}
                  className="px-3 py-1.5 rounded-xl bg-white/[0.08] hover:bg-white/[0.14] text-xs text-white flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset</span>
                </button>
              </div>

              <div
                className={`w-full max-w-[364px] glass-subtle rounded-3xl p-3 flex flex-col gap-2 ${
                  peerOnline && (c4LockedWaiting || c4Turn !== myC4Disc)
                    ? 'opacity-80 pointer-events-none'
                    : ''
                }`}
              >
                {/* Column Drop Buttons */}
                <div className="grid grid-cols-7 gap-1.5">
                  {Array.from({ length: C4_COLS }, (_, col) => (
                    <button
                      key={col}
                      type="button"
                      aria-label={`Drop disc in column ${col + 1}`}
                      onClick={() => handleC4ColTap(col)}
                      className="h-8 rounded-lg bg-white/[0.07] hover:bg-amber-400/25 text-[11px] font-semibold text-white/75 hover:text-amber-200 transition-colors"
                    >
                      ↓
                    </button>
                  ))}
                </div>

                {/* 6x7 Grid */}
                <div className="grid grid-cols-7 gap-1.5">
                  {Array.from({ length: C4_ROWS }, (_, r) =>
                    Array.from({ length: C4_COLS }, (_, c) => {
                      const val = c4Board[r][c];
                      const isWinCell = c4Result.cells.some(
                        ([wr, wc]) => wr === r && wc === c
                      );
                      const isNewDrop =
                        c4LastDrop?.row === r && c4LastDrop?.col === c;
                      return (
                        <button
                          key={`${r}-${c}`}
                          type="button"
                          aria-label={`Connect 4 row ${r + 1} column ${c + 1}`}
                          onClick={() => handleC4ColTap(c)}
                          className="aspect-square rounded-full bg-black/45 border border-white/[0.08] p-1 flex items-center justify-center"
                        >
                          {val !== 0 && (
                            <span
                              className={`w-full h-full rounded-full ${
                                isNewDrop ? 'connect4-disc-drop' : ''
                              } ${
                                val === 1
                                  ? 'bg-gradient-to-br from-rose-400 to-rose-600'
                                  : 'bg-gradient-to-br from-amber-300 to-amber-500'
                              } ${
                                isWinCell
                                  ? 'ring-2 ring-white shadow-[0_0_14px_#fbbf24]'
                                  : ''
                              }`}
                            />
                          )}
                        </button>
                      );
                    })
                  )}
                </div>
              </div>
            </div>
          )}

          {/* 4. MINIMAL LIVE CO-DRAW */}
          {activeTab === 'codraw' && (
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-2">
                  <Palette className="w-4 h-4 text-amber-300" />
                  {CODRAW_COLORS.map((col) => (
                    <button
                      key={col}
                      type="button"
                      aria-label={`Brush color ${col}`}
                      onClick={() => setDrawColor(col)}
                      className={`w-7 h-7 rounded-full border-2 transition-transform ${
                        drawColor === col
                          ? 'scale-115 border-white'
                          : 'border-white/25'
                      }`}
                      style={{ backgroundColor: col }}
                    />
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setDrawWidth((w) => (w === 4 ? 9 : 4))}
                    className="h-8 px-3 rounded-xl bg-white/[0.08] text-xs text-white/85"
                  >
                    {drawWidth === 4 ? 'Fine' : 'Bold'}
                  </button>
                  <button
                    type="button"
                    onClick={handleClearCoDraw}
                    className="h-8 px-3 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-xs text-rose-200 flex items-center gap-1"
                  >
                    <Eraser className="w-3.5 h-3.5" />
                    <span>Clear</span>
                  </button>
                </div>
              </div>

              <canvas
                ref={drawCanvasRef}
                width={520}
                height={310}
                onPointerDown={onDrawPointerDown}
                onPointerMove={onDrawPointerMove}
                onPointerUp={onDrawPointerUp}
                onPointerCancel={onDrawPointerUp}
                data-testid="codraw-canvas"
                className="w-full h-[270px] rounded-2xl bg-black/45 border border-white/[0.12] cursor-crosshair touch-none"
              />
            </div>
          )}

          {/* 5. WATCH & LISTEN TOGETHER */}
          {activeTab === 'watch' && (
            <div className="flex flex-col gap-4">
              {/* YouTube / Shorts URL Input */}
              <form onSubmit={handleLoadYoutube} className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Film className="w-4 h-4 text-amber-300 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={ytInput}
                    onChange={(e) => setYtInput(e.target.value)}
                    placeholder="Paste YouTube or Shorts URL..."
                    className="w-full h-11 pl-10 pr-3 rounded-xl bg-white/[0.06] border border-white/[0.12] text-xs text-white placeholder:text-white/40 focus:outline-none focus:border-amber-300/60"
                  />
                </div>
                <button
                  type="submit"
                  className="h-11 px-4 rounded-xl bg-amber-400 hover:bg-amber-300 text-stone-950 text-xs font-semibold shrink-0"
                >
                  Sync Video
                </button>
              </form>

              {/* Local MP3 / Audio Picker */}
              <div className="flex items-center justify-between glass-subtle rounded-2xl p-3">
                <div className="flex items-center gap-2.5">
                  <Music className="w-4 h-4 text-amber-300" />
                  <span className="text-xs text-white/80">
                    {watchState?.sourceType === 'audio'
                      ? watchState.audioName
                      : 'Or share a local MP3 / Audio track'}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {watchState?.sourceType === 'audio' && (
                    <button
                      type="button"
                      onClick={toggleLocalAudio}
                      className="h-8 px-3 rounded-xl bg-amber-400 text-stone-950 text-xs font-semibold flex items-center gap-1"
                    >
                      {watchState.playing ? (
                        <Pause className="w-3.5 h-3.5" />
                      ) : (
                        <Play className="w-3.5 h-3.5" />
                      )}
                      <span>{watchState.playing ? 'Pause' : 'Play'}</span>
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => audioFileInputRef.current?.click()}
                    className="h-8 px-3 rounded-xl bg-white/[0.08] hover:bg-white/[0.14] text-xs text-white"
                  >
                    Choose MP3
                  </button>
                  <input
                    ref={audioFileInputRef}
                    type="file"
                    accept="audio/*"
                    onChange={handleAudioUpload}
                    className="hidden"
                  />
                </div>
              </div>

              {/* Player Surface */}
              {watchState?.sourceType === 'youtube' && watchState.youtubeId ? (
                <div className="w-full aspect-video rounded-2xl overflow-hidden bg-black border border-white/10">
                  <div ref={ytContainerRef} className="w-full h-full" />
                </div>
              ) : watchState?.sourceType === 'audio' && watchState.audioDataUrl ? (
                <div className="glass-subtle rounded-2xl p-4 flex items-center justify-between gap-3">
                  <audio
                    ref={audioRef}
                    src={watchState.audioDataUrl}
                    controls
                    className="w-full"
                  />
                  <button
                    type="button"
                    onClick={() => setWatchState(null)}
                    aria-label="Clear audio"
                    className="w-9 h-9 rounded-xl bg-white/[0.06] flex items-center justify-center text-white/65"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="glass-subtle rounded-2xl p-8 text-center text-xs text-white/55">
                  Paste any YouTube / Shorts link or pick an MP3 to watch and
                  listen in sync.
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

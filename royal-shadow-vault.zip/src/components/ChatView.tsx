/* ============================================================================
 * MINIMALIST CHAT VIEW
 * - Clean Chat Header: Back, Friend DP (Golden Glow), Name, Online/Offline,
 *   Voice Call (📞), Video Call (📹), minimal ⋮ menu (Nickname, Mute, Clear Both)
 * - Clean Bottom Composer: 📷 (Normal / 2s View-Once), ✨ FX Drawer, 🎮 Games,
 *   minimal text input, 🎙️ Voice Note recorder, ➤ Send
 * - Essential Messaging: Text, typing indicator, golden ✓✓ seen receipts,
 *   tap-to-react, reply/quote, edit & unsend for everyone, Auto-Vanish timer
 * ============================================================================ */

import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  Bell,
  BellOff,
  Camera,
  Check,
  CheckCheck,
  Edit3,
  Eye,
  Gamepad2,
  Mic,
  MoreVertical,
  Pause,
  Phone,
  Play,
  Reply,
  Send,
  Sparkles,
  Square,
  Trash2,
  Video,
  X,
} from 'lucide-react';
import type {
  ChatMessage,
  FontSizeOption,
  FriendContact,
  MessageReplyRef,
} from '../types/vault';
import { compressImageFile } from '../engine/storage';

interface ChatViewProps {
  myCode: string;
  friend: FriendContact;
  isOnline: boolean;
  isPeerTyping: boolean;
  messages: ChatMessage[];
  fontSize: FontSizeOption;
  autoVanishSec: number;
  onBack: () => void;
  onSendText: (text: string, replyTo?: MessageReplyRef) => void;
  onSendPhoto: (dataUrl: string, viewOnce: boolean) => void;
  onSendVoice: (dataUrl: string, durationSec: number) => void;
  onReactMessage: (messageId: string, emoji: string) => void;
  onEditMessage: (messageId: string, newText: string) => void;
  onUnsendMessage: (messageId: string) => void;
  onOpenViewOnce: (message: ChatMessage) => void;
  onTypingChange: (isTyping: boolean) => void;
  onOpenFxDrawer: () => void;
  onOpenGames: () => void;
  onStartCall: (mode: 'voice' | 'video') => void;
  onSetNickname: (nickname: string) => void;
  onToggleMute: () => void;
  onClearChatBothSides: () => void;
}

const CURATED_REACTIONS = ['❤️', '💋', '🔥', '✨', '👻'];

export const ChatView: React.FC<ChatViewProps> = ({
  myCode,
  friend,
  isOnline,
  isPeerTyping,
  messages,
  fontSize,
  autoVanishSec,
  onBack,
  onSendText,
  onSendPhoto,
  onSendVoice,
  onReactMessage,
  onEditMessage,
  onUnsendMessage,
  onOpenViewOnce,
  onTypingChange,
  onOpenFxDrawer,
  onOpenGames,
  onStartCall,
  onSetNickname,
  onToggleMute,
  onClearChatBothSides,
}) => {
  const [draft, setDraft] = useState('');
  const [replyTo, setReplyTo] = useState<MessageReplyRef | null>(null);
  const [editingMsgId, setEditingMsgId] = useState<string | null>(null);
  const [selectedMsgId, setSelectedMsgId] = useState<string | null>(null);
  const [showMenu, setShowMenu] = useState(false);
  const [showNicknamePrompt, setShowNicknamePrompt] = useState(false);
  const [nicknameDraft, setNicknameDraft] = useState(friend.nickname || '');
  const [showMediaChoice, setShowMediaChoice] = useState(false);

  // Voice Note Recording State
  const [recording, setRecording] = useState(false);
  const [recSeconds, setRecSeconds] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recChunksRef = useRef<Blob[]>([]);
  const recTimerRef = useRef<number | null>(null);
  const recStartedAtRef = useRef<number>(0);

  const photoNormalInputRef = useRef<HTMLInputElement | null>(null);
  const photoViewOnceInputRef = useRef<HTMLInputElement | null>(null);
  const scrollEndRef = useRef<HTMLDivElement | null>(null);
  const typingTimeoutRef = useRef<number | null>(null);

  const displayTitle = friend.nickname || friend.displayName;

  useEffect(() => {
    scrollEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length, isPeerTyping]);

  useEffect(() => {
    return () => {
      if (recTimerRef.current !== null) window.clearInterval(recTimerRef.current);
      if (typingTimeoutRef.current !== null) window.clearTimeout(typingTimeoutRef.current);
    };
  }, []);

  const handleInputChange = (val: string) => {
    setDraft(val);
    onTypingChange(val.trim().length > 0);
    if (typingTimeoutRef.current !== null) {
      window.clearTimeout(typingTimeoutRef.current);
    }
    typingTimeoutRef.current = window.setTimeout(() => {
      onTypingChange(false);
    }, 1800);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = draft.trim();
    if (!cleaned) return;

    if (editingMsgId) {
      onEditMessage(editingMsgId, cleaned);
      setEditingMsgId(null);
      setDraft('');
      onTypingChange(false);
      return;
    }

    onSendText(cleaned, replyTo ?? undefined);
    setDraft('');
    setReplyTo(null);
    onTypingChange(false);
  };

  const handlePhotoFile = async (
    e: React.ChangeEvent<HTMLInputElement>,
    viewOnce: boolean
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    setShowMediaChoice(false);
    if (!file) return;
    try {
      const compressed = await compressImageFile(file, 960, 0.78);
      onSendPhoto(compressed, viewOnce);
    } catch {
      // ignore invalid image
    }
  };

  const startVoiceRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      recChunksRef.current = [];
      mediaRecorderRef.current = recorder;
      recStartedAtRef.current = Date.now();
      setRecSeconds(0);
      setRecording(true);

      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) recChunksRef.current.push(ev.data);
      };

      recorder.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(recChunksRef.current, { type: 'audio/webm' });
        const dur = Math.max(
          1,
          Math.round((Date.now() - recStartedAtRef.current) / 1000)
        );
        const reader = new FileReader();
        reader.onload = () => {
          onSendVoice(String(reader.result || ''), dur);
        };
        reader.readAsDataURL(blob);
      };

      recorder.start();
      recTimerRef.current = window.setInterval(() => {
        setRecSeconds((s) => s + 1);
      }, 1000);
    } catch {
      setRecording(false);
    }
  };

  const stopVoiceRecording = () => {
    if (recTimerRef.current !== null) {
      window.clearInterval(recTimerRef.current);
      recTimerRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    setRecording(false);
  };

  const textSizeClass =
    fontSize === 'small'
      ? 'text-xs'
      : fontSize === 'large'
        ? 'text-base'
        : 'text-sm';

  return (
    <main className="relative z-10 w-full h-full flex flex-col items-center sm:py-4 sm:px-4 overflow-hidden">
      <div className="w-full max-w-[780px] h-full flex flex-col sm:glass-surface sm:rounded-[30px] overflow-hidden">
        {/* Clean Chat Header */}
        <header className="glass-surface sm:bg-transparent sm:backdrop-blur-none sm:border-0 sm:border-b sm:border-white/[0.08] px-3 sm:px-5 py-3 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <button
              type="button"
              onClick={onBack}
              aria-label="Back to Vault Home"
              className="w-10 h-10 rounded-full hover:bg-white/[0.08] flex items-center justify-center text-white/85 shrink-0"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            <div className="relative shrink-0">
              <img
                src={friend.avatarDataUrl}
                alt={displayTitle}
                referrerPolicy="no-referrer"
                className={`w-10 h-10 rounded-full object-cover ${
                  isOnline ? 'golden-aura-ring' : 'border border-white/15'
                }`}
              />
              <span
                className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-[#120b14] ${
                  isOnline
                    ? 'bg-amber-400 shadow-[0_0_8px_#fbbf24]'
                    : 'bg-white/30'
                }`}
              />
            </div>

            <div className="min-w-0">
              <h1 className="text-sm font-semibold text-white truncate">
                {displayTitle}
              </h1>
              <div className="text-[11px] text-white/60 flex items-center gap-1.5">
                <span className={isOnline ? 'text-amber-300' : ''}>
                  {isPeerTyping
                    ? 'typing...'
                    : isOnline
                      ? 'Online'
                      : 'Offline'}
                </span>
                {autoVanishSec > 0 && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums">Vanish {autoVanishSec}s</span>
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0 relative">
            <button
              type="button"
              onClick={() => onStartCall('voice')}
              aria-label="Voice Call"
              className="w-10 h-10 rounded-full hover:bg-white/[0.08] flex items-center justify-center text-white/85"
            >
              <Phone className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => onStartCall('video')}
              aria-label="Video Call"
              className="w-10 h-10 rounded-full hover:bg-white/[0.08] flex items-center justify-center text-white/85"
            >
              <Video className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setShowMenu((m) => !m)}
              aria-label="Chat options menu"
              className="w-10 h-10 rounded-full hover:bg-white/[0.08] flex items-center justify-center text-white/85"
            >
              <MoreVertical className="w-4 h-4" />
            </button>

            {showMenu && (
              <div className="absolute right-0 top-12 z-30 w-52 glass-surface-elevated rounded-2xl p-1.5 flex flex-col gap-0.5 shadow-2xl">
                <button
                  type="button"
                  onClick={() => {
                    setShowMenu(false);
                    setNicknameDraft(friend.nickname || '');
                    setShowNicknamePrompt(true);
                  }}
                  className="w-full px-3 py-2.5 rounded-xl hover:bg-white/[0.08] text-left text-xs text-white flex items-center gap-2.5"
                >
                  <Edit3 className="w-3.5 h-3.5 text-amber-300" />
                  <span>Set Nickname</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowMenu(false);
                    onToggleMute();
                  }}
                  className="w-full px-3 py-2.5 rounded-xl hover:bg-white/[0.08] text-left text-xs text-white flex items-center gap-2.5"
                >
                  {friend.muted ? (
                    <Bell className="w-3.5 h-3.5 text-amber-300" />
                  ) : (
                    <BellOff className="w-3.5 h-3.5 text-white/70" />
                  )}
                  <span>{friend.muted ? 'Unmute Notifications' : 'Mute Notifications'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowMenu(false);
                    onClearChatBothSides();
                  }}
                  className="w-full px-3 py-2.5 rounded-xl hover:bg-rose-500/20 text-left text-xs text-rose-300 flex items-center gap-2.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Clear Chat Both Sides</span>
                </button>
              </div>
            )}
          </div>
        </header>

        {/* Nickname Inline Modal */}
        {showNicknamePrompt && (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              onSetNickname(nicknameDraft.trim());
              setShowNicknamePrompt(false);
            }}
            className="px-4 py-2.5 bg-black/40 border-b border-white/[0.08] flex items-center gap-2"
          >
            <input
              type="text"
              value={nicknameDraft}
              onChange={(e) => setNicknameDraft(e.target.value)}
              placeholder={`Nickname for ${friend.displayName}`}
              autoFocus
              className="flex-1 h-9 px-3 rounded-xl bg-white/[0.07] border border-white/[0.12] text-xs text-white focus:outline-none"
            />
            <button
              type="submit"
              className="h-9 px-3 rounded-xl bg-amber-400 text-stone-950 text-xs font-semibold"
            >
              Save
            </button>
            <button
              type="button"
              onClick={() => setShowNicknamePrompt(false)}
              className="h-9 px-2.5 rounded-xl bg-white/[0.06] text-xs text-white/70"
            >
              Cancel
            </button>
          </form>
        )}

        {/* Message Canvas */}
        <div
          onClick={() => {
            setSelectedMsgId(null);
            setShowMenu(false);
            setShowMediaChoice(false);
          }}
          className="flex-1 min-h-0 overflow-y-auto vault-scroll px-3 sm:px-5 py-4 flex flex-col gap-2.5"
        >
          {messages.length === 0 ? (
            <div className="my-auto mx-auto glass-subtle rounded-2xl px-5 py-4 text-center max-w-xs">
              <p className="text-xs text-white/60 leading-relaxed">
                Zero-server P2P encrypted space with {displayTitle}. Tap ✨ for
                synchronized fullscreen FX or 🎮 to play live games.
              </p>
            </div>
          ) : (
            messages.map((msg) => {
              const isMine = msg.senderCode === myCode;
              const isSelected = selectedMsgId === msg.id;

              return (
                <div
                  key={msg.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    if (!msg.unsent) {
                      setSelectedMsgId((prev) => (prev === msg.id ? null : msg.id));
                    }
                  }}
                  className={`flex flex-col ${
                    isMine ? 'items-end' : 'items-start'
                  }`}
                >
                  {/* Tap-to-React & Action Bar */}
                  {isSelected && !msg.unsent && (
                    <div className="mb-1.5 glass-surface-elevated rounded-2xl px-2.5 py-1.5 flex items-center gap-1.5 spring-enter">
                      {CURATED_REACTIONS.map((em) => (
                        <button
                          key={em}
                          type="button"
                          onClick={() => {
                            onReactMessage(msg.id, em);
                            setSelectedMsgId(null);
                          }}
                          className="w-7 h-7 rounded-full hover:bg-white/10 flex items-center justify-center text-sm"
                        >
                          {em}
                        </button>
                      ))}
                      <span className="w-px h-4 bg-white/15 mx-0.5" />
                      <button
                        type="button"
                        aria-label="Reply to message"
                        onClick={() => {
                          setReplyTo({
                            id: msg.id,
                            senderCode: msg.senderCode,
                            preview:
                              msg.text ||
                              (msg.kind === 'view-once'
                                ? '2s View-Once Photo'
                                : msg.kind === 'photo'
                                  ? 'Photo'
                                  : 'Voice Note'),
                          });
                          setSelectedMsgId(null);
                        }}
                        className="p-1.5 rounded-lg hover:bg-white/10 text-white/80"
                      >
                        <Reply className="w-3.5 h-3.5" />
                      </button>
                      {isMine && msg.kind === 'text' && (
                        <button
                          type="button"
                          aria-label="Edit message"
                          onClick={() => {
                            setEditingMsgId(msg.id);
                            setDraft(msg.text || '');
                            setSelectedMsgId(null);
                          }}
                          className="p-1.5 rounded-lg hover:bg-white/10 text-white/80"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                      )}
                      {isMine && (
                        <button
                          type="button"
                          aria-label="Unsend message"
                          onClick={() => {
                            onUnsendMessage(msg.id);
                            setSelectedMsgId(null);
                          }}
                          className="p-1.5 rounded-lg hover:bg-rose-500/20 text-rose-300"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  )}

                  {/* Message Bubble */}
                  <div
                    className={`max-w-[82%] sm:max-w-[70%] rounded-[22px] px-3.5 py-2.5 transition-all ${
                      isMine
                        ? 'bg-gradient-to-br from-amber-400/20 to-rose-500/15 border border-amber-300/30 text-white'
                        : 'glass-subtle text-white'
                    }`}
                  >
                    {/* Quoted Reply */}
                    {msg.replyTo && !msg.unsent && (
                      <div className="mb-1.5 px-2.5 py-1 rounded-xl bg-black/25 text-[11px] text-white/70 truncate">
                        {msg.replyTo.preview}
                      </div>
                    )}

                    {/* Content by Kind */}
                    {msg.unsent ? (
                      <span className="text-xs italic text-white/45">
                        Message unsent
                      </span>
                    ) : msg.kind === 'view-once' ? (
                      msg.viewOnceConsumed ? (
                        <div className="flex items-center gap-2 py-0.5 text-xs text-white/60">
                          <span>💥 Viewed</span>
                        </div>
                      ) : isMine ? (
                        <div className="flex items-center gap-2 py-0.5 text-xs text-amber-200">
                          <Eye className="w-4 h-4" />
                          <span>📸 2s View-Once Sent</span>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onOpenViewOnce(msg);
                          }}
                          className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-amber-400/15 border border-amber-300/45 text-amber-200 text-xs font-semibold hover:bg-amber-400/25 transition-colors"
                        >
                          <span>📸 Hold to View · 2s</span>
                        </button>
                      )
                    ) : msg.kind === 'photo' && msg.mediaDataUrl ? (
                      <img
                        src={msg.mediaDataUrl}
                        alt="Shared media"
                        referrerPolicy="no-referrer"
                        className="rounded-xl max-h-64 object-cover"
                      />
                    ) : msg.kind === 'voice' && msg.mediaDataUrl ? (
                      <VoiceNoteBubble
                        src={msg.mediaDataUrl}
                        durationSec={msg.voiceDurationSec || 1}
                      />
                    ) : (
                      <p className={`${textSizeClass} leading-relaxed whitespace-pre-wrap break-words`}>
                        {msg.text}
                      </p>
                    )}

                    {/* Metadata Footer: Time, Edited, Golden ✓✓ Receipt */}
                    <div className="mt-1 flex items-center justify-end gap-1.5 text-[10px] text-white/45 tabular-nums">
                      {msg.edited && !msg.unsent && <span>edited</span>}
                      <span>
                        {new Date(msg.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                      {isMine && !msg.unsent && (
                        msg.seen ? (
                          <CheckCheck className="w-3.5 h-3.5 text-amber-300" />
                        ) : (
                          <Check className="w-3.5 h-3.5 text-white/45" />
                        )
                      )}
                    </div>
                  </div>

                  {/* Reactions */}
                  {msg.reactions.length > 0 && !msg.unsent && (
                    <div className="mt-0.5 px-2 flex items-center gap-1 text-xs">
                      {msg.reactions.map((r, idx) => (
                        <span key={`${r.byCode}-${idx}`}>{r.emoji}</span>
                      ))}
                    </div>
                  )}
                </div>
              );
            })
          )}
          <div ref={scrollEndRef} />
        </div>

        {/* Reply / Edit Banner */}
        {(replyTo || editingMsgId) && (
          <div className="px-4 py-2 bg-black/40 border-t border-white/[0.08] flex items-center justify-between gap-2 text-xs text-white/75">
            <span className="truncate">
              {editingMsgId
                ? 'Editing message'
                : `Replying to: ${replyTo?.preview}`}
            </span>
            <button
              type="button"
              onClick={() => {
                setReplyTo(null);
                setEditingMsgId(null);
                setDraft('');
              }}
              aria-label="Cancel reply or edit"
              className="p-1 rounded-full hover:bg-white/10"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Media Picker Choice Popover (Normal vs 2s View-Once) */}
        {showMediaChoice && (
          <div className="px-4 py-2.5 bg-black/50 border-t border-white/[0.08] flex items-center gap-2">
            <button
              type="button"
              onClick={() => photoNormalInputRef.current?.click()}
              className="flex-1 h-10 rounded-xl bg-white/[0.08] hover:bg-white/[0.14] text-xs font-medium text-white flex items-center justify-center gap-2"
            >
              <Camera className="w-4 h-4 text-white/80" />
              <span>Normal Photo</span>
            </button>
            <button
              type="button"
              onClick={() => photoViewOnceInputRef.current?.click()}
              className="flex-1 h-10 rounded-xl bg-amber-400/20 hover:bg-amber-400/30 border border-amber-300/40 text-xs font-semibold text-amber-200 flex items-center justify-center gap-2"
            >
              <Eye className="w-4 h-4" />
              <span>2s View-Once</span>
            </button>
          </div>
        )}

        <input
          ref={photoNormalInputRef}
          type="file"
          accept="image/*"
          onChange={(e) => handlePhotoFile(e, false)}
          className="hidden"
        />
        <input
          ref={photoViewOnceInputRef}
          type="file"
          accept="image/*"
          onChange={(e) => handlePhotoFile(e, true)}
          className="hidden"
        />

        {/* Clean Bottom Composer */}
        <form
          onSubmit={handleSubmit}
          className="glass-surface sm:bg-black/25 sm:backdrop-blur-none sm:border-0 sm:border-t sm:border-white/[0.08] px-2.5 sm:px-4 py-2.5 pb-[max(12px,env(safe-area-inset-bottom,12px))] flex items-center gap-1.5 shrink-0"
        >
          <button
            type="button"
            onClick={() => setShowMediaChoice((v) => !v)}
            aria-label="Send Photo or View-Once Photo"
            className="w-10 h-10 rounded-full hover:bg-white/[0.08] flex items-center justify-center text-white/80 shrink-0"
          >
            <Camera className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={onOpenFxDrawer}
            aria-label="Open Animated FX Emoji Drawer"
            className="w-10 h-10 rounded-full hover:bg-white/[0.08] flex items-center justify-center text-amber-300 shrink-0"
          >
            <Sparkles className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={onOpenGames}
            aria-label="Open Games and Shared Space"
            className="w-10 h-10 rounded-full hover:bg-white/[0.08] flex items-center justify-center text-white/80 shrink-0"
          >
            <Gamepad2 className="w-5 h-5" />
          </button>

          {recording ? (
            <div className="flex-1 h-10 px-3.5 rounded-full bg-rose-500/20 border border-rose-400/40 flex items-center justify-between text-xs text-rose-200 tabular-nums">
              <span>Recording · {recSeconds}s</span>
              <button
                type="button"
                onClick={stopVoiceRecording}
                aria-label="Stop and send voice note"
                className="px-2.5 py-1 rounded-full bg-rose-500 text-white font-semibold flex items-center gap-1"
              >
                <Square className="w-3 h-3" />
                <span>Send</span>
              </button>
            </div>
          ) : (
            <input
              type="text"
              value={draft}
              onChange={(e) => handleInputChange(e.target.value)}
              placeholder="Whisper privately..."
              aria-label="Message input"
              className="flex-1 min-w-0 h-10 px-4 rounded-full bg-white/[0.07] border border-white/[0.11] text-sm text-white placeholder:text-white/40 focus:outline-none focus:border-amber-300/50"
            />
          )}

          {!recording && (
            <button
              type="button"
              onClick={startVoiceRecording}
              aria-label="Record voice note"
              className="w-10 h-10 rounded-full hover:bg-white/[0.08] flex items-center justify-center text-white/80 shrink-0"
            >
              <Mic className="w-5 h-5" />
            </button>
          )}

          <button
            type="submit"
            aria-label="Send message"
            className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-stone-950 flex items-center justify-center shrink-0 transition-all"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </main>
  );
};

const VoiceNoteBubble: React.FC<{ src: string; durationSec: number }> = ({
  src,
  durationSec,
}) => {
  const [playing, setPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const toggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    const el = audioRef.current;
    if (!el) return;
    if (el.paused) {
      void el.play().catch(() => {});
      setPlaying(true);
    } else {
      el.pause();
      setPlaying(false);
    }
  };

  return (
    <div className="flex items-center gap-2.5 min-w-[155px]">
      <audio
        ref={audioRef}
        src={src}
        onEnded={() => setPlaying(false)}
        className="hidden"
      />
      <button
        type="button"
        onClick={toggle}
        aria-label={playing ? 'Pause voice note' : 'Play voice note'}
        className="w-8 h-8 rounded-full bg-amber-400 text-stone-950 flex items-center justify-center shrink-0"
      >
        {playing ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
      </button>
      <div className="flex-1 flex items-center gap-0.5 h-5" aria-hidden="true">
        {[40, 75, 55, 95, 65, 85, 50, 70, 90, 45].map((h, idx) => (
          <span
            key={idx}
            className="w-1 rounded-full bg-amber-200/75"
            style={{ height: `${h}%` }}
          />
        ))}
      </div>
      <span className="text-[11px] text-white/75 tabular-nums">
        {durationSec}s
      </span>
    </div>
  );
};

/* ============================================================================
 * VAULT HOME — MINIMALIST CONTACTS & REQUESTS HUB
 * - Displays personal 4-digit P2P code, Chats & Requests tabs
 * - Golden Aura Online Indicator around online friends
 * - Single-click access to Add Friend (+), Settings (⚙️), and Lock (🔒)
 * ============================================================================ */

import React, { useState } from 'react';
import {
  Check,
  Copy,
  Lock,
  MessageCircle,
  Plus,
  Settings,
  UserCheck,
  X,
} from 'lucide-react';
import type {
  ChatMessage,
  FriendContact,
  FriendRequest,
  PeerConnectionStatus,
  VaultUser,
} from '../types/vault';

interface VaultHomeProps {
  user: VaultUser;
  peerStatus: PeerConnectionStatus;
  friends: FriendContact[];
  requests: FriendRequest[];
  onlineCodes: Set<string>;
  messages: ChatMessage[];
  onOpenChat: (friendCode: string) => void;
  onOpenAddFriend: () => void;
  onOpenSettings: () => void;
  onLockVault: () => void;
  onAcceptRequest: (request: FriendRequest) => void;
  onDeclineRequest: (requestId: string) => void;
}

export const VaultHome: React.FC<VaultHomeProps> = ({
  user,
  peerStatus,
  friends,
  requests,
  onlineCodes,
  messages,
  onOpenChat,
  onOpenAddFriend,
  onOpenSettings,
  onLockVault,
  onAcceptRequest,
  onDeclineRequest,
}) => {
  const [activeTab, setActiveTab] = useState<'chats' | 'requests'>('chats');
  const [copied, setCopied] = useState(false);

  const incomingRequests = requests.filter((r) => r.direction === 'incoming');
  const outgoingRequests = requests.filter((r) => r.direction === 'outgoing');

  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText(user.code);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      // ignore clipboard restriction
    }
  };

  const getLastMessageForFriend = (friendCode: string): ChatMessage | undefined => {
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].peerCode === friendCode) return messages[i];
    }
    return undefined;
  };

  const getUnreadCount = (friendCode: string): number => {
    return messages.filter(
      (m) => m.peerCode === friendCode && m.senderCode === friendCode && !m.seen
    ).length;
  };

  return (
    <main className="relative z-10 w-full h-full flex flex-col items-center px-3 sm:px-6 py-4 sm:py-6 overflow-hidden">
      <div className="w-full max-w-[720px] h-full flex flex-col gap-4">
        {/* Whisper-Clean Frosted Header */}
        <header className="glass-surface glass-specular-rim rounded-[26px] px-4 py-3.5 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="relative shrink-0">
              <img
                src={user.avatarDataUrl}
                alt={user.displayName}
                referrerPolicy="no-referrer"
                className="w-11 h-11 rounded-full object-cover border border-amber-300/45"
              />
              {peerStatus === 'ready' && (
                <span
                  title="P2P Ready"
                  className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-amber-400 border-2 border-[#120b14] shadow-[0_0_8px_#fbbf24]"
                />
              )}
            </div>

            <div className="min-w-0">
              <h1 className="text-sm sm:text-base font-semibold text-white truncate">
                {user.displayName}
              </h1>
              <button
                type="button"
                onClick={copyCode}
                aria-label={`Copy your 4-digit code ${user.code}`}
                className="flex items-center gap-1.5 text-xs text-amber-300/90 hover:text-amber-200 tabular-nums transition-colors"
              >
                <span>My Code · {user.code}</span>
                {copied ? (
                  <Check className="w-3.5 h-3.5 text-amber-300" />
                ) : (
                  <Copy className="w-3 h-3 opacity-75" />
                )}
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onOpenAddFriend}
              aria-label="Add Friend"
              className="w-11 h-11 rounded-2xl bg-amber-400/20 hover:bg-amber-400/30 border border-amber-300/40 flex items-center justify-center text-amber-200 transition-colors"
            >
              <Plus className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={onOpenSettings}
              aria-label="Settings"
              className="w-11 h-11 rounded-2xl glass-subtle hover:bg-white/[0.12] flex items-center justify-center text-white/85 transition-colors"
            >
              <Settings className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={onLockVault}
              aria-label="Lock Vault"
              className="w-11 h-11 rounded-2xl glass-subtle hover:bg-white/[0.12] flex items-center justify-center text-white/85 transition-colors"
            >
              <Lock className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Segmented Chats / Requests Tabs */}
        <nav
          aria-label="Vault sections"
          className="glass-surface rounded-2xl p-1.5 grid grid-cols-2 gap-1.5 shrink-0"
        >
          <button
            type="button"
            onClick={() => setActiveTab('chats')}
            className={`h-10 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-2 ${
              activeTab === 'chats'
                ? 'bg-white/[0.14] text-white shadow-sm'
                : 'text-white/60 hover:text-white'
            }`}
          >
            <MessageCircle className="w-4 h-4" />
            <span>Chats ({friends.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('requests')}
            className={`h-10 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-2 ${
              activeTab === 'requests'
                ? 'bg-white/[0.14] text-white shadow-sm'
                : 'text-white/60 hover:text-white'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>Requests</span>
            {incomingRequests.length > 0 && (
              <span className="min-w-[20px] h-5 px-1.5 rounded-full bg-amber-400 text-stone-950 text-[11px] font-bold flex items-center justify-center tabular-nums">
                {incomingRequests.length}
              </span>
            )}
          </button>
        </nav>

        {/* Content List */}
        <section className="flex-1 min-h-0 overflow-y-auto vault-scroll flex flex-col gap-2.5 pb-4">
          {activeTab === 'chats' ? (
            friends.length === 0 ? (
              <div className="glass-surface rounded-[26px] p-8 my-auto flex flex-col items-center text-center gap-3">
                <div className="w-14 h-14 rounded-full bg-amber-400/15 border border-amber-300/30 flex items-center justify-center text-amber-200">
                  <Plus className="w-6 h-6" />
                </div>
                <h2 className="text-base font-semibold text-white">
                  No Connections Yet
                </h2>
                <p className="text-xs text-white/60 max-w-xs leading-relaxed">
                  Share your 4-digit code ({user.code}) or tap Add Friend to
                  connect directly over encrypted P2P WebRTC.
                </p>
                <button
                  type="button"
                  onClick={onOpenAddFriend}
                  className="mt-1 px-5 py-2.5 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 text-stone-950 text-xs font-semibold hover:from-amber-300 hover:to-amber-400 transition-all"
                >
                  Add by 4-Digit Code
                </button>
              </div>
            ) : (
              friends.map((friend) => {
                const isOnline = onlineCodes.has(friend.code);
                const lastMsg = getLastMessageForFriend(friend.code);
                const unread = getUnreadCount(friend.code);
                const label = friend.nickname || friend.displayName;

                let previewText = `Code · ${friend.code}`;
                if (lastMsg) {
                  if (lastMsg.unsent) previewText = 'Message unsent';
                  else if (lastMsg.kind === 'view-once')
                    previewText = lastMsg.viewOnceConsumed
                      ? '💥 Viewed'
                      : '📸 Hold to View • 2s';
                  else if (lastMsg.kind === 'photo') previewText = '📷 Photo';
                  else if (lastMsg.kind === 'voice') previewText = '🎙️ Voice note';
                  else previewText = lastMsg.text || '';
                }

                return (
                  <button
                    key={friend.code}
                    type="button"
                    onClick={() => onOpenChat(friend.code)}
                    className={`glass-surface w-full rounded-[24px] p-3.5 sm:p-4 flex items-center gap-3.5 text-left transition-all hover:bg-white/[0.08] ${
                      isOnline ? 'golden-aura-card' : ''
                    }`}
                  >
                    <div className="relative shrink-0">
                      <img
                        src={friend.avatarDataUrl}
                        alt={label}
                        referrerPolicy="no-referrer"
                        className={`w-13 h-13 rounded-full object-cover ${
                          isOnline
                            ? 'golden-aura-ring'
                            : 'border border-white/15'
                        }`}
                      />
                      <span
                        className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-[#120b14] ${
                          isOnline
                            ? 'bg-amber-400 shadow-[0_0_10px_#fbbf24]'
                            : 'bg-white/30'
                        }`}
                      />
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm font-semibold text-white truncate">
                          {label}
                        </span>
                        <span className="text-[11px] text-white/45 tabular-nums shrink-0">
                          {isOnline ? 'Online' : 'Offline'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between gap-2 mt-0.5">
                        <span className="text-xs text-white/60 truncate">
                          {previewText}
                        </span>
                        {unread > 0 && (
                          <span className="min-w-[20px] h-5 px-1.5 rounded-full bg-amber-400 text-stone-950 text-[11px] font-bold flex items-center justify-center tabular-nums shrink-0">
                            {unread}
                          </span>
                        )}
                      </div>
                    </div>
                  </button>
                );
              })
            )
          ) : (
            <div className="flex flex-col gap-3">
              {incomingRequests.length === 0 && outgoingRequests.length === 0 ? (
                <div className="glass-surface rounded-[26px] p-8 text-center text-xs text-white/60">
                  No pending friend requests.
                </div>
              ) : (
                <>
                  {incomingRequests.map((req) => (
                    <div
                      key={req.id}
                      className="glass-surface golden-aura-card rounded-[24px] p-4 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <img
                          src={req.fromAvatar}
                          alt={req.fromName}
                          referrerPolicy="no-referrer"
                          className="w-12 h-12 rounded-full object-cover border border-amber-300/40 shrink-0"
                        />
                        <div className="min-w-0">
                          <div className="text-sm font-semibold text-white truncate">
                            {req.fromName}
                          </div>
                          <div className="text-xs text-amber-300/85 tabular-nums">
                            Code · {req.fromCode}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => onAcceptRequest(req)}
                          className="h-10 px-3.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-stone-950 text-xs font-semibold transition-colors"
                        >
                          Accept &amp; Save
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeclineRequest(req.id)}
                          aria-label={`Decline ${req.fromName}`}
                          className="w-10 h-10 rounded-xl bg-white/[0.08] hover:bg-rose-500/25 text-white/75 hover:text-rose-200 flex items-center justify-center transition-colors"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}

                  {outgoingRequests.map((req) => (
                    <div
                      key={req.id}
                      className="glass-surface rounded-[24px] p-4 flex items-center justify-between gap-3 opacity-80"
                    >
                      <div>
                        <div className="text-sm font-medium text-white">
                          Sent to Code {req.fromCode}
                        </div>
                        <div className="text-xs text-white/55">
                          Waiting for peer acceptance
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => onDeclineRequest(req.id)}
                        className="text-xs text-white/60 hover:text-white px-3 py-1.5 rounded-xl bg-white/[0.06]"
                      >
                        Cancel
                      </button>
                    </div>
                  ))}
                </>
              )}
            </div>
          )}
        </section>
      </div>
    </main>
  );
};

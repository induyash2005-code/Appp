/* ============================================================================
 * ENCRYPTED VOICE, VIDEO & 3-WAY MESH CALL OVERLAY
 * - Full-screen glass call overlay with live duration timer
 * - Draggable minimized Picture-in-Picture (PiP) mode to keep chatting
 * - Mic Mute, Camera Toggle, Front/Back Camera Flip, Add 3rd Friend (4-digit)
 * ============================================================================ */

import React, { useEffect, useRef, useState } from 'react';
import {
  Maximize2,
  Mic,
  MicOff,
  Minimize2,
  Phone,
  PhoneOff,
  RefreshCw,
  UserPlus,
  Video,
  VideoOff,
} from 'lucide-react';
import type { ActiveCallSession } from '../types/vault';

interface CallOverlayProps {
  call: ActiveCallSession;
  localStream: MediaStream | null;
  onAcceptIncoming: () => void;
  onDeclineOrEnd: () => void;
  onToggleMute: () => void;
  onToggleCamera: () => void;
  onFlipCamera: () => void;
  onToggleMinimize: () => void;
  onInviteThirdFriend: (fourDigitCode: string) => void;
}

function formatCallDuration(startedAt: number | null): string {
  if (!startedAt) return '00:00';
  const secs = Math.max(0, Math.floor((Date.now() - startedAt) / 1000));
  const m = Math.floor(secs / 60);
  const s = secs % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export const CallOverlay: React.FC<CallOverlayProps> = ({
  call,
  localStream,
  onAcceptIncoming,
  onDeclineOrEnd,
  onToggleMute,
  onToggleCamera,
  onFlipCamera,
  onToggleMinimize,
  onInviteThirdFriend,
}) => {
  const [durationStr, setDurationStr] = useState('00:00');
  const [showInviteBox, setShowInviteBox] = useState(false);
  const [thirdCode, setThirdCode] = useState('');
  const [pipPos, setPipPos] = useState({ x: 16, y: 76 });

  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const dragOffsetRef = useRef<{ dx: number; dy: number } | null>(null);

  useEffect(() => {
    const id = window.setInterval(() => {
      setDurationStr(formatCallDuration(call.startedAt));
    }, 1000);
    return () => window.clearInterval(id);
  }, [call.startedAt]);

  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream, call.minimized]);

  /* ---------------- INCOMING RINGING BANNER ---------------- */
  if (call.direction === 'incoming' && call.status === 'ringing') {
    const caller = call.participants[0];
    return (
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Incoming Call"
        className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-[92%] max-w-[420px]"
      >
        <div className="glass-surface-elevated golden-aura-card rounded-[26px] p-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <img
              src={caller?.avatarDataUrl || ''}
              alt={caller?.displayName || 'Caller'}
              referrerPolicy="no-referrer"
              className="w-12 h-12 rounded-full object-cover golden-aura-ring shrink-0"
            />
            <div className="min-w-0">
              <div className="text-sm font-semibold text-white truncate">
                {caller?.displayName || `Peer ${caller?.code}`}
              </div>
              <div className="text-xs text-amber-300">
                Incoming {call.mode === 'video' ? 'Video' : 'Voice'} Call...
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onDeclineOrEnd}
              aria-label="Decline call"
              className="w-11 h-11 rounded-full bg-rose-500 hover:bg-rose-400 text-white flex items-center justify-center transition-colors"
            >
              <PhoneOff className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={onAcceptIncoming}
              aria-label="Accept call"
              className="w-11 h-11 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white flex items-center justify-center transition-colors"
            >
              <Phone className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  /* ---------------- DRAGGABLE MINIMIZED PIP MODE ---------------- */
  if (call.minimized) {
    const primary = call.participants[0];
    return (
      <div
        onPointerDown={(e) => {
          dragOffsetRef.current = {
            dx: e.clientX - pipPos.x,
            dy: e.clientY - pipPos.y,
          };
          e.currentTarget.setPointerCapture(e.pointerId);
        }}
        onPointerMove={(e) => {
          if (!dragOffsetRef.current) return;
          setPipPos({
            x: Math.max(8, Math.min(window.innerWidth - 176, e.clientX - dragOffsetRef.current.dx)),
            y: Math.max(8, Math.min(window.innerHeight - 130, e.clientY - dragOffsetRef.current.dy)),
          });
        }}
        onPointerUp={() => {
          dragOffsetRef.current = null;
        }}
        style={{ left: pipPos.x, top: pipPos.y, touchAction: 'none' }}
        className="fixed z-50 w-[168px] glass-surface-elevated golden-aura-card rounded-2xl p-2.5 flex flex-col gap-2 cursor-grab active:cursor-grabbing"
      >
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <img
              src={primary?.avatarDataUrl || ''}
              alt={primary?.displayName || 'Call'}
              referrerPolicy="no-referrer"
              className="w-7 h-7 rounded-full object-cover"
            />
            <div className="min-w-0">
              <div className="text-[11px] font-semibold text-white truncate">
                {primary?.displayName}
              </div>
              <div className="text-[10px] text-amber-300 tabular-nums">
                {call.status === 'connected' ? durationStr : 'Ringing...'}
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={onToggleMinimize}
            aria-label="Expand call"
            className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center text-white"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="flex items-center justify-between gap-1.5">
          <button
            type="button"
            onClick={onToggleMute}
            aria-label={call.muted ? 'Unmute mic' : 'Mute mic'}
            className={`flex-1 h-8 rounded-xl flex items-center justify-center ${
              call.muted ? 'bg-rose-500/30 text-rose-200' : 'bg-white/10 text-white'
            }`}
          >
            {call.muted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
          </button>
          <button
            type="button"
            onClick={onDeclineOrEnd}
            aria-label="End call"
            className="flex-1 h-8 rounded-xl bg-rose-500 text-white flex items-center justify-center"
          >
            <PhoneOff className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    );
  }

  /* ---------------- FULLSCREEN GLASS CALL OVERLAY ---------------- */
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Active Call"
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xl flex flex-col justify-between p-5 sm:p-7"
    >
      {/* Top Bar */}
      <div className="flex items-center justify-between">
        <div>
          <div className="text-sm font-semibold text-white">
            {call.participants.map((p) => p.displayName).join(' · ')}
          </div>
          <div className="text-xs text-amber-300 tabular-nums">
            {call.status === 'connected' ? durationStr : 'Connecting P2P...'}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowInviteBox((v) => !v)}
            aria-label="Add 3rd Friend to call"
            className="h-10 px-3.5 rounded-2xl glass-subtle text-xs text-white flex items-center gap-1.5 hover:bg-white/15"
          >
            <UserPlus className="w-4 h-4 text-amber-300" />
            <span>Add 3rd</span>
          </button>
          <button
            type="button"
            onClick={onToggleMinimize}
            aria-label="Minimize to Picture in Picture"
            className="w-10 h-10 rounded-2xl glass-subtle text-white flex items-center justify-center hover:bg-white/15"
          >
            <Minimize2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Add 3rd Friend Inline Input */}
      {showInviteBox && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const cleaned = thirdCode.replace(/\D/g, '').slice(0, 4);
            if (cleaned.length === 4) {
              onInviteThirdFriend(cleaned);
              setThirdCode('');
              setShowInviteBox(false);
            }
          }}
          className="mx-auto w-full max-w-xs glass-surface rounded-2xl p-2 flex items-center gap-2"
        >
          <input
            type="text"
            inputMode="numeric"
            maxLength={4}
            value={thirdCode}
            onChange={(e) =>
              setThirdCode(e.target.value.replace(/\D/g, '').slice(0, 4))
            }
            placeholder="3rd friend 4-digit code"
            className="flex-1 h-9 px-3 rounded-xl bg-white/[0.06] text-xs text-white tabular-nums placeholder:text-white/40 focus:outline-none"
          />
          <button
            type="submit"
            className="h-9 px-3 rounded-xl bg-amber-400 text-stone-950 text-xs font-semibold"
          >
            Invite
          </button>
        </form>
      )}

      {/* Participant Video / Avatar Grid */}
      <div className="flex-1 my-4 flex items-center justify-center gap-4 flex-wrap">
        {call.participants.map((p) => (
          <ParticipantTile key={p.code} participant={p} isVideo={call.mode === 'video'} />
        ))}

        {/* Local Self-Preview */}
        {localStream && call.mode === 'video' && !call.cameraOff && (
          <div className="relative w-32 h-44 rounded-2xl overflow-hidden border border-white/20 shadow-xl">
            <video
              ref={localVideoRef}
              autoPlay
              muted
              playsInline
              className="w-full h-full object-cover scale-x-[-1]"
            />
          </div>
        )}
      </div>

      {call.permissionWarning && (
        <p className="text-center text-xs text-amber-200/85 mb-2">
          {call.permissionWarning}
        </p>
      )}

      {/* Bottom Controls */}
      <div className="mx-auto glass-surface rounded-[28px] px-5 py-3 flex items-center gap-3.5">
        <button
          type="button"
          onClick={onToggleMute}
          aria-label={call.muted ? 'Unmute microphone' : 'Mute microphone'}
          className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
            call.muted
              ? 'bg-rose-500/30 text-rose-200 border border-rose-400/50'
              : 'bg-white/10 hover:bg-white/20 text-white'
          }`}
        >
          {call.muted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>

        {call.mode === 'video' && (
          <>
            <button
              type="button"
              onClick={onToggleCamera}
              aria-label={call.cameraOff ? 'Turn camera on' : 'Turn camera off'}
              className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
                call.cameraOff
                  ? 'bg-rose-500/30 text-rose-200 border border-rose-400/50'
                  : 'bg-white/10 hover:bg-white/20 text-white'
              }`}
            >
              {call.cameraOff ? (
                <VideoOff className="w-5 h-5" />
              ) : (
                <Video className="w-5 h-5" />
              )}
            </button>
            <button
              type="button"
              onClick={onFlipCamera}
              aria-label="Flip front and back camera"
              className="w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
            >
              <RefreshCw className="w-5 h-5" />
            </button>
          </>
        )}

        <button
          type="button"
          onClick={onDeclineOrEnd}
          aria-label="End Call"
          className="w-14 h-12 rounded-full bg-rose-500 hover:bg-rose-400 text-white flex items-center justify-center transition-colors"
        >
          <PhoneOff className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

const ParticipantTile: React.FC<{
  participant: ActiveCallSession['participants'][number];
  isVideo: boolean;
}> = ({ participant, isVideo }) => {
  const mediaRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    if (mediaRef.current && participant.stream) {
      mediaRef.current.srcObject = participant.stream;
    }
  }, [participant.stream]);

  return (
    <div className="relative glass-surface golden-aura-card rounded-[28px] w-full max-w-[320px] min-h-[220px] overflow-hidden flex flex-col items-center justify-center p-6 gap-3">
      {participant.stream && isVideo ? (
        <video
          ref={mediaRef}
          autoPlay
          playsInline
          className="absolute inset-0 w-full h-full object-cover"
        />
      ) : (
        <>
          {participant.stream && (
            <video ref={mediaRef} autoPlay playsInline className="hidden" />
          )}
          <img
            src={participant.avatarDataUrl}
            alt={participant.displayName}
            referrerPolicy="no-referrer"
            className="w-24 h-24 rounded-full object-cover golden-aura-ring"
          />
          <div className="text-sm font-semibold text-white">
            {participant.displayName}
          </div>
          <div className="text-xs text-white/55 tabular-nums">
            Code · {participant.code}
          </div>
        </>
      )}
    </div>
  );
};

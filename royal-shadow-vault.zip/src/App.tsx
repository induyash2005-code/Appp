/* ============================================================================
 * ROYAL SHADOW VAULT — ROOT ORCHESTRATOR
 * Connects Stealth Calculator Lock, Zero-Server Personal Accounts, PeerJS P2P,
 * Fullscreen Canvas 2D FX Engine, Curated Games, View-Once Media & Calls.
 * ============================================================================ */

import React, { useCallback, useEffect, useRef, useState } from 'react';
import type { MediaConnection } from 'peerjs';
import type {
  ActiveCallSession,
  ChatMessage,
  FriendContact,
  FriendRequest,
  FxType,
  MessageReplyRef,
  P2PPacket,
  PeerConnectionStatus,
  VaultScreen,
  VaultSettings,
  VaultUser,
} from './types/vault';
import {
  loadFriendRequests,
  loadFriends,
  loadMessages,
  loadVaultSettings,
  loadVaultUser,
  saveFriendRequests,
  saveFriends,
  saveMessages,
  saveVaultSettings,
  saveVaultUser,
} from './engine/storage';
import { audioEngine } from './engine/audioEngine';
import { detectFxTrigger } from './engine/fxTriggers';
import { FullscreenFxRenderer } from './engine/fxCanvas';
import { VaultP2PManager } from './engine/p2pManager';
import { ThemeBackdrop } from './components/ThemeBackdrop';
import { CalculatorLock } from './components/CalculatorLock';
import { AccountGate } from './components/AccountGate';
import { VaultHome } from './components/VaultHome';
import { ChatView } from './components/ChatView';
import { AddFriendModal } from './components/AddFriendModal';
import { SettingsModal } from './components/SettingsModal';
import { FxDrawer } from './components/FxDrawer';
import { GamesSpaceModal } from './components/GamesSpaceModal';
import { ViewOnceViewer } from './components/ViewOnceViewer';
import { CallOverlay } from './components/CallOverlay';

export default function App() {
  const [screen, setScreen] = useState<VaultScreen>('calculator');
  const [user, setUser] = useState<VaultUser | null>(() => loadVaultUser());
  const [sessionAuthed, setSessionAuthed] = useState(false);
  const [settings, setSettings] = useState<VaultSettings>(() =>
    loadVaultSettings()
  );
  const [friends, setFriends] = useState<FriendContact[]>(() => loadFriends());
  const [requests, setRequests] = useState<FriendRequest[]>(() =>
    loadFriendRequests()
  );
  const [messages, setMessages] = useState<ChatMessage[]>(() => loadMessages());

  const [peerStatus, setPeerStatus] = useState<PeerConnectionStatus>('offline');
  const [onlineCodes, setOnlineCodes] = useState<Set<string>>(new Set());
  const [activeFriendCode, setActiveFriendCode] = useState<string | null>(null);
  const [typingPeers, setTypingPeers] = useState<Set<string>>(new Set());

  // Modals & Overlays
  const [showAddFriend, setShowAddFriend] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showFxDrawer, setShowFxDrawer] = useState(false);
  const [showGames, setShowGames] = useState(false);
  const [viewOnceTarget, setViewOnceTarget] = useState<ChatMessage | null>(null);

  // Latest P2P game/activity packet forwarded to GamesSpaceModal
  const [incomingGamePacket, setIncomingGamePacket] = useState<{
    seq: number;
    packet: P2PPacket;
  } | null>(null);

  // Fullscreen FX Canvas & Horror Tremor State
  const fxCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const fxRendererRef = useRef<FullscreenFxRenderer | null>(null);
  const [activeFx, setActiveFx] = useState<FxType | null>(null);

  // WebRTC Call State
  const [activeCall, setActiveCall] = useState<ActiveCallSession | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const [localStreamState, setLocalStreamState] = useState<MediaStream | null>(
    null
  );
  const activeMediaCallsRef = useRef<Map<string, MediaConnection>>(new Map());
  const pendingIncomingMediaRef = useRef<{
    call: MediaConnection;
    fromCode: string;
  } | null>(null);

  // Refs for fresh state inside P2P callbacks
  const p2pRef = useRef<VaultP2PManager | null>(null);
  const activeFriendRef = useRef<string | null>(null);
  const friendsRef = useRef<FriendContact[]>(friends);
  const userRef = useRef<VaultUser | null>(user);
  const settingsRef = useRef<VaultSettings>(settings);

  activeFriendRef.current = activeFriendCode;
  friendsRef.current = friends;
  userRef.current = user;
  settingsRef.current = settings;

  // Sync audio & vibration settings
  useEffect(() => {
    audioEngine.configure(settings.soundEnabled, settings.vibrationEnabled);
  }, [settings.soundEnabled, settings.vibrationEnabled]);

  // Persist state slices cleanly
  useEffect(() => {
    saveVaultSettings(settings);
  }, [settings]);

  useEffect(() => {
    saveFriends(friends);
  }, [friends]);

  useEffect(() => {
    saveFriendRequests(requests);
  }, [requests]);

  useEffect(() => {
    saveMessages(messages);
  }, [messages]);

  // Mount Fullscreen FX Canvas Renderer once
  useEffect(() => {
    if (!fxCanvasRef.current) return;
    const renderer = new FullscreenFxRenderer(fxCanvasRef.current);
    fxRendererRef.current = renderer;
    const onResize = () => renderer.resize();
    window.addEventListener('resize', onResize);
    return () => {
      window.removeEventListener('resize', onResize);
      renderer.stop();
    };
  }, []);

  const triggerFullscreenFx = useCallback((fx: FxType) => {
    setActiveFx(fx);
    audioEngine.playFxSound(fx);
    fxRendererRef.current?.start(fx, () => {
      setActiveFx(null);
    });
  }, []);

  // Auto-Vanish Message Pruner
  useEffect(() => {
    const id = window.setInterval(() => {
      const now = Date.now();
      setMessages((prev) => {
        const hasExpired = prev.some((m) => m.expiresAt && m.expiresAt <= now);
        if (!hasExpired) return prev;
        return prev.filter((m) => !m.expiresAt || m.expiresAt > now);
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, []);

  // Auto-Lock Inactivity Timer
  useEffect(() => {
    if (screen === 'calculator' || settings.autoLockMinutes === 0) return;
    const timeoutMs = settings.autoLockMinutes * 60 * 1000;
    let timer = window.setTimeout(() => {
      setScreen('calculator');
      setShowAddFriend(false);
      setShowSettings(false);
      setShowFxDrawer(false);
      setShowGames(false);
    }, timeoutMs);

    const resetTimer = () => {
      window.clearTimeout(timer);
      timer = window.setTimeout(() => {
        setScreen('calculator');
      }, timeoutMs);
    };

    window.addEventListener('pointerdown', resetTimer);
    window.addEventListener('keydown', resetTimer);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener('pointerdown', resetTimer);
      window.removeEventListener('keydown', resetTimer);
    };
  }, [screen, settings.autoLockMinutes]);

  // End & Cleanup Call Helper
  const cleanupCall = useCallback(() => {
    audioEngine.stopRingtone();
    activeMediaCallsRef.current.forEach((mc) => {
      try {
        mc.close();
      } catch {
        // ignore
      }
    });
    activeMediaCallsRef.current.clear();
    if (pendingIncomingMediaRef.current) {
      try {
        pendingIncomingMediaRef.current.call.close();
      } catch {
        // ignore
      }
      pendingIncomingMediaRef.current = null;
    }
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((t) => t.stop());
      localStreamRef.current = null;
      setLocalStreamState(null);
    }
    setActiveCall(null);
  }, []);

  // Acquire Media Stream with Graceful Fallback
  const acquireLocalMedia = useCallback(
    async (mode: 'voice' | 'video', facingMode: 'user' | 'environment') => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: true,
          video: mode === 'video' ? { facingMode } : false,
        });
        localStreamRef.current = stream;
        setLocalStreamState(stream);
        return { stream, warning: undefined as string | undefined };
      } catch {
        if (mode === 'video') {
          try {
            const audioOnly = await navigator.mediaDevices.getUserMedia({
              audio: true,
              video: false,
            });
            localStreamRef.current = audioOnly;
            setLocalStreamState(audioOnly);
            return {
              stream: audioOnly,
              warning: 'Camera unavailable — switched to audio.',
            };
          } catch {
            // Fall through to silent fallback stream
          }
        }
        return {
          stream: null,
          warning: 'Microphone/Camera permission denied — listen-only mode.',
        };
      }
    },
    []
  );

  // Attach incoming/outgoing MediaConnection stream
  const wireMediaConnection = useCallback(
    (mc: MediaConnection, remoteCode: string) => {
      activeMediaCallsRef.current.set(remoteCode, mc);

      mc.on('stream', (remoteStream) => {
        setActiveCall((prev) => {
          if (!prev) return prev;
          const exists = prev.participants.some((p) => p.code === remoteCode);
          const friendMatch = friendsRef.current.find(
            (f) => f.code === remoteCode
          );
          const nextParticipants = exists
            ? prev.participants.map((p) =>
                p.code === remoteCode ? { ...p, stream: remoteStream } : p
              )
            : [
                ...prev.participants,
                {
                  code: remoteCode,
                  displayName: friendMatch?.displayName || `Peer ${remoteCode}`,
                  avatarDataUrl: friendMatch?.avatarDataUrl || '',
                  stream: remoteStream,
                },
              ];

          return {
            ...prev,
            status: 'connected',
            startedAt: prev.startedAt ?? Date.now(),
            participants: nextParticipants,
          };
        });
      });

      mc.on('close', () => {
        activeMediaCallsRef.current.delete(remoteCode);
        if (activeMediaCallsRef.current.size === 0) {
          cleanupCall();
        }
      });
    },
    [cleanupCall]
  );

  // Initialize P2P Manager when user account exists and session unlocked
  useEffect(() => {
    if (!user || !sessionAuthed) {
      p2pRef.current?.stop();
      p2pRef.current = null;
      return;
    }

    const manager = new VaultP2PManager({
      onStatusChange: (status) => setPeerStatus(status),
      onCodeAssigned: (freshCode) => {
        setUser((prev) => {
          if (!prev) return prev;
          const updated = { ...prev, code: freshCode };
          saveVaultUser(updated);
          return updated;
        });
      },
      onOnlinePeersChange: (codes) => setOnlineCodes(codes),
      onIncomingMediaCall: (mediaCall, fromCode) => {
        pendingIncomingMediaRef.current = { call: mediaCall, fromCode };
        const friend = friendsRef.current.find((f) => f.code === fromCode);
        audioEngine.startRingtone();
        setActiveCall((prev) => {
          if (prev && prev.status === 'connected') {
            // Auto-attach 3rd friend mesh stream when already in call
            if (localStreamRef.current) {
              mediaCall.answer(localStreamRef.current);
              wireMediaConnection(mediaCall, fromCode);
            }
            return prev;
          }
          return {
            callId: `call_${Date.now()}`,
            mode: 'video',
            direction: 'incoming',
            status: 'ringing',
            participants: [
              {
                code: fromCode,
                displayName:
                  friend?.nickname ||
                  friend?.displayName ||
                  `Peer ${fromCode}`,
                avatarDataUrl: friend?.avatarDataUrl || '',
              },
            ],
            startedAt: null,
            muted: false,
            cameraOff: false,
            facingMode: 'user',
            minimized: false,
          };
        });
      },
      onPacket: (fromCode, pkt) => {
        switch (pkt.type) {
          case 'presence_hello': {
            setFriends((prev) =>
              prev.map((f) =>
                f.code === pkt.fromCode
                  ? {
                      ...f,
                      displayName: pkt.displayName || f.displayName,
                      avatarDataUrl: pkt.avatarDataUrl || f.avatarDataUrl,
                      lastSeenAt: Date.now(),
                    }
                  : f
              )
            );
            break;
          }
          case 'friend_request': {
            // Ignore if already friends
            if (friendsRef.current.some((f) => f.code === pkt.fromCode)) {
              break;
            }
            audioEngine.playMessageReceive();
            setRequests((prev) => {
              if (
                prev.some(
                  (r) =>
                    r.fromCode === pkt.fromCode && r.direction === 'incoming'
                )
              ) {
                return prev;
              }
              return [
                {
                  id: pkt.requestId,
                  fromCode: pkt.fromCode,
                  fromName: pkt.fromName,
                  fromAvatar: pkt.fromAvatar,
                  timestamp: pkt.timestamp,
                  direction: 'incoming',
                },
                ...prev,
              ];
            });
            break;
          }
          case 'friend_accept': {
            audioEngine.playVaultUnlock();
            setRequests((prev) =>
              prev.filter((r) => r.fromCode !== pkt.fromCode)
            );
            setFriends((prev) => {
              if (prev.some((f) => f.code === pkt.fromCode)) return prev;
              return [
                ...prev,
                {
                  code: pkt.fromCode,
                  displayName: pkt.fromName,
                  avatarDataUrl: pkt.fromAvatar,
                  addedAt: Date.now(),
                },
              ];
            });
            break;
          }
          case 'friend_decline': {
            setRequests((prev) =>
              prev.filter((r) => r.id !== pkt.requestId)
            );
            break;
          }
          case 'chat_message': {
            const incoming = pkt.message;
            const currentUser = userRef.current;
            if (!currentUser) break;

            const isCurrentlyViewingThisChat =
              activeFriendRef.current === fromCode;

            const storedMsg: ChatMessage = {
              ...incoming,
              peerCode: fromCode,
              seen: isCurrentlyViewingThisChat,
              expiresAt:
                incoming.vanishAfterSec > 0
                  ? Date.now() + incoming.vanishAfterSec * 1000
                  : undefined,
            };

            setMessages((prev) => {
              if (prev.some((m) => m.id === storedMsg.id)) return prev;
              return [...prev, storedMsg];
            });

            const friendObj = friendsRef.current.find(
              (f) => f.code === fromCode
            );
            if (!friendObj?.muted) {
              audioEngine.playMessageReceive();
            }

            // Send seen receipt immediately if chat is open
            if (isCurrentlyViewingThisChat) {
              p2pRef.current?.sendToCode(fromCode, {
                type: 'chat_seen',
                fromCode: currentUser.code,
                messageIds: [storedMsg.id],
              });
            }

            // Smart text FX trigger on incoming text
            if (storedMsg.kind === 'text' && storedMsg.text) {
              const triggered = detectFxTrigger(storedMsg.text);
              if (triggered) {
                triggerFullscreenFx(triggered);
              }
            }
            break;
          }
          case 'chat_typing': {
            setTypingPeers((prev) => {
              const next = new Set(prev);
              if (pkt.isTyping) next.add(pkt.fromCode);
              else next.delete(pkt.fromCode);
              return next;
            });
            break;
          }
          case 'chat_seen': {
            const seenSet = new Set(pkt.messageIds);
            setMessages((prev) =>
              prev.map((m) => (seenSet.has(m.id) ? { ...m, seen: true } : m))
            );
            break;
          }
          case 'chat_react': {
            setMessages((prev) =>
              prev.map((m) => {
                if (m.id !== pkt.messageId) return m;
                const filtered = m.reactions.filter(
                  (r) => r.byCode !== pkt.fromCode
                );
                return {
                  ...m,
                  reactions: [
                    ...filtered,
                    { emoji: pkt.emoji, byCode: pkt.fromCode },
                  ],
                };
              })
            );
            break;
          }
          case 'chat_edit': {
            setMessages((prev) =>
              prev.map((m) =>
                m.id === pkt.messageId
                  ? { ...m, text: pkt.newText, edited: true }
                  : m
              )
            );
            break;
          }
          case 'chat_unsend': {
            setMessages((prev) =>
              prev.map((m) =>
                m.id === pkt.messageId
                  ? {
                      ...m,
                      unsent: true,
                      text: '',
                      mediaDataUrl: undefined,
                    }
                  : m
              )
            );
            break;
          }
          case 'chat_view_once_consumed': {
            setMessages((prev) =>
              prev.map((m) =>
                m.id === pkt.messageId
                  ? {
                      ...m,
                      viewOnceConsumed: true,
                      mediaDataUrl: undefined,
                    }
                  : m
              )
            );
            break;
          }
          case 'chat_clear_both': {
            setMessages((prev) => prev.filter((m) => m.peerCode !== fromCode));
            break;
          }
          case 'fx_trigger': {
            triggerFullscreenFx(pkt.fx);
            break;
          }
          case 'rps_lock':
          case 'rps_reset':
          case 'ttt_move':
          case 'ttt_reset':
          case 'c4_move':
          case 'c4_reset':
          case 'codraw_stroke':
          case 'codraw_clear':
          case 'watch_sync': {
            setIncomingGamePacket({ seq: Date.now() + Math.random(), packet: pkt });
            break;
          }
          case 'call_signal': {
            if (pkt.action === 'ended' || pkt.action === 'declined') {
              cleanupCall();
            } else if (pkt.action === 'ringing') {
              setActiveCall((prev) =>
                prev ? { ...prev, mode: pkt.video ? 'video' : 'voice' } : prev
              );
            }
            break;
          }
        }
      },
    });

    p2pRef.current = manager;
    manager.start({
      code: user.code,
      displayName: user.displayName,
      avatarDataUrl: user.avatarDataUrl,
      friendCodes: friends.map((f) => f.code),
    });

    return () => {
      manager.stop();
      p2pRef.current = null;
    };
  }, [
    cleanupCall,
    sessionAuthed,
    triggerFullscreenFx,
    user?.id,
    wireMediaConnection,
  ]);

  // Keep P2P friend list synced when friends are added/removed
  useEffect(() => {
    p2pRef.current?.updateFriends(friends.map((f) => f.code));
  }, [friends]);

  // Mark messages seen when opening a chat
  useEffect(() => {
    if (!activeFriendCode || !user) return;
    const unseenIds = messages
      .filter(
        (m) =>
          m.peerCode === activeFriendCode &&
          m.senderCode === activeFriendCode &&
          !m.seen
      )
      .map((m) => m.id);

    if (unseenIds.length > 0) {
      const idSet = new Set(unseenIds);
      setMessages((prev) =>
        prev.map((m) => (idSet.has(m.id) ? { ...m, seen: true } : m))
      );
      p2pRef.current?.sendToCode(activeFriendCode, {
        type: 'chat_seen',
        fromCode: user.code,
        messageIds: unseenIds,
      });
    }
  }, [activeFriendCode, messages, user]);

  /* ---------------- ACTION HANDLERS ---------------- */

  const handleUnlockCalculator = () => {
    if (sessionAuthed && user) {
      setScreen(activeFriendCode ? 'chat' : 'home');
    } else {
      setScreen('account-gate');
    }
  };

  const handleAuthenticated = (authedUser: VaultUser) => {
    saveVaultUser(authedUser);
    setUser(authedUser);
    setSessionAuthed(true);
    setScreen('home');
  };

  const handleSendAddRequest = (
    targetCode: string
  ): { ok: boolean; message: string } => {
    if (!user) return { ok: false, message: 'No active account.' };
    if (friends.some((f) => f.code === targetCode)) {
      return { ok: false, message: 'Already in your Contacts.' };
    }
    const reqId = `req_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    p2pRef.current?.sendToCode(targetCode, {
      type: 'friend_request',
      requestId: reqId,
      fromCode: user.code,
      fromName: user.displayName,
      fromAvatar: user.avatarDataUrl,
      timestamp: Date.now(),
    });
    setRequests((prev) => {
      if (prev.some((r) => r.fromCode === targetCode && r.direction === 'outgoing')) {
        return prev;
      }
      return [
        {
          id: reqId,
          fromCode: targetCode,
          fromName: `Code ${targetCode}`,
          fromAvatar: '',
          timestamp: Date.now(),
          direction: 'outgoing',
        },
        ...prev,
      ];
    });
    return { ok: true, message: `Request sent to ${targetCode}.` };
  };

  const handleAcceptRequest = (req: FriendRequest) => {
    if (!user) return;
    audioEngine.playVaultUnlock();
    setFriends((prev) => {
      if (prev.some((f) => f.code === req.fromCode)) return prev;
      return [
        ...prev,
        {
          code: req.fromCode,
          displayName: req.fromName,
          avatarDataUrl: req.fromAvatar,
          addedAt: Date.now(),
        },
      ];
    });
    setRequests((prev) => prev.filter((r) => r.id !== req.id));
    p2pRef.current?.sendToCode(req.fromCode, {
      type: 'friend_accept',
      requestId: req.id,
      fromCode: user.code,
      fromName: user.displayName,
      fromAvatar: user.avatarDataUrl,
      timestamp: Date.now(),
    });
  };

  const handleDeclineRequest = (requestId: string) => {
    const req = requests.find((r) => r.id === requestId);
    setRequests((prev) => prev.filter((r) => r.id !== requestId));
    if (req && req.direction === 'incoming' && user) {
      p2pRef.current?.sendToCode(req.fromCode, {
        type: 'friend_decline',
        requestId,
        fromCode: user.code,
      });
    }
  };

  const handleSendMessage = (
    payload: Omit<
      ChatMessage,
      'id' | 'peerCode' | 'senderCode' | 'timestamp' | 'seen' | 'vanishAfterSec' | 'reactions'
    >
  ) => {
    if (!user || !activeFriendCode) return;
    const vanishSec = settings.autoVanishSec;
    const msg: ChatMessage = {
      ...payload,
      id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      peerCode: activeFriendCode,
      senderCode: user.code,
      timestamp: Date.now(),
      seen: false,
      vanishAfterSec: vanishSec,
      expiresAt: vanishSec > 0 ? Date.now() + vanishSec * 1000 : undefined,
      reactions: [],
    };

    setMessages((prev) => [...prev, msg]);
    audioEngine.playMessageSend();

    p2pRef.current?.sendToCode(activeFriendCode, {
      type: 'chat_message',
      message: msg,
    });

    // Smart text trigger fires FX on both screens
    if (msg.kind === 'text' && msg.text) {
      const triggered = detectFxTrigger(msg.text);
      if (triggered) {
        triggerFullscreenFx(triggered);
        p2pRef.current?.sendToCode(activeFriendCode, {
          type: 'fx_trigger',
          fromCode: user.code,
          fx: triggered,
          timestamp: Date.now(),
        });
      }
    }
  };

  const handleConsumeViewOnce = (messageId: string) => {
    setMessages((prev) =>
      prev.map((m) =>
        m.id === messageId
          ? { ...m, viewOnceConsumed: true, mediaDataUrl: undefined }
          : m
      )
    );
    if (user && activeFriendCode) {
      p2pRef.current?.sendToCode(activeFriendCode, {
        type: 'chat_view_once_consumed',
        fromCode: user.code,
        messageId,
      });
    }
  };

  const handleTriggerFxFromDrawer = (fx: FxType) => {
    triggerFullscreenFx(fx);
    if (user && activeFriendCode) {
      p2pRef.current?.sendToCode(activeFriendCode, {
        type: 'fx_trigger',
        fromCode: user.code,
        fx,
        timestamp: Date.now(),
      });
    }
  };

  const handleStartCall = async (mode: 'voice' | 'video') => {
    if (!user || !activeFriendCode) return;
    const friend = friends.find((f) => f.code === activeFriendCode);
    if (!friend) return;

    const { stream, warning } = await acquireLocalMedia(mode, 'user');
    setActiveCall({
      callId: `call_${Date.now()}`,
      mode,
      direction: 'outgoing',
      status: 'ringing',
      participants: [
        {
          code: friend.code,
          displayName: friend.nickname || friend.displayName,
          avatarDataUrl: friend.avatarDataUrl,
        },
      ],
      startedAt: null,
      muted: false,
      cameraOff: mode === 'voice',
      facingMode: 'user',
      minimized: false,
      permissionWarning: warning,
    });

    p2pRef.current?.sendToCode(friend.code, {
      type: 'call_signal',
      fromCode: user.code,
      action: 'ringing',
      video: mode === 'video',
    });

    if (stream) {
      const mc = p2pRef.current?.callPeer(friend.code, stream);
      if (mc) wireMediaConnection(mc, friend.code);
    }
  };

  const handleAcceptIncomingCall = async () => {
    audioEngine.stopRingtone();
    const pending = pendingIncomingMediaRef.current;
    if (!pending || !activeCall) return;

    const { stream, warning } = await acquireLocalMedia(
      activeCall.mode,
      activeCall.facingMode
    );
    if (stream) {
      pending.call.answer(stream);
      wireMediaConnection(pending.call, pending.fromCode);
    }
    pendingIncomingMediaRef.current = null;
    setActiveCall((prev) =>
      prev
        ? {
            ...prev,
            status: 'connected',
            startedAt: Date.now(),
            permissionWarning: warning,
          }
        : prev
    );
  };

  const handleEndCall = () => {
    if (user && activeCall) {
      activeCall.participants.forEach((p) => {
        p2pRef.current?.sendToCode(p.code, {
          type: 'call_signal',
          fromCode: user.code,
          action: 'ended',
          video: activeCall.mode === 'video',
        });
      });
    }
    cleanupCall();
  };

  const handleToggleCallMute = () => {
    if (!activeCall) return;
    const nextMuted = !activeCall.muted;
    localStreamRef.current?.getAudioTracks().forEach((t) => {
      t.enabled = !nextMuted;
    });
    setActiveCall((prev) => (prev ? { ...prev, muted: nextMuted } : prev));
  };

  const handleToggleCallCamera = () => {
    if (!activeCall) return;
    const nextOff = !activeCall.cameraOff;
    localStreamRef.current?.getVideoTracks().forEach((t) => {
      t.enabled = !nextOff;
    });
    setActiveCall((prev) => (prev ? { ...prev, cameraOff: nextOff } : prev));
  };

  const handleFlipCamera = async () => {
    if (!activeCall || activeCall.mode !== 'video') return;
    const nextFacing =
      activeCall.facingMode === 'user' ? 'environment' : 'user';
    localStreamRef.current?.getVideoTracks().forEach((t) => t.stop());
    const { stream } = await acquireLocalMedia('video', nextFacing);
    if (stream) {
      const videoTrack = stream.getVideoTracks()[0];
      activeMediaCallsRef.current.forEach((mc) => {
        const sender = mc.peerConnection
          ?.getSenders()
          .find((s) => s.track?.kind === 'video');
        if (sender && videoTrack) {
          void sender.replaceTrack(videoTrack);
        }
      });
    }
    setActiveCall((prev) =>
      prev ? { ...prev, facingMode: nextFacing } : prev
    );
  };

  const handleInviteThirdFriend = (thirdCode: string) => {
    if (!user || !activeCall || thirdCode === user.code) return;
    const friend = friends.find((f) => f.code === thirdCode);
    setActiveCall((prev) => {
      if (!prev || prev.participants.some((p) => p.code === thirdCode)) {
        return prev;
      }
      return {
        ...prev,
        participants: [
          ...prev.participants,
          {
            code: thirdCode,
            displayName: friend?.nickname || friend?.displayName || `Peer ${thirdCode}`,
            avatarDataUrl: friend?.avatarDataUrl || '',
          },
        ],
      };
    });
    if (localStreamRef.current) {
      const mc = p2pRef.current?.callPeer(thirdCode, localStreamRef.current);
      if (mc) wireMediaConnection(mc, thirdCode);
    }
  };

  const activeFriend = friends.find((f) => f.code === activeFriendCode) || null;
  const activeThreadMessages = activeFriend
    ? messages.filter((m) => m.peerCode === activeFriend.code)
    : [];

  return (
    <div
      className={`relative w-full h-full overflow-hidden ${
        activeFx === 'horror' ? 'fx-tremor-active' : ''
      }`}
    >
      {/* 7 Scenic Artwork Themes + Custom Wallpaper + Glass Dimmer */}
      <ThemeBackdrop
        themeId={settings.themeId}
        customWallpaper={settings.customWallpaper}
        glassDimmer={settings.glassDimmer}
      />

      {/* Active Screen Router */}
      {screen === 'calculator' && (
        <CalculatorLock pin={settings.pin} onUnlock={handleUnlockCalculator} />
      )}

      {screen === 'account-gate' && (
        <AccountGate
          existingUser={user}
          onAuthenticated={handleAuthenticated}
          onLockBack={() => setScreen('calculator')}
        />
      )}

      {screen === 'home' && user && (
        <VaultHome
          user={user}
          peerStatus={peerStatus}
          friends={friends}
          requests={requests}
          onlineCodes={onlineCodes}
          messages={messages}
          onOpenChat={(code) => {
            setActiveFriendCode(code);
            setScreen('chat');
          }}
          onOpenAddFriend={() => setShowAddFriend(true)}
          onOpenSettings={() => setShowSettings(true)}
          onLockVault={() => {
            setShowAddFriend(false);
            setShowSettings(false);
            setScreen('calculator');
          }}
          onAcceptRequest={handleAcceptRequest}
          onDeclineRequest={handleDeclineRequest}
        />
      )}

      {screen === 'chat' && user && activeFriend && (
        <ChatView
          myCode={user.code}
          friend={activeFriend}
          isOnline={onlineCodes.has(activeFriend.code)}
          isPeerTyping={typingPeers.has(activeFriend.code)}
          messages={activeThreadMessages}
          fontSize={settings.fontSize}
          autoVanishSec={settings.autoVanishSec}
          onBack={() => {
            setActiveFriendCode(null);
            setScreen('home');
          }}
          onSendText={(text: string, replyTo?: MessageReplyRef) =>
            handleSendMessage({ kind: 'text', text, replyTo })
          }
          onSendPhoto={(dataUrl: string, viewOnce: boolean) =>
            handleSendMessage({
              kind: viewOnce ? 'view-once' : 'photo',
              mediaDataUrl: dataUrl,
            })
          }
          onSendVoice={(dataUrl: string, durationSec: number) =>
            handleSendMessage({
              kind: 'voice',
              mediaDataUrl: dataUrl,
              voiceDurationSec: durationSec,
            })
          }
          onReactMessage={(messageId, emoji) => {
            setMessages((prev) =>
              prev.map((m) => {
                if (m.id !== messageId) return m;
                const filtered = m.reactions.filter(
                  (r) => r.byCode !== user.code
                );
                return {
                  ...m,
                  reactions: [...filtered, { emoji, byCode: user.code }],
                };
              })
            );
            p2pRef.current?.sendToCode(activeFriend.code, {
              type: 'chat_react',
              fromCode: user.code,
              messageId,
              emoji,
            });
          }}
          onEditMessage={(messageId, newText) => {
            setMessages((prev) =>
              prev.map((m) =>
                m.id === messageId ? { ...m, text: newText, edited: true } : m
              )
            );
            p2pRef.current?.sendToCode(activeFriend.code, {
              type: 'chat_edit',
              fromCode: user.code,
              messageId,
              newText,
            });
          }}
          onUnsendMessage={(messageId) => {
            setMessages((prev) =>
              prev.map((m) =>
                m.id === messageId
                  ? { ...m, unsent: true, text: '', mediaDataUrl: undefined }
                  : m
              )
            );
            p2pRef.current?.sendToCode(activeFriend.code, {
              type: 'chat_unsend',
              fromCode: user.code,
              messageId,
            });
          }}
          onOpenViewOnce={(msg) => setViewOnceTarget(msg)}
          onTypingChange={(isTyping) => {
            p2pRef.current?.sendToCode(activeFriend.code, {
              type: 'chat_typing',
              fromCode: user.code,
              isTyping,
            });
          }}
          onOpenFxDrawer={() => setShowFxDrawer(true)}
          onOpenGames={() => setShowGames(true)}
          onStartCall={handleStartCall}
          onSetNickname={(nickname) => {
            setFriends((prev) =>
              prev.map((f) =>
                f.code === activeFriend.code
                  ? { ...f, nickname: nickname || undefined }
                  : f
              )
            );
          }}
          onToggleMute={() => {
            setFriends((prev) =>
              prev.map((f) =>
                f.code === activeFriend.code ? { ...f, muted: !f.muted } : f
              )
            );
          }}
          onClearChatBothSides={() => {
            setMessages((prev) =>
              prev.filter((m) => m.peerCode !== activeFriend.code)
            );
            p2pRef.current?.sendToCode(activeFriend.code, {
              type: 'chat_clear_both',
              fromCode: user.code,
            });
          }}
        />
      )}

      {/* Modals & Drawers */}
      {showAddFriend && user && (
        <AddFriendModal
          myCode={user.code}
          onClose={() => setShowAddFriend(false)}
          onSendRequest={handleSendAddRequest}
        />
      )}

      {showSettings && (
        <SettingsModal
          settings={settings}
          onUpdateSettings={setSettings}
          onClose={() => setShowSettings(false)}
        />
      )}

      {showFxDrawer && (
        <FxDrawer
          onClose={() => setShowFxDrawer(false)}
          onTriggerFx={handleTriggerFxFromDrawer}
        />
      )}

      {showGames && user && activeFriend && (
        <GamesSpaceModal
          myCode={user.code}
          peerCode={activeFriend.code}
          peerName={activeFriend.nickname || activeFriend.displayName}
          peerOnline={onlineCodes.has(activeFriend.code)}
          incomingPacket={incomingGamePacket}
          onSendPacket={(pkt) => {
            p2pRef.current?.sendToCode(activeFriend.code, pkt);
          }}
          onClose={() => setShowGames(false)}
        />
      )}

      {viewOnceTarget && viewOnceTarget.mediaDataUrl && (
        <ViewOnceViewer
          messageId={viewOnceTarget.id}
          senderName={
            activeFriend?.nickname ||
            activeFriend?.displayName ||
            `Peer ${viewOnceTarget.senderCode}`
          }
          mediaDataUrl={viewOnceTarget.mediaDataUrl}
          onConsumeDestroy={handleConsumeViewOnce}
          onClose={() => setViewOnceTarget(null)}
        />
      )}

      {activeCall && (
        <CallOverlay
          call={activeCall}
          localStream={localStreamState}
          onAcceptIncoming={handleAcceptIncomingCall}
          onDeclineOrEnd={handleEndCall}
          onToggleMute={handleToggleCallMute}
          onToggleCamera={handleToggleCallCamera}
          onFlipCamera={handleFlipCamera}
          onToggleMinimize={() =>
            setActiveCall((prev) =>
              prev ? { ...prev, minimized: !prev.minimized } : prev
            )
          }
          onInviteThirdFriend={handleInviteThirdFriend}
        />
      )}

      {/* Fullscreen Animated FX Canvas Overlay */}
      <canvas
        ref={fxCanvasRef}
        data-testid="fx-canvas"
        data-active-fx={activeFx || ''}
        aria-hidden="true"
        className="fixed inset-0 z-50 w-full h-full pointer-events-none"
      />
    </div>
  );
}
